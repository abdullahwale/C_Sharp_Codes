//------------------------------------------------------------------------------
//
//FILE: AboutDlg.cs
//
//DESCRIPTION: This is an about dialog
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: AboutDlg
    //--------------------------------------------------------------------------
    public partial class AboutDlg : Form
    {
        public string MyTitle = " ";
        public string ProgramName = "Program";
        public string ProgramInfo = "info";

        //----------------------------------------------------------------------
        //NAME: AboutDlg
        //init the dialog
        //----------------------------------------------------------------------
        public AboutDlg()
        {
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: AboutDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void AboutDlg_Shown(object sender, EventArgs e)
        {
            //display the current set of data
            this.Text = MyTitle;
            lblProgramName.Text = ProgramName;
            lblProgramName.BackColor = this.BackColor;
            txbAboutInfo.Text = ProgramInfo;
            ContextMenuStrip DontShow = new ContextMenuStrip();
            DontShow.Visible = false;
            txbAboutInfo.ContextMenuStrip = DontShow;
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
            MyTitle = title;
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}