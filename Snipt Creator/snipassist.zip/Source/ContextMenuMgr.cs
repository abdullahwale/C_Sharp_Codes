//------------------------------------------------------------------------------
//
//FILE: ContextMenuMgr.cs
//
//DESCRIPTION: This file has the ContextMenuMgr. This class makes it easy to 
// fix the context menu (right click) for text boxes.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: ContextMenuMgr
    //--------------------------------------------------------------------------
    public class ContextMenuMgr
    {
        public static Char CtCr = (Char)(0x0D);
        public static Char CtLf = (Char)(0x0A);

        //----------------------------------------------------------------------
        //NAME: GetEmptyStrip
        //create a ContextMenuStrip that is disabled
        //----------------------------------------------------------------------
        public static ContextMenuStrip GetEmptyStrip()
        {
            ContextMenuStrip CMS = new ContextMenuStrip();
            CMS.Visible = false;
            return CMS;
        }
        //----------------------------------------------------------------------
        //NAME: SetEmptyStrip
        //create a ContextMenuStrip that is disabled
        //----------------------------------------------------------------------
        public static void SetEmptyStrip(TextBox Txb)
        {
            ContextMenuStrip CMS = new ContextMenuStrip();
            CMS.Visible = false;
            Txb.ContextMenuStrip = CMS;
        }
        //----------------------------------------------------------------------
        //NAME: GetStrip
        //create a ContextMenuStrip for read / write text boxes
        //----------------------------------------------------------------------
        public static ContextMenuStrip GetStrip(TextBox Txb)
        {
            int jj = 0;
            ContextMenuStrip CMS = new ContextMenuStrip();
            CMS.Items.Add("Select All", null, mnuSelectAll_Click);
            CMS.Items.Add("Delete", null, mnuDelete_Click);
            CMS.Items.Add("Cut", null, mnuCut_Click);
            CMS.Items.Add("Copy", null, mnuCopy_Click);
            CMS.Items.Add("Paste", null, mnuPaste_Click);
            CMS.Items.Add("Undo", null, mnuUndo_Click);
            CMS.Items.Add("Adjust Lines", null, mnuAdjust_Click);
            for (jj = 0; jj < CMS.Items.Count; jj++)
            {
                CMS.Items[jj].Tag = CMS;
            }
            CMS.Tag = Txb; 
            return CMS;
        }
        //----------------------------------------------------------------------
        //NAME: SetStrip
        //create a ContextMenuStrip for read / write text boxes
        //----------------------------------------------------------------------
        public static void SetStrip(TextBox Txb)
        {
            int jj = 0;
            ContextMenuStrip CMS = new ContextMenuStrip();
            CMS.Items.Add("Select All", null, mnuSelectAll_Click);
            CMS.Items.Add("Delete", null, mnuDelete_Click);
            CMS.Items.Add("Cut", null, mnuCut_Click);
            CMS.Items.Add("Copy", null, mnuCopy_Click);
            CMS.Items.Add("Paste", null, mnuPaste_Click);
            CMS.Items.Add("Undo", null, mnuUndo_Click);
            CMS.Items.Add("Adjust Lines", null, mnuAdjust_Click);
            for (jj = 0; jj < CMS.Items.Count; jj++)
            {
                CMS.Items[jj].Tag = CMS;
            }
            CMS.Tag = Txb;
            Txb.ContextMenuStrip = CMS;
        }
        //----------------------------------------------------------------------
        //NAME: GetStripRo
        //create a ContextMenuStrip for read only text boxes
        //----------------------------------------------------------------------
        public static ContextMenuStrip GetStripRo(TextBox Txb)
        {
            int jj = 0;
            ContextMenuStrip CMS = new ContextMenuStrip();
            CMS.Items.Add("Select All", null, mnuSelectAll_Click);
            CMS.Items.Add("Copy", null, mnuCopy_Click);
            for (jj = 0; jj < CMS.Items.Count; jj++)
            {
                CMS.Items[jj].Tag = CMS;
            }
            CMS.Tag = Txb;
            return CMS;
        }
        //----------------------------------------------------------------------
        //NAME: SetStripRo
        //create a ContextMenuStrip for read only text boxes
        //----------------------------------------------------------------------
        public static void SetStripRo(TextBox Txb)
        {
            int jj = 0;
            ContextMenuStrip CMS = new ContextMenuStrip();
            CMS.Items.Add("Select All", null, mnuSelectAll_Click);
            CMS.Items.Add("Copy", null, mnuCopy_Click);
            for (jj = 0; jj < CMS.Items.Count; jj++)
            {
                CMS.Items[jj].Tag = CMS;
            }
            CMS.Tag = Txb;
            Txb.ContextMenuStrip = CMS;
        }
        //----------------------------------------------------------------------
        //NAME: mnuCut_Click
        //----------------------------------------------------------------------
        public static void mnuCut_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem MyMenuItem = (ToolStripMenuItem)sender;
            ContextMenuStrip MyCms = (ContextMenuStrip)MyMenuItem.Tag;
            TextBox MyTxb = (TextBox)MyCms.Tag;
            Clipboard.SetText(MyTxb.SelectedText);
            MyTxb.SelectedText = "";
        }
        //----------------------------------------------------------------------
        //NAME: mnuCopy_Click
        //----------------------------------------------------------------------
        public static void mnuCopy_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem MyMenuItem = (ToolStripMenuItem)sender;
            ContextMenuStrip MyCms = (ContextMenuStrip)MyMenuItem.Tag;
            TextBox MyTxb = (TextBox)MyCms.Tag;
            Clipboard.SetText(MyTxb.SelectedText);
        }
        //----------------------------------------------------------------------
        //NAME: mnuPaste_Click
        //----------------------------------------------------------------------
        public static void mnuPaste_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem MyMenuItem = (ToolStripMenuItem)sender;
            ContextMenuStrip MyCms = (ContextMenuStrip)MyMenuItem.Tag;
            TextBox MyTxb = (TextBox)MyCms.Tag;
            MyTxb.SelectedText = Clipboard.GetText();
        }
        //----------------------------------------------------------------------
        //NAME: mnuSelectAll_Click
        //----------------------------------------------------------------------
        public static void mnuSelectAll_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem MyMenuItem = (ToolStripMenuItem)sender;
            ContextMenuStrip MyCms = (ContextMenuStrip)MyMenuItem.Tag;
            TextBox MyTxb = (TextBox)MyCms.Tag;
            MyTxb.Focus();
            MyTxb.SelectAll();
        }
        //----------------------------------------------------------------------
        //NAME: mnuUndo_Click
        //----------------------------------------------------------------------
        public static void mnuUndo_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem MyMenuItem = (ToolStripMenuItem)sender;
            ContextMenuStrip MyCms = (ContextMenuStrip)MyMenuItem.Tag;
            TextBox MyTxb = (TextBox)MyCms.Tag;
            if (MyTxb.CanUndo)
            {
                MyTxb.Undo();
                MyTxb.ClearUndo();
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuDelete_Click
        //----------------------------------------------------------------------
        public static void mnuDelete_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem MyMenuItem = (ToolStripMenuItem)sender;
            ContextMenuStrip MyCms = (ContextMenuStrip)MyMenuItem.Tag;
            TextBox MyTxb = (TextBox)MyCms.Tag;
            MyTxb.SelectedText = "";
        }
        //----------------------------------------------------------------------
        //NAME: mnuAdjust_Click
        //only adjust line with something selected
        //----------------------------------------------------------------------
        public static void mnuAdjust_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem MyMenuItem = (ToolStripMenuItem)sender;
            ContextMenuStrip MyCms = (ContextMenuStrip)MyMenuItem.Tag;
            TextBox MyTxb = (TextBox)MyCms.Tag;
            if (MyTxb.SelectionLength == 0)
            {
                return;
            }
            int SelNum = 0;
            int jj = 0;
            while (SelNum <= MyTxb.SelectionStart)
            {
                SelNum = SelNum + MyTxb.Lines[jj].Length + 2;
                jj++;
            }
            jj--;
            if (SelNum > MyTxb.SelectionStart)
            {
                SelNum = SelNum - MyTxb.Lines[jj].Length - 2;
            }
            int SelSize = 0;
            jj = 0;
            while (SelSize < MyTxb.SelectionStart + MyTxb.SelectionLength)
            {
                SelSize = SelSize + MyTxb.Lines[jj].Length + 2;
                jj++;
            }
            //-- set textbox selection
            MyTxb.SelectionStart = SelNum;
            MyTxb.SelectionLength = SelSize - SelNum;
            //-- get the lines and adjust them
            string TempText = MyTxb.SelectedText;
            List<string> MyLines = Util.MakeParagraphs(TempText);
            List<string> AllLines = new List<string>();
            foreach (string stx in MyLines)
            {
                List<string> TempList = Util.MakeDesc(stx, "", "");
                AllLines.AddRange(TempList);
                AllLines.Add("");
            }
            string EOL = "" + CtCr + CtLf;
            string AdjustedText = String.Join(EOL, AllLines.ToArray());
            MyTxb.SelectedText = AdjustedText;
            MyTxb.ScrollToCaret();
        }
    }
}
