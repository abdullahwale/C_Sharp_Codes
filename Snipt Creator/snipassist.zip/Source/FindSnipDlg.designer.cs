namespace Bartel
{
    partial class FindSnipDlg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBrowse = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtStartPath = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkIgnoreCase = new System.Windows.Forms.CheckBox();
            this.chkSnipDesc = new System.Windows.Forms.CheckBox();
            this.chkSnipBody = new System.Windows.Forms.CheckBox();
            this.chkCatDesc = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtLookFor = new System.Windows.Forms.TextBox();
            this.lxbFound = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBrowse
            // 
            this.btnBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Location = new System.Drawing.Point(383, 8);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(151, 23);
            this.btnBrowse.TabIndex = 0;
            this.btnBrowse.Text = "Select Search Folder";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Start Search Path";
            // 
            // txtStartPath
            // 
            this.txtStartPath.Location = new System.Drawing.Point(12, 36);
            this.txtStartPath.Name = "txtStartPath";
            this.txtStartPath.Size = new System.Drawing.Size(522, 20);
            this.txtStartPath.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PowderBlue;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.chkIgnoreCase);
            this.panel1.Controls.Add(this.chkSnipDesc);
            this.panel1.Controls.Add(this.chkSnipBody);
            this.panel1.Controls.Add(this.chkCatDesc);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Controls.Add(this.txtLookFor);
            this.panel1.Location = new System.Drawing.Point(12, 62);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(522, 104);
            this.panel1.TabIndex = 5;
            // 
            // chkIgnoreCase
            // 
            this.chkIgnoreCase.AutoSize = true;
            this.chkIgnoreCase.Checked = true;
            this.chkIgnoreCase.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIgnoreCase.Location = new System.Drawing.Point(370, 67);
            this.chkIgnoreCase.Name = "chkIgnoreCase";
            this.chkIgnoreCase.Size = new System.Drawing.Size(83, 17);
            this.chkIgnoreCase.TabIndex = 9;
            this.chkIgnoreCase.Text = "Ignore Case";
            this.chkIgnoreCase.UseVisualStyleBackColor = true;
            // 
            // chkSnipDesc
            // 
            this.chkSnipDesc.AutoSize = true;
            this.chkSnipDesc.Checked = true;
            this.chkSnipDesc.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSnipDesc.Location = new System.Drawing.Point(245, 66);
            this.chkSnipDesc.Name = "chkSnipDesc";
            this.chkSnipDesc.Size = new System.Drawing.Size(103, 17);
            this.chkSnipDesc.TabIndex = 8;
            this.chkSnipDesc.Text = "Snip Description";
            this.chkSnipDesc.UseVisualStyleBackColor = true;
            // 
            // chkSnipBody
            // 
            this.chkSnipBody.AutoSize = true;
            this.chkSnipBody.Location = new System.Drawing.Point(140, 66);
            this.chkSnipBody.Name = "chkSnipBody";
            this.chkSnipBody.Size = new System.Drawing.Size(74, 17);
            this.chkSnipBody.TabIndex = 7;
            this.chkSnipBody.Text = "Snip Body";
            this.chkSnipBody.UseVisualStyleBackColor = true;
            // 
            // chkCatDesc
            // 
            this.chkCatDesc.AutoSize = true;
            this.chkCatDesc.Location = new System.Drawing.Point(20, 66);
            this.chkCatDesc.Name = "chkCatDesc";
            this.chkCatDesc.Size = new System.Drawing.Size(111, 17);
            this.chkCatDesc.TabIndex = 6;
            this.chkCatDesc.Text = "Folder Description";
            this.chkCatDesc.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Text To Look for";
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(399, 8);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Stop Search";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(270, 8);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 23);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Begin Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtLookFor
            // 
            this.txtLookFor.Location = new System.Drawing.Point(20, 37);
            this.txtLookFor.Name = "txtLookFor";
            this.txtLookFor.Size = new System.Drawing.Size(486, 20);
            this.txtLookFor.TabIndex = 0;
            // 
            // lxbFound
            // 
            this.lxbFound.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.lxbFound.FormattingEnabled = true;
            this.lxbFound.Location = new System.Drawing.Point(15, 172);
            this.lxbFound.Name = "lxbFound";
            this.lxbFound.ScrollAlwaysVisible = true;
            this.lxbFound.Size = new System.Drawing.Size(519, 160);
            this.lxbFound.TabIndex = 6;
            this.lxbFound.SelectedIndexChanged += new System.EventHandler(this.lxbFound_SelectedIndexChanged);
            // 
            // FindSnipDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(546, 345);
            this.Controls.Add(this.lxbFound);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtStartPath);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBrowse);
            this.MaximizeBox = false;
            this.Name = "FindSnipDlg";
            this.Text = "FindDlg";
            this.Shown += new System.EventHandler(this.FindDlg_Shown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FindDlg_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtStartPath;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtLookFor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lxbFound;
        private System.Windows.Forms.CheckBox chkSnipDesc;
        private System.Windows.Forms.CheckBox chkSnipBody;
        private System.Windows.Forms.CheckBox chkCatDesc;
        private System.Windows.Forms.CheckBox chkIgnoreCase;
    }
}