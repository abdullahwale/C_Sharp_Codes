//------------------------------------------------------------------------------
//
//FILE: FindDlg.cs
//
//DESCRIPTION: This is the find dialog for the text editor.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: FindDlg
    //--------------------------------------------------------------------------
    public partial class FindDlg : Form
    {
        public string MyTitle = "FindDlg";

        public string What = "";
        public bool IgnoreCase = true;
        public bool WholeWord = false;
        public bool StartAtBeginning = false;
        public bool StartCurrent = true;

        public bool ExitNow = false;        //set by delegate to quit
        public MyEventHandler NextEvent;    //delegate to do find

        //----------------------------------------------------------------------
        //NAME: FindDlg
        //init the dialog
        //----------------------------------------------------------------------
        public FindDlg()
        {
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: FindDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void FindDlg_Shown(object sender, EventArgs e)
        {
            //display the current set of data
            this.Text = MyTitle;
            txbFindWhat.Text = What;
            txbFindWhat.Focus();
            chkIgnoreCase.Checked = IgnoreCase;
            chkWholeWord.Checked = WholeWord;
            rbStartBegin.Checked = StartAtBeginning;
            rbStartCurrent.Checked = StartCurrent;
            ContextMenuMgr.SetEmptyStrip(txbFindWhat);
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
            MyTitle = title;
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            What = txbFindWhat.Text.Trim();
            IgnoreCase = chkIgnoreCase.Checked;
            WholeWord = chkWholeWord.Checked;
            StartAtBeginning = rbStartBegin.Checked;
            StartCurrent = rbStartCurrent.Checked;

            if (NextEvent != null)
            {
                NextEvent();
            }
            rbStartCurrent.Checked = true;

            if (ExitNow)
            {
                DialogResult = DialogResult.OK;
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        //--------------------------------------------------------------------------
        //DELEGATE: MyEventHandler
        //do something for the replace dialog
        //--------------------------------------------------------------------------
        public delegate void MyEventHandler();
    }
}