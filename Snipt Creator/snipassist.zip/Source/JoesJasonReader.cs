//------------------------------------------------------------------------------
//
//FILE: JoesJasonReader.cs
//
//DESCRIPTION: This file has definition of JoesJasonReader. This is a specialised
// JSON string reader. It requires the Lexical class.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: JoesJasonReader
    //--------------------------------------------------------------------------
    public class JoesJasonReader
    {
        Lexical Lexus;
        //----------------------------------------------------------------------
        //NAME: JoesJasonReader
        //create the class
        //----------------------------------------------------------------------
        public JoesJasonReader(string RawString)
        {
            Lexus = new Lexical(RawString);
        }
        //----------------------------------------------------------------------
        //NAME: GetToken
        //----------------------------------------------------------------------
        public LexItem GetJsonToken()
        {
            LexItem ThisToken;
            ThisToken = Lexus.GetToken();
            while (ThisToken.Type == TokenType.LineEnd)
            {
                ThisToken = Lexus.GetToken();
                Application.DoEvents();
            }
            return ThisToken;
        }
        //----------------------------------------------------------------------
        //NAME: GetToken
        //----------------------------------------------------------------------
        public LexItem GetToken()
        {
            LexItem ThisToken;
            ThisToken = GetJsonToken();
            return ThisToken;
        }
        //----------------------------------------------------------------------
        //NAME: GetStringItem
        // for simple "nnn" : "sss"
        //----------------------------------------------------------------------
        public string GetStringItem()
        {
            string Result = "";
            LexItem ThisToken;

            ThisToken = GetJsonToken();   //this token should be ':'
            ThisToken = GetJsonToken();
            Result = ThisToken.Name;
            return Result;
        }
        //----------------------------------------------------------------------
        //NAME: GetStringList
        //for "nnn" : ["aaa", "bbb"]
        //----------------------------------------------------------------------
        public List<string> GetStringList()
        {
            List<string> Result = new List<string>();
            LexItem ThisToken;

            ThisToken = GetJsonToken();   //this token should be ':'
            while (ThisToken.Name != "]")
            {
                if (ThisToken.Type == TokenType.End)
                {
                    Gbls.LG.WriteLog("Something wrong");
                    break;      //something is wrong
                }
                if (ThisToken.Type == TokenType.Tstring)
                {
                    Result.Add(ThisToken.Name);
                }
                ThisToken = GetJsonToken();   //',' or '['
            }
            //should closing '}' be skipped here?
            string xyz = "";
            foreach (string stx in Result)
            {
                xyz = xyz + " - " + stx ;
            }
            return Result;
        }
    }
}
