//------------------------------------------------------------------------------
//
//FILE: TreeSelectDlg.cs
//
//DESCRIPTION: This is a dialog that uses a TreeView to select a folder. An
// existing tree view from a different form is used to populate the tree view.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: TreeSelectDlg
    //--------------------------------------------------------------------------
    public partial class TreeSelectDlg : Form
    {
        public string MyTitle = "StartSelectDlg";

        public TreeView CopyTreeView;       //original tree
        public string DirectoryName = "";
        public bool NoRoot = false;

        TreeNode CurntNode;
        //----------------------------------------------------------------------
        //NAME: TreeSelectDlg
        //init the dialog
        //----------------------------------------------------------------------
        public TreeSelectDlg()
        {
            InitializeComponent();
            txbFolderName.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
        }
        //----------------------------------------------------------------------
        //NAME: TreeSelectDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void TreeSelectDlg_Shown(object sender, EventArgs e)
        {
            tvSelect.Nodes.Clear();
            //display the current set of data
            if (CopyTreeView != null)
            {
                Util.TreeViewClone(CopyTreeView, tvSelect);
            }
            if (NoRoot)
            {
                btnRoot.Visible = false;
            }
        }
        //----------------------------------------------------------------------
        //NAME: tvSelect_AfterSelect
        //a new node was selected
        //----------------------------------------------------------------------
        private void tvSelect_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode TN = tvSelect.SelectedNode;
            CurntNode = TN;
            string Tx = TN.FullPath;
            txbFolderName.Text = Tx;
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            DirectoryName = txbFolderName.Text;
            DialogResult = DialogResult.OK;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: btnRoot_Click
        //If the result is an empty string, start at root
        //----------------------------------------------------------------------
        private void btnRoot_Click(object sender, EventArgs e)
        {
            txbFolderName.Text = "";
        }
        //----------------------------------------------------------------------
        //NAME: tvSelect_MouseDown
        //allow right mouse click to select node
        //----------------------------------------------------------------------
        private void tvSelect_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                TreeNode MyTn = tvSelect.GetNodeAt(e.Location);
                if (MyTn != null)
                {
                    tvSelect.SelectedNode = MyTn;
                }
            }
        }
    }
}