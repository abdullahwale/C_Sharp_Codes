//------------------------------------------------------------------------------
//
//FILE: MoveRenameDlg.cs
//
//DESCRIPTION: This dialog is for Copy, Move, Rename files of folders
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: MoveRenameDlg
    //--------------------------------------------------------------------------
    public partial class MoveRenameDlg : Form
    {
        public string MyTitle = "MoveRenameDlg";
        public string StartFolder = "";     //start for destination browse
        public string StartPath = "";       //may be snip file name
        public string DestPath = "";        //may be snip or folder name
        public TreeView WorkTree = null;
        public string ItemType = "Snip";
        public Char Action = 'R';           //Move, Rename

        public Color MyDark = Color.FromArgb(255, 0, 128, 255);
        public Color MyMedium = Color.FromArgb(255, 80, 168, 255);
        public Color MyLight = Color.FromArgb(255, 185, 220, 255);
        //----------------------------------------------------------------------
        //NAME: MoveRenameDlg
        //init the dialog
        //----------------------------------------------------------------------
        public MoveRenameDlg()
        {
            InitializeComponent();
            this.BackColor = MyMedium;
            groupBoxDest.BackColor = MyLight;
            groupBoxSrc.BackColor = MyLight;
        }
        //----------------------------------------------------------------------
        //NAME: MoveRenameDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void MoveRenameDlg_Shown(object sender, EventArgs e)
        {
            //display the current set of data
            this.Text = MyTitle;           
            txbDest.ContextMenuStrip = ContextMenuMgr.GetStrip(txbDest);
            txbSrc.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
            groupBoxSrc.Text = "Start " + ItemType;
            groupBoxDest.Text = "Result " + ItemType;
            txbSrc.Text = StartPath;
            if (Action == 'R')
            {
                btnDestSelect.Visible = false;
            }
            lblTitle.Text = MyTitle;
            txbSrc.Text = StartPath;
            txbDest.Text = "";
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title,string ItemKind)
        {
            MyTitle = title;
            ItemType = ItemKind;
            lblSrc.Text = "Start " + ItemType;
            lblDest.Text = "Result " + ItemType;
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            StartPath = txbSrc.Text.Trim();
            DestPath = txbDest.Text.Trim();
            Char[] BadPathChars = Path.GetInvalidPathChars();
            Char[] BadNameChars = Path.GetInvalidFileNameChars();
            bool DestOK = true;

            if (DestPath.Trim().Length < 1)
            {
                MessageBox.Show("Destination Cannot be blank", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                DestOK = false;
            }
            if (Action == 'R')
            {
                if(DestPath.IndexOfAny(BadNameChars) >= 0)
                {
                    MessageBox.Show("New Name Not Valid", Gbls.ProgTitle,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    int NameNdx = DestPath.IndexOfAny(BadNameChars);
                    Gbls.LG.WriteLog("Bad Char: "  + NameNdx.ToString());
                    DestOK = false;
                }
            }
            else
            {
                if (DestPath.IndexOfAny(BadPathChars) >= 0)
                {
                    MessageBox.Show("Destination Folder Not Valid", Gbls.ProgTitle,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    int PathNdx = DestPath.IndexOfAny(BadPathChars);
                    Gbls.LG.WriteLog("Bad Char: " + PathNdx.ToString());
                    DestOK = false;
                }
            }
            if (DestOK)
            {
                DialogResult = DialogResult.OK;
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: btnDestSelect_Click
        //select a destination folder - name must be added
        //----------------------------------------------------------------------
        private void btnDestSelect_Click(object sender, EventArgs e)
        {
            TreeSelectDlg TSD = new TreeSelectDlg();
            TSD.CopyTreeView = WorkTree;
            TSD.NoRoot = true;

            if (TSD.ShowDialog() == DialogResult.OK)
            {
                txbDest.Text = TSD.DirectoryName;
            }
        }
    }
}