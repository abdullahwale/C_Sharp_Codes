//------------------------------------------------------------------------------
//
//FILE: CryptoDlg.cs
//
//DESCRIPTION: This dialog will allow encrypting or decrypting a snip
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: CryptoDlg
    //--------------------------------------------------------------------------
    public partial class CryptoDlg : Form
    {
        public string MyTitle = "CryptoDlg";
        public bool SaveResult = false;
        public string SnipBody = "";
        public byte[] WorkByte;
        public Random CrRandum = new Random();

        //----------------------------------------------------------------------
        //NAME: CryptoDlg
        //init the dialog
        //----------------------------------------------------------------------
        public CryptoDlg()
        {
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: CryptoDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void CryptoDlg_Shown(object sender, EventArgs e)
        {
            //display the current set of data
            this.Text = MyTitle;
            ContextMenuStrip DontShow = new ContextMenuStrip();
            DontShow.Visible = false;
            txbBody.ContextMenuStrip = DontShow;
            txbBody.Text = SnipBody;
            txbKey.ContextMenuStrip = DontShow;
            txbKey.Focus();
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
            MyTitle = title;
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            SaveResult = true;
            DialogResult = DialogResult.OK;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it -- plain Exit, no save
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            SaveResult = false;
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: btnEncrypt_Click
        //encrypt the snip body text to a string of hex chars
        //----------------------------------------------------------------------
        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            int jj;
            SnipBody = txbBody.Text;
            int blocks = SnipBody.Length / 8;
            int PadSize = (blocks + 1)*8;
            string WorkStr = SnipBody.PadRight(PadSize);

            string KeyStr = txbKey.Text.Trim();
            if (KeyStr.Length < 1)
            {
                MessageBox.Show("No Key Entered", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbKey.Focus();
                return;
            }

            //1. convert chars to bytes, pad
            WorkByte = new byte[PadSize + PadSize];
            for (jj = 0; jj < PadSize; jj++)
            {
                WorkByte[jj + jj] = Convert.ToByte(WorkStr[jj]);
                WorkByte[jj + jj + 1] = (byte)(CrRandum.Next() & 0x0FF);
            }
            //2. add junk string, pad to fixed size blocks - can be interleave, 
            //3. rearrange chars  - a simple array of destination indexes - blocks
            //4. xor with key
            byte[] Keybyte = new byte[KeyStr.Length];
            for (jj = 0; jj < KeyStr.Length; jj++)
            {
                Keybyte[jj] = Convert.ToByte(KeyStr[jj]);
            }
            int kk = 0;
            for (jj = 0; jj < WorkByte.Length; jj++)
            {
                WorkByte[jj] = (byte)(WorkByte[jj] ^ Keybyte[kk]);
                if ((CrRandum.Next() & 1) == 1)
                {
                    WorkByte[jj] = (byte)(WorkByte[jj] | 0x80); //random high bit
                }
                kk++;
                if(kk >= Keybyte.Length) kk = 0;
            }
            //convert bytes to hex - format nicely
            StringBuilder SB = new StringBuilder();
            for (jj=0; jj < WorkByte.Length;)
            {
                for(kk=0; kk<32; kk++)
                {
                    if (jj >= WorkByte.Length)
                    {
                        break;
                    }
                    SB.Append(WorkByte[jj].ToString("X2"));
                    kk++;
                    jj++;
                }
                SB.AppendLine();
            }
            SnipBody = SB.ToString();
            txbBody.Text = SnipBody ;
        }
        //----------------------------------------------------------------------
        //NAME: btnDecrypt_Click
        //decrypt the string of hex characters back to plain text
        //----------------------------------------------------------------------
        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            int jj;
            //unconvert from hex back to bytes - ignore crlf
            byte[] WorkByte = ConvertHex(txbBody.Text);

            //xor with key
            string KeyStr = txbKey.Text.Trim();
            if (KeyStr.Length < 1)
            {
                MessageBox.Show("No Key Entered", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbKey.Focus();
                return;
            }

            byte[] Keybyte = new byte[KeyStr.Length];
            for (jj = 0; jj < KeyStr.Length; jj++)
            {
                Keybyte[jj] = Convert.ToByte(KeyStr[jj]);
            }
            int kk = 0;
            for (jj = 0; jj < WorkByte.Length; jj++)
            {
                WorkByte[jj] = (byte)((WorkByte[jj] ^ Keybyte[kk]) & 0x7F);
                kk++;
                if (kk >= Keybyte.Length) kk = 0;
            }
            //rearrange chars  - ignore random junk //use inverse array
            byte[] ClearByte = new byte[WorkByte.Length / 2];
            for (kk = 0; kk < ClearByte.Length; kk++)
            {
                ClearByte[kk] = WorkByte[kk+kk];
            }
            //convert bytes to chars, trim
            StringBuilder SB = new StringBuilder();
            for (kk = 0; kk < ClearByte.Length; kk++)
            {
                SB.Append(Convert.ToChar(ClearByte[kk]));
            }
            //display
            txbBody.Text = SB.ToString().Trim();
            SnipBody = txbBody.Text;
        }
        //----------------------------------------------------------------------
        //NAME: HexFromBytes
        // convert an array of bytes to a string of hex chars
        //----------------------------------------------------------------------
        public string HexFromBytes(byte[] Rawbytes)
        {
            StringBuilder Result = new StringBuilder();
            int jj;

            for (jj = 0; jj < Rawbytes.Length; jj++)
            {
                Result.Append(Rawbytes[jj].ToString("X4"));
            }

            return Result.ToString();
        }
        //----------------------------------------------------------------------
        //NAME: ConvertHex
        //convert an ascii hex string to an array of bytes
        //----------------------------------------------------------------------
        public static byte[] ConvertHex(string Input)
        {
            string InStr = Input.ToUpper();
            int ndx = 0;
            byte[] Buff = new byte[InStr.Length + 1];
            string HexStr = "0123456789ABCDEF";
            int jj = 0;
            int kk = 0;
            byte[] OutMsg = new byte[InStr.Length];

            //this is for a possible range error if odd number of chars
            Buff[InStr.Length] = 0;
            //-- this assumes there are no spaces - may need work
            for (jj = 0; jj < InStr.Length; jj++)
            {
                ndx = HexStr.IndexOf(InStr[jj]);
                if (ndx >= 0)           //skip crlf
                {
                    Buff[kk] = (byte)ndx;
                    kk++;
                }
            }
            //now convert the small numbers into bytes
            ndx = 0;
            for (jj = 0; jj < kk; jj = jj + 2)
            {
                OutMsg[ndx] = Convert.ToByte((Buff[jj] << 4) + Buff[jj + 1]);
                ndx++;
            }
            Array.Resize(ref OutMsg, ndx);
            return OutMsg;
        }
        //----------------------------------------------------------------------
        //NAME: btnCopy_Click
        //copy text to clipboard
        //----------------------------------------------------------------------
        private void btnCopy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txbBody.Text);
        }
    }
}