//------------------------------------------------------------------------------
//
//FILE: Globals.cs
//
//DESCRIPTION: This file has the global items for SnipAssist
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Gbls
    //--------------------------------------------------------------------------
    class Gbls
    {
        public static bool DebugVersion = false;
        public static Logger LG;                // common logger
        public static string ProgVersion = "1.0";
        public static string BuildDate = "14-MAR-19";
        public static string ProgTitle = "SnipAssist";
        public static string ContactEMail = "PineTreeJoe@hotmail.com";
        public static string StartPath = "";    //the config file goes here
        public static string HelpPath = "";     //get help file from here
        public static Form1 MainForm;           //who we are - Form1 - this

        public static Color DarkColor = Color.FromArgb(255, 0, 128, 255);
        public static Color MediumColor = Color.FromArgb(255, 80, 168, 255);
        public static Color LightColor = Color.FromArgb(255, 185, 220, 255);

        public static Char CtlC = (Char)(0x03);
        public static Char CtlV = (Char)(0x16);
        public static Char CtCr = (Char)(0x0D);
        public static Char CtLf = (Char)(0x0A);
        public static Char TabChar = (Char)(0x09);

        public static int TextMargin = 80;
        public static int TabSize = 4;
        public static bool AutoClipboard = true;
        public static string RootFolder = "";
        public static bool UsbRoot = true;     //true if using default library root
        //----------------------------------------------------------------------
        //NAME: Init
        //initialize global items
        //----------------------------------------------------------------------
        public static void Init()
        {
            if (DebugVersion)
            {
                Gbls.LG.WriteLog("* Debugging *");
                ProgTitle = ProgTitle + " * * * DEBUGGING * * *";
            }
            //------------------------------------------------------------
            HelpPath = StartPath + "\\SnipAssist-Help.tdf";
            RootFolder = StartPath;

            string ConfigPath = Gbls.StartPath + "\\" + "Config.txt";
            if (File.Exists(ConfigPath))
            {
                //read and apply config file
                MainForm.ReadConfig();
            }
        }
    }
}
