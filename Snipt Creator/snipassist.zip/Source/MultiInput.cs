//------------------------------------------------------------------------------
//
//FILE: MultiInput.cs
//
//DESCRIPTION: This is a generic multiple input dialog box. The boxes can be
// text or combo boxes. The boxes can have intial values. There can be up to
// 20 input boxes.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: MultiInputDlg
    //--------------------------------------------------------------------------
    public partial class MultiInputDlg : Form
    {
        public string[] Results;    //user entered data

        int MaxBox = 19;            //max index for a box
        Label[] UserLabels;         //labels for the boxes
        TextBox[] UserText;         //textbox controls
        ComboBox[] UserCombo;       //combobox controls
        int Labelx = 12;
        int BoxX = 150;
        int MinY = 105;         //minimum Y for dialog size
        int StartY = 15;        //start y location
        int YSize = 25;         //y inc for each item
        int NumUsed = 0;        //number of inputs used

        public Dictionary<string, List<string>> AllItems = new Dictionary<string, List<string>>();

        //----------------------------------------------------------------------
        //NAME: MultiInputDlg
        //create the main gui
        //----------------------------------------------------------------------
        public MultiInputDlg()
        {
            //create all the controls before Initiailize
            Label ThisLabel;
            TextBox ThisBox;
            ComboBox ThisCombo;
            int jj;
            int yLoc = StartY;

            Results = new string[MaxBox + 1];
            UserLabels = new Label[MaxBox + 1];
            UserText = new TextBox[MaxBox + 1];
            UserCombo = new ComboBox[MaxBox + 1];

            for (jj = 0; jj <= MaxBox; jj++)
            {
                ThisLabel = new Label();
                ThisLabel.Location = new Point(Labelx, yLoc);
                ThisLabel.Visible = false;
                ThisLabel.AutoSize = true;
                ThisLabel.Anchor = ((AnchorStyles)(((AnchorStyles.Top |
                        AnchorStyles.Left)| AnchorStyles.Right)));
                ThisLabel.Text = "Label + " + jj.ToString();
                this.Controls.Add(ThisLabel);
                UserLabels[jj] = ThisLabel;

                ThisBox = new TextBox();
                ThisBox.Location = new System.Drawing.Point(BoxX, yLoc);
                ThisBox.Name = "textBox1";
                ThisBox.Size = new System.Drawing.Size(179, 20);
                ThisBox.Visible = false;
                ThisBox.Anchor = ((AnchorStyles)(((AnchorStyles.Top |
                                AnchorStyles.Left) | AnchorStyles.Right)));
                ThisBox.ContextMenuStrip = new ContextMenuStrip();
                ThisBox.ContextMenuStrip.Visible = false;
                //-- test multiline input!
                ThisBox.Multiline = true;
                ThisBox.AcceptsReturn = true;
                this.Controls.Add(ThisBox);
                UserText[jj] = ThisBox;

                ThisCombo = new ComboBox();
                ThisCombo.Location = new System.Drawing.Point(BoxX, yLoc);
                ThisCombo.Name = "textBox1";
                ThisCombo.Size = new System.Drawing.Size(179, 20);
                ThisCombo.Visible = false;
                ThisCombo.Anchor = ((AnchorStyles)(((AnchorStyles.Top |
                                AnchorStyles.Left) | AnchorStyles.Right)));
                //ThisBox.TabIndex = 3;
                this.Controls.Add(ThisCombo);
                UserCombo[jj] = ThisCombo;
                yLoc = yLoc + YSize ;
            }
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: MultiInputDlg_Shown
        //just got displayed - set size - set focus to first box 
        //----------------------------------------------------------------------
        private void MultiInputDlg_Shown(object sender, EventArgs e)
        {
            this.Height = (NumUsed * YSize) + YSize + YSize + StartY;
            if (this.Height < MinY)
            {
                this.Height = MinY;
            }
            if (UserText[0].Visible)
            {
                UserText[0].Focus();
            }
            if (UserCombo[0].Visible)
            {
                UserCombo[0].Focus();
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //gather all the inputs into the results array
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            int jj;

            for (jj = 0; jj <= MaxBox; jj++)
            {
                if (UserCombo[jj].Visible)
                {
                    Results[jj] = UserCombo[jj].Text;
                }
                else
                {
                    Results[jj] = UserText[jj].Text;
                }
            }
            DialogResult = DialogResult.OK;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //just quit - all results are blank
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            int jj;

            for (jj = 0; jj <= MaxBox; jj++)
            {
                Results[jj] = "";
            }
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: SetupText
        //set all the label text and the title - overload
        //----------------------------------------------------------------------
        public void SetupText(string TitleText, string Names)
        {
            //set height
            this.Text = TitleText;
            string[] MyLabels = Names.Split(',');
            int jj;
            int Max = MyLabels.Length;

            if (Max > MaxBox)
            {
                Max = MaxBox + 1;
            }

            for (jj = 0; jj < Max; jj++)
            {
                UserLabels[jj].Text = MyLabels[jj];
                UserLabels[jj].Visible = true;
                UserText[jj].Visible = true;
            }
            NumUsed = Max;
        }
        //----------------------------------------------------------------------
        //NAME: SetupText
        //set all the label text and the title - overload
        //----------------------------------------------------------------------
        public void SetupText(string TitleText, List<string> Names)
        {
            //set height
            this.Text = TitleText;
            int jj;
            int Max = Names.Count;

            if (Max > MaxBox)
            {
                Max = MaxBox + 1;
            }

            for (jj = 0; jj < Max; jj++)
            {
                UserLabels[jj].Text = Names[jj];
                UserLabels[jj].Visible = true;
                UserText[jj].Visible = true;
            }
            NumUsed = Max;
        }
        //----------------------------------------------------------------------
        //NAME: SetDefaults
        //set defaults for text boxes - overload
        //----------------------------------------------------------------------
        public void SetDefaults(string Initial)
        {
            string[] Vals = Initial.Split(',');
            int jj;
            int Max = Vals.Length;
            if (Max > MaxBox)
            {
                Max = MaxBox + 1;
            }

            for (jj = 0; jj < Max ; jj++)
            {
                UserText[jj].Text = Vals[jj];
            }
        }
        //----------------------------------------------------------------------
        //NAME: SetDefaults
        //set defaults for text boxes - overload
        //----------------------------------------------------------------------
        public void SetDefaults(List<string> Initial)
        {
            int jj;
            int Max = Initial.Count;
            if (Max > MaxBox)
            {
                Max = MaxBox + 1;
            }

            for (jj = 0; jj < Max; jj++)
            {
                UserText[jj].Text = Initial[jj];
            }
        }
        //----------------------------------------------------------------------
        //NAME: SetComboBox
        //set a text box to a combo box and set the combo box entries
        //----------------------------------------------------------------------
        public void SetComboBox(int Box, string SelText, string Default)
        {
            if (Box > MaxBox)
            {
                return;
            }
            int jj;
            string[] Vals = SelText.Split(',');
            for (jj = 0; jj < Vals.Length; jj++)
            {
                UserCombo[Box].Items.Add(Vals[jj]);
            }
            UserCombo[Box].Text = Default;
            UserCombo[Box].Visible = true;
            UserText[Box].Visible = false;
        }
        //----------------------------------------------------------------------
        //NAME: SetComboBox
        //set a text box to a combo box and set the combo box entries
        //----------------------------------------------------------------------
        public void SetComboBox(List<List<string>> BoxList)
        {
            int jj = 0;
            int kk = 0;

            for (jj = 0; jj < BoxList.Count; jj++)
            {
                if (BoxList[jj].Count > 2)
                {
                    //[0] name [1] default [2] first option
                    for (kk = 1; kk < BoxList[jj].Count; kk++)
                    {
                        UserCombo[jj].Items.Add(BoxList[jj][kk]);
                    }
                    UserCombo[jj].Text = BoxList[jj][1];
                    UserCombo[jj].Visible = true;
                    UserText[jj].Visible = false;
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: SetComboBox
        //set a text box to a combo box and set the combo box entries
        //----------------------------------------------------------------------
        public void SetComboBox(int Box, List<string> SelText, string Default)
        {
            if (Box > MaxBox)
            {
                return;
            }
            int jj;
            //string[] Vals = SelText.Split(',');
            for (jj = 0; jj < SelText.Count; jj++)
            {
                UserCombo[Box].Items.Add(SelText[jj]);
            }
            UserCombo[Box].Text = Default;
            UserCombo[Box].Visible = true;
            UserText[Box].Visible = false;
        }
        //----------------------------------------------------------------------
        //NAME: SetAllItems
        //set a text box to a combo box and set the combo box entries
        //----------------------------------------------------------------------
        public void SetAllItems(Dictionary<string, List<string>> NewItems)
        {
            int jj = 0;
            AllItems = NewItems;

            foreach(KeyValuePair<string, List<string>> KVP in AllItems)
            {
                UserLabels[jj].Text = KVP.Value[0]; //KVP.Key;
                UserLabels[jj].Visible = true;
                if (KVP.Value.Count == 1)
                {
                    UserText[jj].Visible = true;
                }
                else if (KVP.Value.Count == 2)
                {
                    UserText[jj].Text = KVP.Value[1];
                    UserText[jj].Visible = true;
                }
                else
                {
                    string[] Tmp = KVP.Value.ToArray();
                    UserCombo[jj].Items.AddRange(Tmp);
                    UserCombo[jj].Items.RemoveAt(0);
                    UserCombo[jj].Text = Tmp[1];
                    UserCombo[jj].Visible = true;
                    UserText[jj].Visible = false;   //set by SetupText
                }
                jj++;
            }
        }
    }
}
