//------------------------------------------------------------------------------
//
//FILE: MakeCatalog.cs
//
//DESCRIPTION: This file has methods that go with Form1 to create the Catalog
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Form1
    //--------------------------------------------------------------------------
    public partial class Form1 : Form
    {
        public string MyTitle = "CatalogDlg";
        public string StartFolder = "";
        public string ItemType = "Snip";
        public bool DoCatDescription;
        public bool DoSnipDescription;
        public bool DoSnipBody;
        public bool DoWholeTree;

        //----------------------------------------------------------------------
        //NAME: mnuMakeCatalog_Click
        //run the dialog to make a Item Catalog
        //----------------------------------------------------------------------
        private void mnuMakeCatalog_Click(object sender, EventArgs e)
        {
            CatalogDlg CD = new CatalogDlg();
            string Catalog = "";

            CD.StartFolder = Gbls.RootFolder;
            CD.WorkTree = Util.CloneTreeView(tvSelect);
            CD.Setup(Gbls.ProgTitle);
            CD.ItemType = "Snip";
            CD.MyDark = Gbls.DarkColor;
            CD.MyMedium = Gbls.MediumColor;
            CD.MyLight = Gbls.LightColor;

            if (CD.ShowDialog() == DialogResult.OK)
            {
                StartFolder = CD.StartFolder;
                DoCatDescription = CD.DoCatDescription;
                DoSnipDescription = CD.DoItemDescription;
                DoSnipBody = CD.DoItemBody;
                DoWholeTree = CD.DoWholeTree;

                CatalogCls MyCatalog = new CatalogCls();
                MyCatalog.ItemType = ItemType;
                MyCatalog.MakeDate = DateTime.Now.ToLongDateString();
                if (StartFolder.Trim() == "")
                {
                    MyCatalog.LibraryRoot = true;
                    CatalogFolderCls FirstFolder = new CatalogFolderCls();
                    FirstFolder.FolderName = "Whole Library";
                    MyCatalog.RootFolder = FirstFolder;

                    //start at root, do all the nodes
                    foreach (TreeNode Tx in tvSelect.Nodes)
                    {
                        FirstFolder.Folder.Add(GetCatalogFolder(Tx));
                    }
                }
                else
                {
                    //look in start node
                    TreeNode Tnn = Util.FindTreeNode(StartFolder, tvSelect);
                    MyCatalog.RootFolder = GetCatalogFolder(Tnn);
                }

                Catalog = MyCatalog.MakeTextCatalog();
                //show the result and close
                RtfViewDlg RFD = new RtfViewDlg();
                RFD.Title = "SnipAssist Catalog";
                RFD.ReportName = ItemType + " Catalog";
                RFD.MyColor = Color.LightBlue;
                RFD.PlainText = true;           //not rtf
                RFD.ReportText = Catalog;
                //RFD.TopMost = true;
                RFD.Show();
            }
        }
        //----------------------------------------------------------------------
        //NAME: GetCatalogFolder
        //warning: recursive - Abstract Catalog
        //----------------------------------------------------------------------
        CatalogFolderCls GetCatalogFolder(TreeNode MyNode)
        {
            CatalogFolderCls MyFolder = new CatalogFolderCls();
            CatalogItemCls MyItem = new CatalogItemCls();
            int jj;
            string Folder = Gbls.RootFolder + "\\" + MyNode.FullPath;
            DirectoryInfo DI = new DirectoryInfo(Folder);
            FileInfo[] LocalFiles;
            string[] FileNames;
            string txx = "";
            SnipCls ThisSnip;

            MyFolder.FolderName = MyNode.FullPath.Trim();

            //if CatDesc - add CatDesc
            if (DoCatDescription)
            {
                string DescName = Folder + "\\Description.txt";
                if (File.Exists(DescName))
                {
                    txx = Util.GetTextFile(DescName);
                    MyFolder.Description = txx.Trim();
                }
            }
            //----------- do snips in this folder
            LocalFiles = DI.GetFiles("*.snp");
            FileNames = Directory.GetFiles(Folder, "*.snp");
            Array.Sort(FileNames, LocalFiles);
            for (jj = 0; jj < LocalFiles.Length; jj++)
            {
                MyItem = new CatalogItemCls();
                MyItem.Name = LocalFiles[jj].Name;
                if (DoSnipDescription | DoSnipBody)
                {
                    txx = Util.GetTextFile(LocalFiles[jj].FullName);
                    ThisSnip = new SnipCls();
                    ThisSnip.GetSnipText(txx);
                    if (DoSnipDescription)
                    {
                        MyItem.Description = ThisSnip.Description.Trim();
                    }
                    if (DoSnipBody)
                    {
                        MyItem.Body = ThisSnip.Body;
                    }
                }
                MyFolder.Item.Add(MyItem);
            }
            //------ do the sub folders
            if (DoWholeTree)
            {
                foreach (TreeNode Tx in MyNode.Nodes)
                {
                    MyFolder.Folder.Add(GetCatalogFolder(Tx));
                }
            }
            return MyFolder;
        }
    }
}
