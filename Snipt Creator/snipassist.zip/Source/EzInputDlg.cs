//------------------------------------------------------------------------------
//
//NAME: EzInputDlg.cs
//
//DESCRIPTION: This class has some easy input dialogs. Each will have a prompt
// and will convert the input.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: EzInputDlg
    //--------------------------------------------------------------------------
    public partial class EzInputDlg : Form
    {
        public string MyTitle = "EZ Input";
        public string MyPrompt = "Enter";
        public Color BackCol = Color.CadetBlue;
        public string Rslt = "";

        //----------------------------------------------------------------------
        //NAME: EzInputDlg
        //init the dialog form - dialog must be first class in file
        //----------------------------------------------------------------------
        public EzInputDlg()
        {
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: EzInputDlg_Shown
        //show the dialog
        //----------------------------------------------------------------------
        private void EzInputDlg_Shown(object sender, EventArgs e)
        {
            label1.Text = MyPrompt;
            this.Text = MyTitle;
            this.BackColor = BackCol;
            ContextMenuMgr.SetEmptyStrip(textBox1);
            this.textBox1.Focus();
            this.textBox1.Text = Rslt;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //cancel, ignore the input
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Rslt = "";
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: btnNext_Click
        //OK, save the info
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            Rslt = textBox1.Text;
            DialogResult = DialogResult.OK;
        }
    }
    //--------------------------------------------------------------------------
    //CLASS: EzInput
    //class to run the dialog
    //--------------------------------------------------------------------------
    public class EzInput : Object
    {
        public static Color BackGround = Color.LightBlue;
        public static int Width;
        public static string Initial = "";

        //----------------------------------------------------------------------
        //NAME: GetDouble
        //run the dialog and convert the result to a double
        //----------------------------------------------------------------------
        public static double GetDouble(string title, string prompt)
        {
            EzInputDlg EZ = new EzInputDlg();
            EZ.BackCol = BackGround;
            EZ.MyTitle = title;
            EZ.MyPrompt = prompt;
            EZ.Rslt = Initial;
            Size NewSize = new Size(Width, EZ.Size.Height);
            EZ.Size = NewSize;
            double Value = 0.0;

            if (EZ.ShowDialog() == DialogResult.OK)
            {
                double.TryParse(EZ.Rslt, out Value);
            }
            return Value;
        }
        //----------------------------------------------------------------------
        //NAME: GetString
        //run the dialog and return the result as a string
        //----------------------------------------------------------------------
        public static string GetString(string title, string prompt)
        {
            string Value = "";
            EzInputDlg EZ = new EzInputDlg();
            EZ.BackCol = BackGround;
            EZ.MyTitle = title;
            EZ.MyPrompt = prompt;
            EZ.Rslt = Initial;

            if (EZ.ShowDialog() == DialogResult.OK)
            {
                Value = EZ.Rslt;
            }
            return Value;
        }
        //----------------------------------------------------------------------
        //NAME: GetInt
        //run the dialog and convert the result to a Int32
        //----------------------------------------------------------------------
        public static Int32 GetInt(string title, string prompt)
        {
            Int32 Value = 0;
            EzInputDlg EZ = new EzInputDlg();
            EZ.BackCol = BackGround;
            EZ.MyTitle = title;
            EZ.MyPrompt = prompt;
            EZ.Rslt = Initial;

            Size NewSize = new Size(Width, EZ.Size.Height);
            EZ.Size = NewSize;

            if (EZ.ShowDialog() == DialogResult.OK)
            {
                Int32.TryParse(EZ.Rslt, out Value);
            }
            return Value;
        }
    }
}