//------------------------------------------------------------------------------
//
//FILE: Logger.cs
//
//DESCRIPTION: This is a generic logger for c#
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Logger
    //--------------------------------------------------------------------------
    public partial class Logger : Form
    {
        public bool LogEnabled;             //file logging is enabled
        public bool DisplayEnabled;         //form display enabled
        public string LogFolder = "C:\\Test\\Logs\\";
        public StreamWriter LogFile;        //debug logging
        public Queue<string> LogDisplay;    //queue of lines to display
        public int LogLineCount;            //lines in display
        public int MaxLineCount;            //max lines in log display
        public string MyTitle;              //title for display
        public string PathName;             //where to store log file
        
        //----------------------------------------------------------------------
        //NAME: Logger
        //create object
        //----------------------------------------------------------------------
        public Logger()
        {
            InitializeComponent();
            LogEnabled = false;
            DisplayEnabled = true;
            LogLineCount = 0;
            MaxLineCount = 300;
            LogDisplay = new Queue<string>();
        }
        //----------------------------------------------------------------------
        //NAME: Logger_FormClosing
        //Dont close form, just hide it - The main window will destroy it
        //----------------------------------------------------------------------
        private void Logger_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }
        //----------------------------------------------------------------------
        //PROPERTY: Title
        //Set the title string - will get modified if file open
        //----------------------------------------------------------------------
        public string Title
        {
            set
            {
                MyTitle = value;
                this.Text = MyTitle + " * Not Saved *";
            }
        }
        //----------------------------------------------------------------------
        //NAME: OpenFile
        //get a file to record stuff here
        //update title to show where it is going
        //----------------------------------------------------------------------
        public void OpenFile()
        {
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.InitialDirectory = LogFolder;
            SFD.Title = MyTitle + " Open File";
            SFD.FileName = MyTitle + DateTime.Now.ToString("yyyMMdd") + ".txt";
            if (SFD.ShowDialog() == DialogResult.OK)
            {
                PathName = SFD.FileName;
                Start(PathName);
            }
            else
            {
                PathName = "";
            }
        }
        //----------------------------------------------------------------------
        //NAME: Start
        //start the disk log, open the file
        //----------------------------------------------------------------------
        public void Start(string FName)
        {
            PathName = FName;
            try
            {
                LogFile = new StreamWriter(PathName);
                LogFile.AutoFlush = true;
                LogEnabled = true;
                this.Text = MyTitle + " = " + FName;
            }
            catch
            {
            }
        }
        //----------------------------------------------------------------------
        //NAME: Stop
        //stop the disk log, close the file
        //----------------------------------------------------------------------
        public void Stop()
        {
            try
            {
                //DisplayEnabled = false;
                LogEnabled = false;
                LogFile.Close();
                this.Text = MyTitle + " * Not Saved *";
            }
            catch
            {
            }
        }
        //----------------------------------------------------------------------
        //NAME: UpdateDisplay
        //this should be called every 100 msc - a timer is needed in main form
        //----------------------------------------------------------------------
        public void UpdateDisplay()
        {
            string Tstr = "";
            if (DisplayEnabled )
            {
                //-- update the log display from the transient queue
                while (LogDisplay.Count > 0)
                {
                    lock (LogDisplay)
                    {
                        Tstr = LogDisplay.Dequeue();
                    }
                    DisplayLogLine(Tstr);
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: DisplayLogLine
        //put a new line of text in the log window - check for display enabled first
        //----------------------------------------------------------------------
        public void DisplayLogLine(string msg)
        {
            string[] ATemp;
            string[] BTemp;

            if (LogLineCount > MaxLineCount)
            {
                //remove some lines - 5 each time to reduce calls
                //really fast logging can get count out of sync
                //fix to LogLineCount tries to fix this
                ATemp = txbText.Lines;
                if (ATemp.Length > 50)
                {
                    BTemp = new string[ATemp.Length - 5];
                    Array.Copy(ATemp, 4, BTemp, 0, BTemp.Length);
                    txbText.Lines = BTemp;
                    txbText.AppendText("\r\n");
                    LogLineCount = BTemp.Length;
                }
                else
                {
                    LogLineCount = ATemp.Length;
                }
            }
            txbText.AppendText(msg + "\r\n");
            LogLineCount++;
        }
        //----------------------------------------------------------------------
        //NAME: WriteLog
        //encapsulate the text and the log write
        //----------------------------------------------------------------------
        public void WriteLog(string Msg)
        {
            string Tsr;
            //-- need to be options
            // nothing, time, date and time,
            //Tsr = DateTime.Now.ToLongTimeString();  //time only
            Tsr = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToLongTimeString();
            Tsr = Tsr + " : " + Msg;

            if (LogEnabled)
            {
                LogFile.WriteLine(Tsr);
            }
            if (DisplayEnabled)
            {
                //if(LogDisplay .Count > 300)
                lock (LogDisplay)
                {
                    LogDisplay.Enqueue(Tsr);
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnNotes_Click
        //write the notes to the log 
        //----------------------------------------------------------------------
        private void btnNotes_Click(object sender, EventArgs e)
        {
            int jj = 0;
            string[] ATemp;
            ATemp = txbNotes.Lines;

            for (jj = 0; jj < ATemp.Length; jj++)
            {
                WriteLog(ATemp[jj]);
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnClear_Click
        //clear the notes box
        //----------------------------------------------------------------------
        private void btnClear_Click(object sender, EventArgs e)
        {
            txbNotes.Clear();
        }
    }
}
