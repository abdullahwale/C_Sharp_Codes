//------------------------------------------------------------------------------
//
//FILE: Settings.cs
//
//DESCRIPTION: This file has methods that provide settings menu actions
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Form1
    //--------------------------------------------------------------------------
    public partial class Form1 : Form
    {
        //----------------------------------------------------------------------
        //NAME: mnuSelectLibrary_Click
        //select a new root library
        //----------------------------------------------------------------------
        private void mnuSelectLibrary_Click(object sender, EventArgs e)
        {
            DirectorySelectDlg DSD = new DirectorySelectDlg();
            DSD.NewBackColor = Color.SkyBlue;
            DSD.MyTitle = "Select Root Library Directory";
            if (DSD.ShowDialog() == DialogResult.OK)
            {
                string stx = DSD.SelectedDirectory.Trim();
                if (stx.Length < 2)
                {
                    MessageBox.Show("Library Set to Default", Gbls.ProgTitle,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Gbls.UsbRoot = true;
                }
                else
                {
                    if (!Directory.Exists(stx))
                    {
                        MessageBox.Show("Directory Not Found", Gbls.ProgTitle,
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    Gbls.UsbRoot = false;
                    lxbItem.Items.Clear();
                    txtDisplay.Text = "";
                    Gbls.RootFolder = DSD.SelectedDirectory;
                    //need to rebuild the list boxes for new library
                    PopulateTv();
                    NoSelect = true;
                }
                WriteConfig();
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuAutoClip_Click
        //copy snip body to clipboard when selected
        //----------------------------------------------------------------------
        private void mnuAutoClip_Click(object sender, EventArgs e)
        {
            Gbls.AutoClipboard = !Gbls.AutoClipboard;
            if (Gbls.AutoClipboard)
            {
                mnuAutoClip.Text = "Auto Clip Copy Off";
            }
            else
            {
                mnuAutoClip.Text = "Auto Clip Copy On";
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuEditorSettings_Click
        //change the editor settings
        //----------------------------------------------------------------------
        private void mnuEditorSettings_Click(object sender, EventArgs e)
        {
            EditSettingDlg ESD = new EditSettingDlg();
            ESD.SetMargin = Gbls.TextMargin;
            ESD.SetTab = Gbls.TabSize;

            if (ESD.ShowDialog() == DialogResult.OK)
            {
                Gbls.TextMargin = ESD.SetMargin;
                Gbls.TabSize = ESD.SetTab;
                WriteConfig();
            }
        }
    }
}
