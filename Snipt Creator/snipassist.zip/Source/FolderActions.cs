//------------------------------------------------------------------------------
//
//FILE: FolderActions.cs
//
//DESCRIPTION: This file has methods that go things with folders
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Form1
    //--------------------------------------------------------------------------
    public partial class Form1 : Form
    {
        //----------------------------------------------------------------------
        //NAME: mnuAddCategory_Click
        //Add a new category folder with a blank CatDescription.txt
        //----------------------------------------------------------------------
        private void mnuAddCategory_Click(object sender, EventArgs e)
        {
            NewFolderDlg NCD = new NewFolderDlg();
            NCD.WorkTree = Util.CloneTreeView(tvSelect);

            if (NCD.ShowDialog() == DialogResult.OK)
            {
                PopulateTv();
                //should select the new category
                FindAction(NCD.MyFolder);
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuDeleteFolder_Click
        //delete a folder or a whole tree and the files in them
        //----------------------------------------------------------------------
        private void mnuDeleteFolder_Click(object sender, EventArgs e)
        {
            if (CheckNoFolderSelect()) return;

            //do confirm dialog
            string MyPath = Gbls.RootFolder + "\\" + CurrentFolder;
            string[] Subdirs = Directory.GetDirectories(MyPath);
            string[] MyFiles = Directory.GetFiles(MyPath,"*.snp");

            if ((Subdirs.Length > 0) || (MyFiles.Length>0))
            {
                if (MessageBox.Show("Are you sure you want to delete this folder\r\n"
                        + "and the subfolders?", Gbls.ProgTitle,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    Directory.Delete(MyPath, true);
                    PopulateTv();
                }
            }
            else
            {
                if (MessageBox.Show("Are you sure you want to delete this folder?", Gbls.ProgTitle,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    Directory.Delete(MyPath,true);
                    Application.DoEvents();
                    PopulateTv();
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuRenameFolder_Click
        //Rename the CatDescription.txt to FolderDescription.txt
        //----------------------------------------------------------------------
        private void mnuRenameFolder_Click(object sender, EventArgs e)
        {
            if (CheckNoFolderSelect()) return;

            MoveRenameDlg MRD = new MoveRenameDlg();
            MRD.Setup("Rename Folder", "Folder");
            MRD.Action = 'R';
            MRD.StartPath = CurrentFolder;
            MRD.WorkTree = Util.CloneTreeView(tvSelect);

            if (MRD.ShowDialog() == DialogResult.OK)
            {
                string SrcPath = Gbls.RootFolder + "\\" + CurrentFolder;

                string OldPath = Gbls.RootFolder + "\\" + CurrentFolder;
                int ndx = OldPath.LastIndexOf('\\');
                OldPath = OldPath.Substring(0, ndx);
                string DestPath = OldPath + "\\" + MRD.DestPath;
                
                if (SrcPath == DestPath) return;    //nothing to do
                //if new name exists, ask if overwrite or copy
                if (CheckOverWriteFile(DestPath))
                {
                    Directory.Move(SrcPath, DestPath);
                    Application.DoEvents();
                    PopulateTv();
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuEditCatDesc_Click
        //edit or create a Description.txt file
        //----------------------------------------------------------------------
        private void mnuEditCatDesc_Click(object sender, EventArgs e)
        {
            if (CheckNoFolderSelect()) return;

            if (CurntNode != null)
            {
                EditorDlg ED = new EditorDlg();
                CurrentFolder = CurntNode.FullPath;
                string Fname = Gbls.RootFolder + "\\" + CurrentFolder + "\\Description.txt";
                FileInfo FI = new FileInfo(Fname);
                if (FI.Exists)
                {
                    string txx = "";
                    txx = Util.GetTextFile(Fname);
                    ED.MyText = txx;
                }
                else
                {
                    ED.MyText = "";
                }
                ED.MyTitle = "Edit Folder Description - " + Gbls.ProgTitle;
                if (ED.ShowDialog() == DialogResult.OK)
                {
                    //save the edited file
                    Util.PutTextFile(Fname, ED.MyText);
                    //change the folder description
                    if (NoSelect)
                    {
                        //DescDisplay.Text = "CurrentFolder Description";
                        DescDisplay.Text = ED.MyText;
                    }
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: CheckOverWriteFolder
        // true if write is OK
        //$$not used
        //----------------------------------------------------------------------
        public bool CheckOverWriteFolder(string NewPath)
        {
            bool Result = false;
            if (File.Exists(NewPath))
            {
                //strip the library path before sending message
                string ShowName = NewPath.Substring(Gbls.RootFolder.Length + 1);
                if (MessageBox.Show("Are you sure you want to overwrite?\r\n" + ShowName,
                        Gbls.ProgTitle,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    Result = true;
                }
            }
            else
            {
                Result = true;
            }
            return Result;
        }
    }
}
