//------------------------------------------------------------------------------
//
//FILE: TreeHelpDlg.cs
//
//DESCRIPTION: This dialog will display a TreeDoc file as read only
// This dialog has features to make it more useful as a Help window
// For TreeDoc editor see PineTreeJoe.com
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: TreeDocTextDlg
    //--------------------------------------------------------------------------
    public partial class TreeHelpDlg : Form
    {
        //---- public stuff
        public string FileName = "";
        public string Title = "";
        public Color MyColor = Color.LightBlue;     //Color.PaleGreen;
        //---- private stuff
        string LookFor = "";
        TreeNode CurntNode;
        HelpTreeDocCls Document;
        string NodeEnd = "------$$$$$$------node end------$$$$$$";
        //----------------------------------------------------------------------
        //NAME: TreeDocTextDlg
        //init the dialog
        //----------------------------------------------------------------------
        public TreeHelpDlg()
        {
            InitializeComponent();
            Document = new HelpTreeDocCls();
            CurntNode = new TreeNode();
        }
        //----------------------------------------------------------------------
        //NAME: TreeHelpDlg_Shown
        //init the dialog
        //----------------------------------------------------------------------
        private void TreeHelpDlg_Shown(object sender, EventArgs e)
        {
            //build index for ListView from tvNavigate
            ContextMenuStrip CMS = new ContextMenuStrip();
            CMS.Visible = false;
            txbMainText.ContextMenuStrip = CMS;
            cmbxSearch.ContextMenuStrip = CMS;

            foreach (TreeNode TN in tvNavigate.Nodes)
            {
                GetListItem(TN);
            }
            tvNavigate.SelectedNode = tvNavigate.Nodes[0];
            CurntNode = tvNavigate.SelectedNode;

            menuStrip2.BackColor = MyColor;
            menuStrip3.BackColor = MyColor;
            tabPage1.BackColor = MyColor;
            tabPage2.BackColor = MyColor;
            tabPage3.BackColor = MyColor;
            HelpTextDisplay.BackColor = MyColor;
            navigeteToolStripMenuItem.BackColor = MyColor;       
        }
        //----------------------------------------------------------------------
        //NAME: GetListItem
        //get a list item from the tree - recursive
        //----------------------------------------------------------------------
        void GetListItem(TreeNode TN)
        {
            ListViewItem LSI = new ListViewItem(TN.Text.Trim());
            LSI.SubItems.Add(TN.FullPath);
            lsvIndexList.Items.Add(LSI);

            foreach (TreeNode CTN in TN.Nodes)
            {
                GetListItem(CTN);
            }
        }
        //----------------------------------------------------------------------
        //NAME: lsvIndexList_SelectedIndexChanged
        //
        //----------------------------------------------------------------------
        private void lsvIndexList_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListView.SelectedIndexCollection SIC = lsvIndexList.SelectedIndices;
            if (SIC.Count > 0)
            {
                int ndx = SIC[0];
                ListViewItem LSI = lsvIndexList.Items[ndx];
                //txbIndexText.Text = LSI.Text;
                string MyPath = LSI.SubItems[1].Text;
                FindAction(MyPath);
            }
        }
        //----------------------------------------------------------------------
        //NAME: FindAction
        //this is called to get a specific node displayed
        //----------------------------------------------------------------------
        public void FindAction(string NodePath)
        {
            string[] PathNodes = NodePath.Split('\\');

            if (CurntNode != null)
            {
                CurntNode.BackColor = Color.Empty;
            }

            try
            {
                tvNavigate.CollapseAll();   //clean things up
                TreeNode TN = tvNavigate.Nodes[PathNodes[0]];
                tvNavigate.SelectedNode = TN;
                TreeNode Tnx;

                int jj = 0;
                for (jj = 1; jj < PathNodes.Length; jj++)
                {
                    Tnx = new TreeNode();
                    Tnx = TN.Nodes[PathNodes[jj]];
                    TN = Tnx;
                    tvNavigate.SelectedNode = TN;
                }
                //now show what was selected
                TN = tvNavigate.SelectedNode;
                CurntNode = TN;
                if (CurntNode != null)
                {
                    int ThisNodeID = (int)CurntNode.Tag;
                    HelpTreeNode TDN = Document.Nodes[ThisNodeID];
                    txbMainText.Text = TDN.Text;
                    HelpTextDisplay.Text = TN.Text;
                    TN.BackColor = Color.LightBlue;
                    TN.EnsureVisible();
                }
                else
                {
                    Gbls.LG.WriteLog("node not found");
                }
            }
            catch (Exception ex)
            {
                Gbls.LG.WriteLog("Exception: " + ex.ToString());
            }
        }
        //----------------------------------------------------------------------
        //NAME: tvNavigate_AfterSelect
        //a new node was selected
        //----------------------------------------------------------------------
        private void tvNavigate_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (CurntNode != null)
            {
                CurntNode.BackColor = Color.Empty;
            }
            TreeNode TN = tvNavigate.SelectedNode;
            CurntNode = TN;
            if (CurntNode != null)
            {
                int ThisNodeID = (int)CurntNode.Tag;
                HelpTreeNode TDN = Document.Nodes[ThisNodeID];
                txbMainText.Text = TDN.Text;
                HelpTextDisplay.Text = TN.Text;
            }
            TN.BackColor = Color.LightBlue;
        }
        //----------------------------------------------------------------------
        //NAME: ReadTreeDocFile
        //read a TreeDoc file into the TreeDoc program
        //----------------------------------------------------------------------
        public bool ReadTreeDocFile(string RawText)
        {
            bool OK = true;
            string Linin = "";
            StringReader SR = new StringReader(RawText);

            Linin = SR.ReadLine();
            //check for start and abort if not correct
            if (!Linin.StartsWith("<version "))
            {
                return false;
            }
            txbMainText.Text = "";
            tvNavigate.Nodes.Clear();
            Document = new HelpTreeDocCls();
            Linin = SR.ReadLine();

            while (Linin != null)
            {
                if (Linin.StartsWith("<end>")) break; //all done
                if (Linin.StartsWith("<text>"))
                {
                    //extract node path
                    string NodePath = Linin.Substring(6).Trim();
                    TreeNode TN = MakeTreeNode(NodePath, tvNavigate);
                    int NodeId = Document.AddNode("MyName");
                    TN.Tag = NodeId;
                    HelpTreeNode TDN = Document.Nodes[NodeId];
                    //grab lines until Gbls.NodeEnd
                    Linin = SR.ReadLine();
                    StringBuilder SB = new StringBuilder();
                    while (!Linin.StartsWith(NodeEnd))
                    {
                        //add text to node text
                        SB.AppendLine(Linin);
                        Linin = SR.ReadLine();
                    }
                    TDN.Text = SB.ToString();
                }
                Linin = SR.ReadLine();
            }
            return OK;
        }
        //----------------------------------------------------------------------
        //NAME: cmbxSearch_SelectedIndexChanged
        //search for the item in the search combobox
        //----------------------------------------------------------------------
        private void cmbxSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            LookFor = cmbxSearch.Text;

            foreach (TreeNode TN in tvNavigate.Nodes)
            {
                Search_Node(TN);
            }
        }
        //----------------------------------------------------------------------
        //NAME: Search_Node
        //search for the item in the search combobox
        //----------------------------------------------------------------------
        void Search_Node(TreeNode TN)
        {
            bool Found = false;
            StringComparison ScType = StringComparison.Ordinal;
            if (chkNoCase.Checked)
            {
                ScType = StringComparison.OrdinalIgnoreCase;
            }

            if (chkLookLabel.Checked)
            {
                if(TN.Text.IndexOf(LookFor,ScType) >= 0)
                {
                    Found = true;
                }                
            }
            if (chkLookText.Checked)
            {
                int ThisNodeID = (int)TN.Tag;
                HelpTreeNode TDN = Document.Nodes[ThisNodeID];
                if (TDN.Text.IndexOf(LookFor, ScType) >= 0)
                {
                    Found = true;
                }
            }
            if(Found)
            {
                ListViewItem LSI = new ListViewItem(TN.Text.Trim());
                LSI.SubItems.Add(TN.FullPath);
                lsvSearch.Items.Add(LSI);
            }
            foreach (TreeNode CTN in TN.Nodes)
            {
                Search_Node(CTN);
            }
        }
        //----------------------------------------------------------------------
        //NAME: lsvSearch_SelectedIndexChanged
        //
        //----------------------------------------------------------------------
        private void lsvSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListView.SelectedIndexCollection SIC = lsvSearch.SelectedIndices;
            if (SIC.Count > 0)
            {
                int ndx = SIC[0];
                ListViewItem LSI = lsvSearch.Items[ndx];
                string MyPath = LSI.SubItems[1].Text;
                FindAction(MyPath);
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnSearch_Click
        //start the search
        //----------------------------------------------------------------------
        private void btnSearch_Click(object sender, EventArgs e)
        {
            LookFor = cmbxSearch.Text;
            lsvSearch.Items.Clear();

            foreach (TreeNode TN in tvNavigate.Nodes)
            {
                Search_Node(TN);
            }
            //if any found, show first found
            if (lsvSearch.Items.Count <= 0)
            {
                MessageBox.Show("Search Complete - Nothing found", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        //----------------------------------------------------------------------
        //NAME: MakeTreeNode
        //Make the node in the tree that has the full path
        //----------------------------------------------------------------------
        public TreeNode MakeTreeNode(string FullPath, TreeView MyTree)
        {
            TreeNode TN;        //first or parent node
            TreeNode CTN;       //new or child node
            string[] Parts = FullPath.Split('\\');
            int jj;

            if (MyTree.Nodes.ContainsKey(Parts[0]))
            {
                TN = MyTree.Nodes[Parts[0]];
            }
            else
            {
                TN = new TreeNode(Parts[0]);
                TN.Name = Parts[0];
                MyTree.Nodes.Add(TN);
            }

            for (jj = 1; jj < Parts.Length; jj++)
            {
                if (TN.Nodes.ContainsKey(Parts[jj]))
                {
                    TN = TN.Nodes[Parts[jj]];
                }
                else
                {
                    CTN = new TreeNode(Parts[jj]);
                    CTN.Name = Parts[jj];
                    TN.Nodes.Add(CTN);
                    TN = CTN;
                }
            }
            return TN;
        }
        //--------------------------------------------------------------------------
        //CLASS: HelpTreeDocCls
        //This is the same as TreeDocCls but is renamed so the dialog is more 
        // independent. The parts need to be compatible so the file s can be used.     
        //--------------------------------------------------------------------------
        public class HelpTreeDocCls
        {
            public string SavePath = "";
            public Dictionary<int, HelpTreeNode> Nodes = new Dictionary<int, HelpTreeNode>();
            public int NextID = 1;          //only increments, never dec
            //----------------------------------------------------------------------
            //NAME: HelpTreeDocCls
            //create the class
            //----------------------------------------------------------------------
            public HelpTreeDocCls()
            {
            }
            //----------------------------------------------------------------------
            //NAME: AddNode
            //read the raw text and make it into a TreeDoc
            //----------------------------------------------------------------------
            public int AddNode(string NodeTitle)
            {
                HelpTreeNode TDN = new HelpTreeNode();
                TDN.ID = NextID;
                NextID++;
                TDN.Text = "";
                Nodes.Add(TDN.ID, TDN);
                return TDN.ID;
            }
        }
        //--------------------------------------------------------------------------
        //CLASS: HelpTreeDocNode
        //This is compatible with TreeDocNode. An explicit constructor is not needed
        //--------------------------------------------------------------------------
        public class HelpTreeNode
        {
            public int ID;
            public string Text = "";
        }
        //----------------------------------------------------------------------
        //NAME: tvNavigate_MouseDown
        //allow right mouse click to select node
        //----------------------------------------------------------------------
        private void tvNavigate_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                TreeNode MyTn = tvNavigate.GetNodeAt(e.Location);
                if (MyTn != null)
                {
                    tvNavigate.SelectedNode = MyTn;
                }
            }
        }
    }
}