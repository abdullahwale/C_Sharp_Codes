namespace Bartel
{
    partial class FindDlg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txbFindWhat = new System.Windows.Forms.TextBox();
            this.gbxOptions = new System.Windows.Forms.GroupBox();
            this.rbStartCurrent = new System.Windows.Forms.RadioButton();
            this.rbStartBegin = new System.Windows.Forms.RadioButton();
            this.chkWholeWord = new System.Windows.Forms.CheckBox();
            this.chkIgnoreCase = new System.Windows.Forms.CheckBox();
            this.gbxOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(175, 116);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "Find Next";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(281, 116);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Find What:";
            // 
            // txbFindWhat
            // 
            this.txbFindWhat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txbFindWhat.Location = new System.Drawing.Point(12, 19);
            this.txbFindWhat.Name = "txbFindWhat";
            this.txbFindWhat.Size = new System.Drawing.Size(355, 20);
            this.txbFindWhat.TabIndex = 3;
            // 
            // gbxOptions
            // 
            this.gbxOptions.Controls.Add(this.rbStartCurrent);
            this.gbxOptions.Controls.Add(this.rbStartBegin);
            this.gbxOptions.Controls.Add(this.chkWholeWord);
            this.gbxOptions.Controls.Add(this.chkIgnoreCase);
            this.gbxOptions.Location = new System.Drawing.Point(12, 42);
            this.gbxOptions.Name = "gbxOptions";
            this.gbxOptions.Size = new System.Drawing.Size(355, 68);
            this.gbxOptions.TabIndex = 4;
            this.gbxOptions.TabStop = false;
            this.gbxOptions.Text = "Find Options";
            // 
            // rbStartCurrent
            // 
            this.rbStartCurrent.AutoSize = true;
            this.rbStartCurrent.Location = new System.Drawing.Point(184, 42);
            this.rbStartCurrent.Name = "rbStartCurrent";
            this.rbStartCurrent.Size = new System.Drawing.Size(141, 17);
            this.rbStartCurrent.TabIndex = 3;
            this.rbStartCurrent.TabStop = true;
            this.rbStartCurrent.Text = "Start At Current Location";
            this.rbStartCurrent.UseVisualStyleBackColor = true;
            // 
            // rbStartBegin
            // 
            this.rbStartBegin.AutoSize = true;
            this.rbStartBegin.Location = new System.Drawing.Point(184, 19);
            this.rbStartBegin.Name = "rbStartBegin";
            this.rbStartBegin.Size = new System.Drawing.Size(110, 17);
            this.rbStartBegin.TabIndex = 2;
            this.rbStartBegin.TabStop = true;
            this.rbStartBegin.Text = "Start At Beginning";
            this.rbStartBegin.UseVisualStyleBackColor = true;
            // 
            // chkWholeWord
            // 
            this.chkWholeWord.AutoSize = true;
            this.chkWholeWord.Location = new System.Drawing.Point(13, 42);
            this.chkWholeWord.Name = "chkWholeWord";
            this.chkWholeWord.Size = new System.Drawing.Size(86, 17);
            this.chkWholeWord.TabIndex = 1;
            this.chkWholeWord.Text = "Whole Word";
            this.chkWholeWord.UseVisualStyleBackColor = true;
            this.chkWholeWord.Visible = false;
            // 
            // chkIgnoreCase
            // 
            this.chkIgnoreCase.AutoSize = true;
            this.chkIgnoreCase.Location = new System.Drawing.Point(12, 19);
            this.chkIgnoreCase.Name = "chkIgnoreCase";
            this.chkIgnoreCase.Size = new System.Drawing.Size(83, 17);
            this.chkIgnoreCase.TabIndex = 0;
            this.chkIgnoreCase.Text = "Ignore Case";
            this.chkIgnoreCase.UseVisualStyleBackColor = true;
            // 
            // FindDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(379, 143);
            this.ControlBox = false;
            this.Controls.Add(this.gbxOptions);
            this.Controls.Add(this.txbFindWhat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Name = "FindDlg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Find Dialog";
            this.Shown += new System.EventHandler(this.FindDlg_Shown);
            this.gbxOptions.ResumeLayout(false);
            this.gbxOptions.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbFindWhat;
        private System.Windows.Forms.GroupBox gbxOptions;
        private System.Windows.Forms.CheckBox chkWholeWord;
        private System.Windows.Forms.CheckBox chkIgnoreCase;
        private System.Windows.Forms.RadioButton rbStartCurrent;
        private System.Windows.Forms.RadioButton rbStartBegin;
    }
}