//------------------------------------------------------------------------------
//
//FILE: JoesJsonWriter.cs
//
//DESCRIPTION: This file has definition of JoesJsonWriter. This is a specialised
// class for reading and writing JSON. The write part has some extras to make
// things easy. The reader might not be able to read everything the writer can write.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: JoesJsonWriter
    //--------------------------------------------------------------------------
    public class JoesJsonWriter
    {
        public StringBuilder JsonBuild;
        public int IndentCnt = 0;
        public string IndentStr = "";

        //----------------------------------------------------------------------
        //NAME: JoesJsonWriter
        //Initialize the writer to an empty string
        //----------------------------------------------------------------------
        public JoesJsonWriter()
        {
            JsonBuild = new StringBuilder();
        }
        //----------------------------------------------------------------------
        //NAME: StartWrite
        //start a new JSON document
        //----------------------------------------------------------------------
        public void StartWrite()
        {
            JsonBuild = new StringBuilder();
        }
        //----------------------------------------------------------------------
        //NAME: GetText
        //get the JSON document so it can be sent or stored
        //----------------------------------------------------------------------
        public string GetText()
        {
            string Result = JsonBuild.ToString();

            return Result;
        }
        //----------------------------------------------------------------------
        //NAME: Comment
        //write a JSON comment
        //----------------------------------------------------------------------
        public void Comment(string Text)
        {
            JsonBuild.Append("// " + Text);
        }
        //----------------------------------------------------------------------
        //NAME: CommentLine
        //write a JSON comment - on a line all its own
        //----------------------------------------------------------------------
        public void CommentLine(string Text)
        {
            JsonBuild.AppendLine();
            JsonBuild.Append("// " + Text);
        }
        //----------------------------------------------------------------------
        //NAME: Write
        //write a name and a string value
        //----------------------------------------------------------------------
        public void Write(string name, string value)
        {
            JsonBuild.Append("\"" + name + "\" : ");
            JsonBuild.Append("\"" + EscapeString(value) + "\"");
        }
        //----------------------------------------------------------------------
        //NAME: Write
        //write a name and a list as an array
        //----------------------------------------------------------------------
        public void Write(string name, List<string> value)
        {
            bool First = true;
            JsonBuild.Append("\"" + name + "\" : [");
            foreach (string stx in value)
            {
                if (First)
                {
                    JsonBuild.Append("\"" + EscapeString(stx) + "\"");
                    First = false;
                }
                else
                {
                    JsonBuild.Append(",\"" + EscapeString(stx) + "\"");
                }
            }
            JsonBuild.Append("]");
        }
        //----------------------------------------------------------------------
        //NAME: Write
        //write a name and a boolean value
        //----------------------------------------------------------------------
        public void Write(string name, bool value)
        {
            JsonBuild.Append("\"" + name + "\" : ");
            if (value)
            {
                JsonBuild.AppendLine(" true}");
            }
            else
            {
                JsonBuild.AppendLine(" false}");
            }
        }
        //----------------------------------------------------------------------
        //NAME: Write
        //write a name and a int value
        //----------------------------------------------------------------------
        public void Write(string name, int value)
        {
            JsonBuild.AppendLine("\"" + name + "\" : " + value.ToString() + "}");
        }
        //----------------------------------------------------------------------
        //NAME: WriteSeparater
        //----------------------------------------------------------------------
        public void WriteSeparater()
        {
            JsonBuild.Append(",");
        }
        //----------------------------------------------------------------------
        //NAME: StartNewLine
        //----------------------------------------------------------------------
        public void StartNewLine()
        {
            JsonBuild.AppendLine("");
        }
        //----------------------------------------------------------------------
        //NAME: WriteObject
        // {"RootFolder" : "C:\\BartelTools\\SnipManager"}
        //----------------------------------------------------------------------
        public void WriteObject(string name, string value)
        {
            JsonBuild.AppendLine();
            JsonBuild.Append("{ \"" + name + "\" : ");
            JsonBuild.Append("\"" + EscapeString(value) + "\" }");
        }
        //----------------------------------------------------------------------
        //NAME: WriteObject
        // {"NoLook" : ["zzz", "xxx", "yyy"]}
        //----------------------------------------------------------------------
        public void WriteObject(string name, List<string> value)
        {
            bool First = true;
            JsonBuild.AppendLine();
            JsonBuild.Append("{ \"" + name + "\" : [");
            foreach (string stx in value)
            {
                if (First)
                {
                    JsonBuild.Append("\"" + EscapeString(stx) + "\"");
                    First = false;
                }
                else
                {
                    JsonBuild.Append(",\"" + EscapeString(stx) + "\"");
                }
            }
            JsonBuild.Append("]}");
        }
        //----------------------------------------------------------------------
        //NAME: EscapeString
        //----------------------------------------------------------------------
        string EscapeString(string SrcStr)
        {
            char[] Escape = { '"', '\\', '/', '\b', '\f', '\n', '\r', '\t' };
            List<char> EscapeList = new List<char>();
            EscapeList.AddRange(Escape);
            StringBuilder MySb = new StringBuilder();
            int jj;

            for (jj = 0; jj < SrcStr.Length; jj++)
            {
                if (EscapeList.Contains(SrcStr[jj]))
                {
                    MySb.Append('\\');
                }
                MySb.Append(SrcStr[jj]);
            }
            return MySb.ToString();
        }
    }
}
