//------------------------------------------------------------------------------
//
//FILE: TextEditor.cs
//
//DESCRIPTION: This is a general purpose editor control based on a TextBox.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: TextEditor
    //--------------------------------------------------------------------------
    public partial class TextEditor : UserControl
    {
        public Char CtlC = (Char)(0x03);
        public Char CtlV = (Char)(0x16);
        public Char CtCr = (Char)(0x0D);
        public Char CtLf = (Char)(0x0A);
        public Char TabChar = (Char)(0x09);

        FindDlg FDD;        //used for find and find next
        ReplaceDlg RPD;     //used by delegate
        public Color MyColor = Color.LightBlue;
        //-- may need these for tabs and line adjust
        //public int TextMargin = 80; -- cannot call it TextMargin
        //public int TabSize = 4;

        //these are the selected lines for special formatting
        string[] SelectedLines = new string[1];
        List<string> SelList = new List<string>();
        int StartLine = 0;      //first selected line
        int EndLine = 0;        //last selected line

        private bool FullKind = true;  //true if full version

        //-- put in info string and fire event, handler gets what it needs
        [Description("Debug event")]
        public event GenericEventHandler Debug;
        public string DebugInfo = "none";

        //----------------------------------------------------------------------
        //NAME: TextEditor
        //Init the editor
        //----------------------------------------------------------------------
        public TextEditor()
        {
            InitializeComponent();
            ContextMenuMgr.SetStrip(txbMainText);
            txbMainText.SelectionLength = 0;
        }
        //----------------------------------------------------------------------
        //NAME: GetTextBox
        //Get the TextBox used
        //----------------------------------------------------------------------
        public TextBox GetTextBox()
        {
            return txbMainText;
        }
        //----------------------------------------------------------------------
        // NAME: MenuColor
        // set the color of the editor
        //----------------------------------------------------------------------
        [Description("Menu Color")]
        public Color MenuColor
        {
            get
            {
                return menuStrip1.BackColor;
            }
            set
            {
                menuStrip1.BackColor = value;
            }
        }
        //----------------------------------------------------------------------
        // NAME: ReadOnly
        // set the editor read only - disable the menu
        //----------------------------------------------------------------------
        [Description("Read Only")]
        public Boolean ReadOnly
        {
            get
            {
                return txbMainText.ReadOnly;
            }
            set
            {
                txbMainText.ReadOnly = value;
                if (value)
                {
                    menuStrip1.Enabled = false;
                    ContextMenuMgr.SetStripRo(txbMainText);
                }
                else
                {
                    menuStrip1.Enabled = true;
                    ContextMenuMgr.SetStrip(txbMainText);
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: OnDebug
        //send a debug string to the form using the control
        //----------------------------------------------------------------------
        protected virtual void OnDebug()
        {
            EventArgs e = new EventArgs();
            if (Debug != null) Debug(this, e);
        }
        //----------------------------------------------------------------------
        //NAME: OnDebug
        //send a debug string to the form using the control
        //----------------------------------------------------------------------
        protected virtual void OnDebug(string InfoText)
        {
            EventArgs e = new EventArgs();
            if (Debug != null)
            {
                DebugInfo = InfoText;
                Debug(this, e);
            }
        }
        //----------------------------------------------------------------------
        //NAME: Edit_KeyPress
        //this is so regular keys will work
        //----------------------------------------------------------------------
        private void txbMainText_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char MyChar = e.KeyChar;
            if (MyChar == TabChar)
            {
                string TabSpace = " ";
                int LineStart = txbMainText.SelectionStart;
                if (txbMainText.SelectionStart == 0)
                {
                    // simple, insert spaces
                    TabSpace = " ".PadRight(Gbls.TabSize);
                    txbMainText.SelectedText = TabSpace;
                    e.Handled = true;
                    return;
                }
                else if (txbMainText.SelectionStart == txbMainText.Text.Length)
                {
                    LineStart--;
                }
                //else {}

                while ((txbMainText.Text[LineStart] != '\n') && (LineStart > 0))
                {
                    LineStart--;
                }
                int LineEnd = txbMainText.Text.IndexOf('\n', LineStart + 1);

                if (LineStart == 0) LineStart = -1;
                if (LineEnd < 0) LineEnd = txbMainText.Text.Length;
                string LinePart = txbMainText.Text.Substring(LineStart + 1, LineEnd - LineStart - 1);
                int CarPos = txbMainText.SelectionStart - LineStart - 1;
                int TabMod = CarPos % Gbls.TabSize;
                TabSpace = " ".PadRight(Gbls.TabSize - TabMod);

                txbMainText.SelectedText = TabSpace;
                e.Handled = true;
            }
            else
            {
                int dx = Convert.ToInt32(MyChar);
                e.Handled = false;
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuUndo_Click
        //
        //----------------------------------------------------------------------
        private void mnuUndo_Click(object sender, EventArgs e)
        {
            if (txbMainText.CanUndo)
            {
                txbMainText.Undo();
                txbMainText.ClearUndo();
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuCut_Click
        //
        //----------------------------------------------------------------------
        private void mnuCut_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txbMainText.SelectedText);
            txbMainText.SelectedText = "";
        }
        //----------------------------------------------------------------------
        //NAME: mnuCopy_Click
        //
        //----------------------------------------------------------------------
        private void mnuCopy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txbMainText.SelectedText);
        }
        //----------------------------------------------------------------------
        //NAME: mnuPaste_Click
        //
        //----------------------------------------------------------------------
        private void mnuPaste_Click(object sender, EventArgs e)
        {
            txbMainText.SelectedText = Clipboard.GetText();
        }
        //----------------------------------------------------------------------
        //NAME: mnuDelete_Click
        //
        //----------------------------------------------------------------------
        private void mnuDelete_Click(object sender, EventArgs e)
        {
            txbMainText.SelectedText = "";
        }
        //----------------------------------------------------------------------
        //NAME: mnuGoTo_Click
        //
        //----------------------------------------------------------------------
        private void mnuGoTo_Click(object sender, EventArgs e)
        {
            string Prompt = "Go To Line Number ( " + txbMainText.Lines.Length.ToString() + " )";
            EzInput.BackGround = MyColor;
            EzInput.Width = 232;    //guess
            int LineNum = EzInput.GetInt(Gbls.ProgTitle, Prompt);
            if (LineNum < txbMainText.Lines.Length)
            {
                int SelNum = 0;
                int jj = 0;
                for (jj = 0; jj < LineNum - 1; jj++)
                {
                    SelNum = SelNum + txbMainText.Lines[jj].Length + 2;
                }
                txbMainText.SelectionStart = SelNum;
                txbMainText.SelectionLength = 0;
                txbMainText.Focus();
                txbMainText.ScrollToCaret();
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuFind_Click
        //
        //----------------------------------------------------------------------
        private void mnuFind_Click(object sender, EventArgs e)
        {
            FDD = new FindDlg();
            FDD.BackColor = MyColor;
            FDD.NextEvent += DoFindAction;

            if (txbMainText.SelectionLength > 0)
            {
                FDD.What = txbMainText.SelectedText;
            }
            FDD.ShowDialog();
        }
        //----------------------------------------------------------------------
        //NAME: FindAction
        //delegate for Find
        //----------------------------------------------------------------------
        private void DoFindAction()
        {
            int FindIndex = 0;
            int StartIndex = 0;

            if (FDD.StartAtBeginning)
            {
                StartIndex = 0;
            }
            else
            {
                StartIndex = txbMainText.SelectionStart + txbMainText.SelectionLength;
            }

            if (FDD.IgnoreCase)
            {
                FindIndex = txbMainText.Text.IndexOf(FDD.What, StartIndex, StringComparison.CurrentCultureIgnoreCase);
            }
            else
            {
                FindIndex = txbMainText.Text.IndexOf(FDD.What, StartIndex);
            }

            if (FindIndex >= 0)
            {
                txbMainText.SelectionStart = FindIndex;
                txbMainText.SelectionLength = FDD.What.Length;
                txbMainText.Focus();
                txbMainText.ScrollToCaret();
            }
            else
            {
                MessageBox.Show("Nothing Found", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                FDD.ExitNow = true;
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuReplace_Click
        //
        //----------------------------------------------------------------------
        private void mnuReplace_Click(object sender, EventArgs e)
        {
            RPD = new ReplaceDlg();
            RPD.NextEvent += DoNextEvent;
            RPD.ReplaceEvent += DoReplaceEvent;

            if (txbMainText.SelectionLength > 0)
            {
                RPD.What = txbMainText.SelectedText;
            }
            RPD.BackColor = MyColor;
            RPD.ShowDialog();
        }
        //----------------------------------------------------------------------
        //NAME: DoNextEvent
        //find next occurance of string for replace dialog
        //----------------------------------------------------------------------
        private void DoNextEvent()
        {
            int FindIndex = 0;
            int StartIndex = 0;
            if (RPD.StartAtBeginning)
            {
                StartIndex = 0;
            }
            else
            {
                StartIndex = txbMainText.SelectionStart + txbMainText.SelectionLength;
            }

            if (RPD.IgnoreCase)
            {
                FindIndex = txbMainText.Text.IndexOf(RPD.What, StartIndex, StringComparison.CurrentCultureIgnoreCase);
            }
            else
            {
                FindIndex = txbMainText.Text.IndexOf(RPD.What, StartIndex);
            }

            if (FindIndex >= 0)
            {
                txbMainText.SelectionStart = FindIndex;
                txbMainText.SelectionLength = RPD.What.Length;
                txbMainText.Focus();
                txbMainText.ScrollToCaret();
            }
            else
            {
                MessageBox.Show("Nothing Found", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                RPD.ExitNow = true;
            }
        }
        //----------------------------------------------------------------------
        //NAME: DoReplaceEvent
        //do actual replacement for replace dialog
        //----------------------------------------------------------------------
        private void DoReplaceEvent()
        {
            txbMainText.SelectedText = RPD.Replacement;
        }
        //----------------------------------------------------------------------
        //NAME: mnuDate_Click
        //
        //----------------------------------------------------------------------
        private void mnuDate_Click(object sender, EventArgs e)
        {
            List<string> ToDay = Util.MakeDateList();
            string[] Dates = ToDay.ToArray();
            ListSelectDlg LSD = new ListSelectDlg();
            LSD.Setup("Todays Date");
            LSD.MyItems = Dates;
            if (LSD.ShowDialog() == DialogResult.OK)
            {
                txbMainText.SelectedText = LSD.SelectedItem;
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuTime_Click
        //
        //----------------------------------------------------------------------
        private void mnuTime_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Feature Not Implemented", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        //----------------------------------------------------------------------
        //NAME: mnuWordWrap_Click
        //
        //----------------------------------------------------------------------
        private void mnuWordWrap_Click(object sender, EventArgs e)
        {
            txbMainText.WordWrap = !txbMainText.WordWrap;
        }
        //----------------------------------------------------------------------
        //NAME: mnuAdjust_Click
        //
        //----------------------------------------------------------------------
        private void mnuAdjust_Click(object sender, EventArgs e)
        {
            if (txbMainText.SelectionLength == 0)
            {
                return;
            }
            int SelNum = 0;
            int jj = 0;
            while (SelNum <= txbMainText.SelectionStart)
            {
                SelNum = SelNum + txbMainText.Lines[jj].Length + 2;
                jj++;
            }
            jj--;
            if (SelNum > txbMainText.SelectionStart)
            {
                SelNum = SelNum - txbMainText.Lines[jj].Length - 2;
            }
            int SelSize = 0;
            jj = 0;
            while (SelSize < txbMainText.SelectionStart + txbMainText.SelectionLength)
            {
                SelSize = SelSize + txbMainText.Lines[jj].Length + 2;
                jj++;
            }
            //-- set textbox selection
            txbMainText.SelectionStart = SelNum;
            txbMainText.SelectionLength = SelSize - SelNum;
            //-- get the lines and adjust them
            string TempText = txbMainText.SelectedText;
            List<string> MyLines = Util.MakeParagraphs(TempText);
            List<string> AllLines = new List<string>();
            foreach (string stx in MyLines)
            {
                List<string> TempList = Util.MakeDesc(stx, "", "");
                AllLines.AddRange(TempList);
                AllLines.Add("");
            }
            string EOL = "" + CtCr + CtLf;
            string AdjustedText = String.Join(EOL, AllLines.ToArray());
            txbMainText.Focus();
            txbMainText.SelectedText = AdjustedText;
            txbMainText.ScrollToCaret();
        }
        //----------------------------------------------------------------------
        //NAME: mnuSelectAll_Click
        //
        //----------------------------------------------------------------------
        private void mnuSelectAll_Click(object sender, EventArgs e)
        {
            txbMainText.SelectAll();
        }
        //----------------------------------------------------------------------
        //NAME: mnuClearAll_Click
        //
        //----------------------------------------------------------------------
        private void mnuClearAll_Click(object sender, EventArgs e)
        {
            txbMainText.Text = "";
        }
        //----------------------------------------------------------------------
        //NAME: mnuInsertBlankLines_Click
        //Insert a blank line after each real line. For doc,docx, rtf snips
        //----------------------------------------------------------------------
        private void mnuInsertBlankLines_Click(object sender, EventArgs e)
        {
            string[] RawText = txbMainText.Lines;
            List<string> StuffedText = new List<string>();
            int jj;
            bool notfirst = false;

            for (jj = 0; jj < RawText.Length; jj++)
            {
                if (notfirst)
                {
                    StuffedText.Add("");
                }
                StuffedText.Add(RawText[jj]);
                notfirst = true;
            }
            RawText = StuffedText.ToArray();
            txbMainText.Lines = RawText;
        }
        //----------------------------------------------------------------------
        //NAME: mnuJoinLines_Click
        //join selected lines - text to rtf
        //----------------------------------------------------------------------
        private void mnuJoinLines_Click(object sender, EventArgs e)
        {
            if (txbMainText.SelectionLength == 0)
            {
                return;
            }
            GetSelectedLines();
            SelList = Util.JoinLines(SelList);
            PutSelectedLines();
        }
        //----------------------------------------------------------------------
        //NAME: GetSelectedLines
        //get the selected lines from the textbox
        //----------------------------------------------------------------------
        public void GetSelectedLines()
        {
            if (txbMainText.SelectionLength == 0)
            {
                return;
            }
            StartLine = 0;
            EndLine = 0;
            int EndSelection = txbMainText.SelectionStart + txbMainText.SelectionLength;

            int SelNum = 0;
            while (SelNum <= txbMainText.SelectionStart)
            {
                SelNum = SelNum + txbMainText.Lines[StartLine].Length + 2;
                StartLine++;
            }
            EndLine = StartLine;
            StartLine--;

            if (SelNum > txbMainText.SelectionStart)
            {
                SelNum = SelNum - txbMainText.Lines[StartLine].Length - 2;
            }
            int SelSize = 0;
            EndLine = 0;
            while (SelSize < EndSelection)
            {
                SelSize = SelSize + txbMainText.Lines[EndLine].Length + 2;
                EndLine++;
            }
            //-- set textbox selection
            txbMainText.SelectionStart = SelNum;
            txbMainText.SelectionLength = SelSize - SelNum;

            SelList = new List<string>();
            for (SelNum = StartLine; SelNum < EndLine; SelNum++)
            {
                SelList.Add(txbMainText.Lines[SelNum]);
            }
        }
        //----------------------------------------------------------------------
        //NAME: PutSelectedLines
        //put the selected lines back into the textbox
        //----------------------------------------------------------------------
        public void PutSelectedLines()
        {
            string EOL = "" + CtCr + CtLf;
            string AdjustedText = String.Join(EOL, SelList.ToArray()) + EOL;
            txbMainText.SelectedText = AdjustedText;
            txbMainText.Focus();
            txbMainText.ScrollToCaret();
        }
    }
}
