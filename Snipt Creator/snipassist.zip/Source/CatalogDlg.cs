//------------------------------------------------------------------------------
//
//FILE: CatalogDlg.cs
//
//DESCRIPTION: This is a dialog that collects information about doing a catalog
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: CatalogDlg
    //--------------------------------------------------------------------------
    public partial class CatalogDlg : Form
    {
        public string MyTitle = "CatalogDlg";
        public string StartFolder = "";
        public TreeView WorkTree = null;
        public string ItemType = "Snip";

        public bool DoCatDescription;
        public bool DoItemDescription;
        public bool DoItemBody;
        public bool DoWholeTree;

        public Color MyDark = Color.FromArgb(255, 0, 128, 255);
        public Color MyMedium = Color.FromArgb(255, 80, 168, 255);
        public Color MyLight = Color.FromArgb(255, 185, 220, 255);
        //----------------------------------------------------------------------
        //NAME: CatalogDlg
        //init the dialog
        //----------------------------------------------------------------------
        public CatalogDlg()
        {
            InitializeComponent();
            txbStart.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
            chkItemBody.Text = ItemType + " Body";
            chkItemDescription.Text = ItemType + " Description";
            this.BackColor = MyMedium;
            groupBox1.BackColor = MyLight;
            groupBox2.BackColor = MyLight;
        }
        //----------------------------------------------------------------------
        //NAME: CatalogDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void CatalogDlg_Shown(object sender, EventArgs e)
        {
            txbStart.Text = "";     //StartFolder;
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            DoCatDescription = chkCatDescription.Checked;
            DoItemDescription = chkItemDescription.Checked;
            DoItemBody = chkItemBody.Checked;
            DoWholeTree = rbWholeTree.Checked;
            StartFolder = txbStart.Text;

            DialogResult = DialogResult.OK;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: btnBrowse_Click
        //do a dialog to get the source file or folder
        //----------------------------------------------------------------------
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            TreeSelectDlg TSD = new TreeSelectDlg();
            TSD.CopyTreeView = WorkTree;

            if (TSD.ShowDialog() == DialogResult.OK)
            {
                txbStart.Text = TSD.DirectoryName;
            }
        }
    }
}