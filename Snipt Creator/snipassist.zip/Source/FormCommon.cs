//------------------------------------------------------------------------------
//
//FILE: FormCommon.cs
//
//DESCRIPTION: This has common methods for the main form of a program.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Form1
    //--------------------------------------------------------------------------
    public partial class Form1 : Form
    {
        //----------------------------------------------------------------------
        //NAME: Timex_Tick
        //check timeouts
        //----------------------------------------------------------------------
        private void Timex_Tick(object sender, EventArgs e)
        {
            Gbls.LG.UpdateDisplay();
        }
        //----------------------------------------------------------------------
        //NAME: mnuHelp_Click
        //display some help
        //----------------------------------------------------------------------
        private void mnuHelp_Click(object sender, EventArgs e)
        {
            FileInfo FI = new FileInfo(Gbls.HelpPath);
            if (FI.Exists)
            {
                StreamReader SR = new StreamReader(Gbls.HelpPath);
                String RawText = SR.ReadToEnd();
                SR.Close();

                TreeHelpDlg THD = new TreeHelpDlg();
                THD.Text = Gbls.ProgTitle + " Help - " + Gbls.ProgVersion;
                THD.Title = Gbls.ProgTitle + " Help";
                THD.MyColor = Color.LightBlue;
                THD.FileName = Path.GetFileName(Gbls.HelpPath);
                //-- set everything before requesting file read
                if (THD.ReadTreeDocFile(RawText))
                {
                    THD.Show();
                }
                else
                {
                    MessageBox.Show("Help File Missing.\r\nNo built in help yet,\r\nRead the manual\r\n or just call us",
                                    Gbls.ProgTitle,
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Help File Missing.\r\nNo built in help yet,\r\nRead the manual\r\n or just call us",
                                Gbls.ProgTitle,
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuAbout_Click
        //display info about the program
        //----------------------------------------------------------------------
        private void mnuAbout_Click(object sender, EventArgs e)
        {
            AboutDlg MyAbout = new AboutDlg();
            MyAbout.BackColor = Color.LightBlue;
            MyAbout.ProgramName = Gbls.ProgTitle;

            MyAbout.ProgramInfo = Gbls.ProgTitle + 
                            "\r\nVersion: " + Gbls.ProgVersion +
                            "\r\nCopyright 2019 - Joe Bartel" +
                            "\r\n\r\nSend comments to: " + Gbls.ContactEMail;
            MyAbout.ShowDialog();
        }
        //----------------------------------------------------------------------
        //NAME: mnuLogShow_Click
        //show the log file
        //----------------------------------------------------------------------
        private void mnuLogShow_Click(object sender, EventArgs e)
        {
            //special disable timer for main use
            Timex.Enabled = true;
            Gbls.LG.Show();
        }
        //----------------------------------------------------------------------
        //NAME: mnuLogSave_Click
        //start saving the log to disk
        //----------------------------------------------------------------------
        private void mnuLogSave_Click(object sender, EventArgs e)
        {
            Gbls.LG.OpenFile();
            mnuLogSave.Enabled = false;
            mnuLogClose.Enabled = true;
        }
        //----------------------------------------------------------------------
        //NAME: mnuLogClose_Click
        //close the log file if it is open
        //----------------------------------------------------------------------
        private void mnuLogClose_Click(object sender, EventArgs e)
        {
            Gbls.LG.Stop();
            mnuLogSave.Enabled = true;
            mnuLogClose.Enabled = false;
        }
    }
}
