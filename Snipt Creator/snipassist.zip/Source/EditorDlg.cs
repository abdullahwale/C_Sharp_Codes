//------------------------------------------------------------------------------
//
//FILE: EditorDlg.cs
//
//DESCRIPTION: This is a simple editor dialog that uses the editor control.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: EditorDlg
    //--------------------------------------------------------------------------
    public partial class EditorDlg : Form
    {
        public string MyTitle = "EditorDlg";
        public string MyText = "";
        public Color MyColor = Color.LightBlue;

        TextBox txtDisplay;
        //----------------------------------------------------------------------
        //NAME: EditorDlg
        //init the dialog
        //----------------------------------------------------------------------
        public EditorDlg()
        {
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: EditorDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void EditorDlg_Shown(object sender, EventArgs e)
        {
            this.BackColor = MyColor;
            this.Text = MyTitle;
            txtDisplay = textEditor1.GetTextBox();
            txtDisplay.Text = MyText;
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
            MyTitle = title;
        }
        //----------------------------------------------------------------------
        //NAME: btnNext_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            MyText = txtDisplay.Text;
            DialogResult = DialogResult.OK;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            MyText = "";
            DialogResult = DialogResult.Cancel;
        }
    }
}