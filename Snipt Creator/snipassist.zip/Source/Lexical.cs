//------------------------------------------------------------------------------
//
//NAME: Lexical.cs
//
//DESCRIPTION: This class has a generic lexical parser. Input is line oriented.
//assume a c like syntax
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Lexical
    //--------------------------------------------------------------------------
    class Lexical
    {
        public int scpn;            //lexical scan index
        public string Linin;        //current input line
        public char Dlim;           //delimiter if return string
        public char Ungotten;       //a pushed back character
        public bool Ungot;          //flag for ungotten char
        StringReader SR;            //used for reading source
        public Boolean HasCodes;    //if true, strip first char from line
        public Int32 LineNumber;    //current line number
        public char chx;            //current character
        //This is public so lines can be inserted or deleted. After messing with
        //this call GotoLine to resync. Also lines can be modified or tested.
        public List<string> SrcLines;   //convert source to lines

        //----------------------------------------------------------------------
        // NAME: Lexical
        // constructor from string
        // a constructor from a list may be needed
        //----------------------------------------------------------------------
        public Lexical(string Src)
        {
            SR = new StringReader(Src);
            SrcLines = new List<string>(500);

            Linin = SR.ReadLine();
            while (Linin != null)
            {
                SrcLines.Add(Linin);
                Linin = SR.ReadLine();
            }
            SR = null;          //not needed after being read
            LineNumber = 0;
            Dlim = '"';         //default for string
            NextLine();         //prime the pump
            Ungot = false;      //flag for ungotten char
            HasCodes = false;   //assume no codes
            LineNumber = 1;
            chx = ' ';            
        }
        //----------------------------------------------------------------------
        // NAME: NextLine
        // ReadString a line of text from the current input file.
        //----------------------------------------------------------------------
        public Boolean NextLine()
        {
            scpn = 0;           // reset lexical scan pointer

            if(LineNumber >= SrcLines.Count)
            {
                Linin = "END ";
                return false;
            }
            else
            {
                Linin = SrcLines[LineNumber];
                //if there is a code, remove it from the line
                //this is mostly for using a preprocessed C file to find funcs
                if(HasCodes && (Linin.Length > 1))
                {
                    Linin = Linin.Substring(1);
                }
                LineNumber++;
                return true;
            }
        }
        //----------------------------------------------------------------------
        // NAME: GotoLine
        // This goes to a new line in the source. This is used after lines are
        // inserted or deleted from the line list. To rewind GoToLine(1)
        //----------------------------------------------------------------------
        public bool GotoLine(int target)
        {
            if (target >= SrcLines.Count)
            {
                return false;
            }
            Ungot = false;
            NextLine();
            return true;
        }
        //----------------------------------------------------------------------
        // NAME: GetChar
        // Get next character from src string
        // End of line = char.MinValue   --- End of Src = char.MaxValue
        // need to besure EOL come before EOF
        //----------------------------------------------------------------------
        public char GetChar()
        {
            char cxx;
            //first check for pushed back char
            if (Ungot)
            {
                Ungot = false;
                return Ungotten;
            }
            if (scpn >= Linin.Length)
            {
                if (!NextLine())
                {
                    Ungotten = char.MaxValue;
                    Ungot = true;
                }
                cxx = char.MinValue;
                return cxx;
            }
            cxx = Linin[scpn];
            scpn++;
            return cxx;
        }
        //----------------------------------------------------------------------
        // NAME: UnGetChar
        // un get a char that was gotten
        //----------------------------------------------------------------------
        public void UnGetChar(char cx)
        {
            Ungotten = cx;  //push back character
            Ungot = true;   //set flag
        }
        //----------------------------------------------------------------------
        //NAME: SkipWhite
        //skip white space
        //----------------------------------------------------------------------
        void SkipWhite()
        {
            bool Skipping = true;   //skipping chars for comment
            //bool Possible = false;  //possible new comment

            chx = GetChar();
            while (true)
            {
                if (Char.IsWhiteSpace(chx))
                {
                    while (Char.IsWhiteSpace(chx))
                    {
                        chx = GetChar();
                    }
                }
                else if (chx == '/')
                {
                    chx = GetChar();
                    if (chx == '*')
                    {
                        //inside comment, start skipping things until */
                        Skipping = true;
                        while (Skipping)
                        {
                            chx = GetChar();
                            //-- test possible end of comment
                            if (chx == '*')
                            {
                                chx = GetChar();
                                if (chx == '/')
                                {
                                    Skipping = false;
                                    chx = GetChar();    //replace what we used
                                    //UnGetChar(chx);
                                }
                                else
                                {
                                    UnGetChar(chx);
                                }
                            }
                            else if (chx == char.MaxValue)
                            {
                                Skipping = false;
                            }
                        }
                    }
                    else if (chx == '/')
                    {
                        //comment to end of line
                        //get and discard until char.MinValue
                        while ((chx != char.MinValue) && (chx != char.MaxValue))
                        {
                            chx = GetChar();
                        }
                    }
                    else
                    {
                        UnGetChar(chx);
                    }                              
                }
                else
                {
                    break;
                }
            }
        }
        //----------------------------------------------------------------------
        // NAME: GetToken
        // Get next token from src string
        //----------------------------------------------------------------------
        public LexItem GetToken()
        {
            LexItem Token = new LexItem();
            string Name = "";       //this should be a string builder

            // skip white space and comments
            SkipWhite();
            // figure out what was found
            //special marker for EOL
            if (chx == char.MinValue)
            {
                Token.Type = TokenType.LineEnd;
                return Token;
            }
            //special marker for End of Src
            if (chx == char.MaxValue)
            {
                Token.Type = TokenType.End;
                return Token;
            }
            if (char.IsNumber(chx))
            {
                Token.Type = TokenType.Number;
                while (chx == '.' | char.IsNumber(chx))
                {
                    Name = Name + chx;
                    chx = GetChar();
                }
                UnGetChar(chx);
                Token.Name = Name;
                return Token;
            }
            else if(char.IsLetter(chx) | chx == '_')
            {
                Token.Type = TokenType.Name;
                while(chx == '_' | char.IsLetterOrDigit(chx))
                {
                    Name = Name + chx;
                    chx = GetChar();
                }
                UnGetChar(chx);
                Token.Name = Name;
                return Token;
            }
            else if( chx == '"' | chx == '\'')
            {
                Dlim = chx;
                Token.Type = TokenType.Tstring;
                chx = GetChar();
                //pickup chars until EOL or Dlim
                //-> need to add escape characters so quotes can be in string
                while((chx != Dlim)&(chx != char.MinValue)&(chx != char.MaxValue))
                {
                    //need to save the string characters!
                    if (chx == '\\')
                    {
                        chx = GetChar();
                        switch (chx)
                        {
                            case '"':
                                Token.Name = Token.Name + chx;
                                break;
                            case '\'':
                                Token.Name = Token.Name + chx;
                                break;
                            case '\\':
                                Token.Name = Token.Name + chx;
                                break;
                            case '/':
                                Token.Name = Token.Name + chx;
                                break;
                            case 'b':
                                Token.Name = Token.Name + '\b';
                                break;
                            case 'f':
                                Token.Name = Token.Name + '\f';
                                break;
                            case 'n':
                                Token.Name = Token.Name + '\n';
                                break;
                            case 'r':
                                Token.Name = Token.Name + '\r';
                                break;
                            case 't':
                                Token.Name = Token.Name + '\t';
                                break;
                        }
                    }
                    else
                    {
                        Token.Name = Token.Name + chx;
                    }
                    chx = GetChar();
                }
                return Token;
            }
            else
            {
                //comments were skipped above /* //
                Name = Name + chx;
                Token.Type = TokenType.Operator;
            }
            Token.Name = Name;              //what we found
            Token.LineNumber = LineNumber;  //where we found it
            return Token;
        }
        //----------------------------------------------------------------------
        // NAME: GetRestOfLine
        // Get anything left on the current line, but skip white space
        //----------------------------------------------------------------------
        public string GetRestOfLine()
        {
            string stx = "";
            char chx;

            // skip blanks
            chx = GetChar();
            while (Char.IsWhiteSpace(chx))
            {
                chx = GetChar();
            }
            //get the rest
            while (chx != char.MinValue)
            {
                stx = stx + chx;
                chx = GetChar();
            }
            return stx;
        }
    }
    //--------------------------------------------------------------------------
    // CLASS: LexItem
    //--------------------------------------------------------------------------
    public class LexItem
    {
        public TokenType Type = TokenType.None;
        public String Name = "";
        public Int32 LineNumber = 0;    //line number where found

        //----------------------------------------------------------------------
        // NAME: LexItem
        // Constructor: Make a blank lexical item
        //----------------------------------------------------------------------
        public LexItem()
        {
        }
        //----------------------------------------------------------------------
        // NAME: LexItem
        // Constructor: Make a lexical item from a name - type might not be name
        //----------------------------------------------------------------------
        public LexItem(String Namx)
        {
            Type = TokenType.None;
            Name = Namx;
        }
    }
    //--------------------------------------------------------------------------
    // ENUM: TokenType
    //--------------------------------------------------------------------------
    public enum TokenType 
    { 
        None,       //nothing
        Name,       //starts with A-Z,a-z,_
        Number,     //starts with 0-9
        LineEnd,    //end of line
        Operator,   //operator
        Tstring,    //string
        End,        //end of input
        Error       //error
    }
}
