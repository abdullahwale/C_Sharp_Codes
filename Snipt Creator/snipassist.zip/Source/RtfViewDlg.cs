//------------------------------------------------------------------------------
//
//NAME: RtfViewDlg.cs
//
//DESCRIPTION: This is a reusable dialog that will display a block of rtf text.
//The operater can save the text to a file.
//A fixed size font is used so report columns will look good.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: RtfViewDlg
    //--------------------------------------------------------------------------
    public partial class RtfViewDlg : Form
    {
        public string ReportName = "None";
        public string Title = "Report";
        public Color MyColor = Color.Silver;
        public string ReportText = "";
        public bool CanEdit = false;
        public bool PlainText = false;

        //----------------------------------------------------------------------
        //NAME: RtfViewDlg
        //initialize the dialog
        //----------------------------------------------------------------------
        public RtfViewDlg()
        {
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: ReportDlg_Shown
        //fill in the boxes from setup and public items
        //----------------------------------------------------------------------
        private void RtfViewDlg_Shown(object sender, EventArgs e)
        {
            this.Text = Title;
            lblName.Text = ReportName;
            this.BackColor = MyColor;
            if (PlainText)
            {
                RichText.Text = ReportText; //inserts as plain text
            }
            else
            {
                RichText.Rtf = ReportText;  //real rtf
            }
            RichText.ReadOnly = !CanEdit;
        }
        //----------------------------------------------------------------------
        //NAME: btnSave_Click
        //do a dialog to get the destination file and save the file
        //----------------------------------------------------------------------
        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult DL;
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.RestoreDirectory = true;
            DL = SFD.ShowDialog();
            Gbls.LG.WriteLog("rtf save DL = " + DL.ToString());
            if (DL == DialogResult.OK)
            {
                if (PlainText)
                {
                    PutTextFile(SFD.FileName, RichText.Text);
                }
                else
                {
                    PutTextFile(SFD.FileName, RichText.Rtf);
                }
            }
            else
            {
                Gbls.LG.WriteLog("file not written : DL = " + DL.ToString());
            }
        }
        //----------------------------------------------------------------------
        //NAME: PutTextFile
        //put the the text into a file - path needed
        //----------------------------------------------------------------------
        public bool PutTextFile(string FilePath, string FileText)
        {
            bool OK = true;

            try
            {
                StreamWriter MySW = new StreamWriter(FilePath);
                MySW.Write(FileText);
                MySW.Close();
            }
            catch (Exception ex)
            {
                Gbls.LG.WriteLog("PutTextFile: " + ex.ToString());
                OK = false;
            }
            return OK;
        }
    }
}