//------------------------------------------------------------------------------
//
//FILE: SnipActions.cs
//
//DESCRIPTION: This file has methods that do things with snips
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Form1
    //--------------------------------------------------------------------------
    public partial class Form1 : Form
    {
        //----------------------------------------------------------------------
        //NAME: mnuEditSnip_Click
        //Edit an existing snip - either the source or the description
        //----------------------------------------------------------------------
        private void mnuEditSnip_Click(object sender, EventArgs e)
        {
            int CrntItemIndex = lxbItem.SelectedIndex;
            if (CheckNoSnipSelect()) return;
            SnipEditDlg SED = new SnipEditDlg();
            SED.Setup("Edit Existing Snip");
            SED.MySnip = CurrentSnip.Clone();
            SED.MySnip.Name = SnipName;
            SED.Category = CurntNode.FullPath;
            SED.RootFolder = Gbls.RootFolder;
            SED.WorkTree = Util.CloneTreeView(tvSelect);
            if (SED.ShowDialog() == DialogResult.OK)
            {
                CurrentSnip = SED.MySnip;
                //- get the body again
                txtDisplay.Text = CurrentSnip.Description;
                BodyDisplay.Text = CurrentSnip.Body;
                SetClipText(CurrentSnip.Body);
                txbSnip.Text = "Snip Description";
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuMoveSnip_Click
        //move a snip to a new folder - can rename
        //----------------------------------------------------------------------
        private void mnuMoveSnip_Click(object sender, EventArgs e)
        {
            if (CheckNoSnipSelect()) return;

            MoveRenameDlg MRD = new MoveRenameDlg();
            MRD.Setup("Move Snip", "Snip");
            MRD.Action = 'M';
            MRD.StartPath = SnipName;
            MRD.WorkTree = Util.CloneTreeView(tvSelect);

            if (MRD.ShowDialog() == DialogResult.OK)
            {
                string DestPath = MRD.DestPath;
                if (DestPath == "")
                {
                    DestPath = CurrentFolder;
                }
                //if new name exists, ask if overwrite or copy
                TreeNode TN = Util.FindTreeNode(DestPath, tvSelect);
                if (TN == null)
                {
                    MessageBox.Show("Destination Folder does not exist\r\n" +
                        DestPath , Gbls.ProgTitle,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                string SrcPath = Gbls.RootFolder + "\\" + CurrentFolder + "\\" + SnipName;
                DestPath = Gbls.RootFolder + "\\" + DestPath + "\\" + SnipName;
                if (!DestPath.EndsWith(".snp"))
                {
                    DestPath = DestPath + ".snp";
                }
                //if new name exists, just ignore command
                if (SrcPath == DestPath) return;

                if (CheckOverWriteFile(DestPath))
                {
                    File.Move(SrcPath,DestPath);
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuRenameSnip_Click
        //rename a snip where it is
        //----------------------------------------------------------------------
        private void mnuRenameSnip_Click(object sender, EventArgs e)
        {
            if (CheckNoSnipSelect()) return;

            MoveRenameDlg MRD = new MoveRenameDlg();
            MRD.Setup("Rename Snip", "Snip");
            MRD.Action = 'R';
            MRD.StartPath = SnipName;

            if (MRD.ShowDialog() == DialogResult.OK)
            {
                string SrcPath = Gbls.RootFolder + "\\" + CurrentFolder + "\\" + SnipName;
                string DestPath = Gbls.RootFolder + "\\" + CurrentFolder + "\\" + MRD.DestPath;
                if(!DestPath.EndsWith(".snp"))
                {
                    DestPath = DestPath + ".snp";
                }
                //if new name exists, just ignore it
                if (SrcPath == DestPath) return;
                if (CheckOverWriteFile(DestPath))
                {
                    File.Move(SrcPath,DestPath);
                }
                PopulateItemsList();
            }
        }
        //----------------------------------------------------------------------
        //NAME: mnuDeleteSnip_Click
        //delete the currently selected sniip
        //----------------------------------------------------------------------
        private void mnuDeleteSnip_Click(object sender, EventArgs e)
        {
            if (CheckNoSnipSelect()) return;

            string CurrntItem = lxbItem.SelectedItem.ToString();

            if (MessageBox.Show("Confirm Delete Snip: " + CurrntItem,
                Gbls.ProgTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                //delete SnipName
                FileInfo DFI = new FileInfo(SnipPath);
                DFI.Delete();
                PopulateItemsList();
                NoSelect = true;
                txtDisplay.Text = "";
                //get folder description
                txbSnip.Text = "Snip Description";
            }
        }
        //----------------------------------------------------------------------
        //NAME: CheckOverWriteFile
        // true if write is OK
        //----------------------------------------------------------------------
        public bool CheckOverWriteFile(string NewPath)
        {
            bool Result = false;
            if (File.Exists(NewPath))
            {
                //strip the library path before sending message
                string ShowName = NewPath.Substring(Gbls.RootFolder.Length + 1);
                if (MessageBox.Show("Are you sure you want to overwrite?\r\n" + ShowName, 
                        Gbls.ProgTitle,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    Result = true;
                }
            }
            else
            {
                Result = true;
            }        
            return Result;
        }
    }
}
