namespace Bartel
{
    partial class TextEditor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuEditTop = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUndo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCut = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPaste = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSearchTop = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuGoTo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFind = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReplace = new System.Windows.Forms.ToolStripMenuItem();
            this.formatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuWordWrap = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInsertBlankLines = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdjust = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuJoinLines = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.specToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDate = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTime = new System.Windows.Forms.ToolStripMenuItem();
            this.txbMainText = new System.Windows.Forms.TextBox();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightGray;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuEditTop,
            this.mnuSearchTop,
            this.formatToolStripMenuItem,
            this.specToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(292, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuEditTop
            // 
            this.mnuEditTop.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuUndo,
            this.mnuCut,
            this.mnuCopy,
            this.mnuPaste,
            this.mnuDelete});
            this.mnuEditTop.Name = "mnuEditTop";
            this.mnuEditTop.Size = new System.Drawing.Size(40, 20);
            this.mnuEditTop.Text = "Edit";
            // 
            // mnuUndo
            // 
            this.mnuUndo.Name = "mnuUndo";
            this.mnuUndo.Size = new System.Drawing.Size(152, 22);
            this.mnuUndo.Text = "Undo";
            this.mnuUndo.Click += new System.EventHandler(this.mnuUndo_Click);
            // 
            // mnuCut
            // 
            this.mnuCut.Name = "mnuCut";
            this.mnuCut.Size = new System.Drawing.Size(152, 22);
            this.mnuCut.Text = "Cut";
            this.mnuCut.Click += new System.EventHandler(this.mnuCut_Click);
            // 
            // mnuCopy
            // 
            this.mnuCopy.Name = "mnuCopy";
            this.mnuCopy.Size = new System.Drawing.Size(152, 22);
            this.mnuCopy.Text = "Copy";
            this.mnuCopy.Click += new System.EventHandler(this.mnuCopy_Click);
            // 
            // mnuPaste
            // 
            this.mnuPaste.Name = "mnuPaste";
            this.mnuPaste.Size = new System.Drawing.Size(152, 22);
            this.mnuPaste.Text = "Paste";
            this.mnuPaste.Click += new System.EventHandler(this.mnuPaste_Click);
            // 
            // mnuDelete
            // 
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(152, 22);
            this.mnuDelete.Text = "Delete";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // 
            // mnuSearchTop
            // 
            this.mnuSearchTop.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuGoTo,
            this.mnuFind,
            this.mnuReplace});
            this.mnuSearchTop.Name = "mnuSearchTop";
            this.mnuSearchTop.Size = new System.Drawing.Size(57, 20);
            this.mnuSearchTop.Text = "Search";
            // 
            // mnuGoTo
            // 
            this.mnuGoTo.Name = "mnuGoTo";
            this.mnuGoTo.Size = new System.Drawing.Size(152, 22);
            this.mnuGoTo.Text = "Go To Line";
            this.mnuGoTo.Click += new System.EventHandler(this.mnuGoTo_Click);
            // 
            // mnuFind
            // 
            this.mnuFind.Name = "mnuFind";
            this.mnuFind.Size = new System.Drawing.Size(152, 22);
            this.mnuFind.Text = "Find";
            this.mnuFind.Click += new System.EventHandler(this.mnuFind_Click);
            // 
            // mnuReplace
            // 
            this.mnuReplace.Name = "mnuReplace";
            this.mnuReplace.Size = new System.Drawing.Size(152, 22);
            this.mnuReplace.Text = "Replace";
            this.mnuReplace.Click += new System.EventHandler(this.mnuReplace_Click);
            // 
            // formatToolStripMenuItem
            // 
            this.formatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuWordWrap,
            this.mnuInsertBlankLines,
            this.mnuAdjust,
            this.mnuJoinLines,
            this.mnuSelectAll,
            this.mnuClearAll});
            this.formatToolStripMenuItem.Name = "formatToolStripMenuItem";
            this.formatToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.formatToolStripMenuItem.Text = "Format";
            // 
            // mnuWordWrap
            // 
            this.mnuWordWrap.Name = "mnuWordWrap";
            this.mnuWordWrap.Size = new System.Drawing.Size(172, 22);
            this.mnuWordWrap.Text = "Word Wrap";
            this.mnuWordWrap.Click += new System.EventHandler(this.mnuWordWrap_Click);
            // 
            // mnuInsertBlankLines
            // 
            this.mnuInsertBlankLines.Name = "mnuInsertBlankLines";
            this.mnuInsertBlankLines.Size = new System.Drawing.Size(172, 22);
            this.mnuInsertBlankLines.Text = "Insert Blank Lines";
            this.mnuInsertBlankLines.Click += new System.EventHandler(this.mnuInsertBlankLines_Click);
            // 
            // mnuAdjust
            // 
            this.mnuAdjust.Name = "mnuAdjust";
            this.mnuAdjust.Size = new System.Drawing.Size(172, 22);
            this.mnuAdjust.Text = "Adjust lines";
            this.mnuAdjust.Click += new System.EventHandler(this.mnuAdjust_Click);
            // 
            // mnuJoinLines
            // 
            this.mnuJoinLines.Name = "mnuJoinLines";
            this.mnuJoinLines.Size = new System.Drawing.Size(172, 22);
            this.mnuJoinLines.Text = "Join Lines";
            this.mnuJoinLines.Click += new System.EventHandler(this.mnuJoinLines_Click);
            // 
            // mnuSelectAll
            // 
            this.mnuSelectAll.Name = "mnuSelectAll";
            this.mnuSelectAll.Size = new System.Drawing.Size(172, 22);
            this.mnuSelectAll.Text = "Select All";
            this.mnuSelectAll.Click += new System.EventHandler(this.mnuSelectAll_Click);
            // 
            // specToolStripMenuItem
            // 
            this.specToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuDate,
            this.mnuTime});
            this.specToolStripMenuItem.Name = "specToolStripMenuItem";
            this.specToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.specToolStripMenuItem.Text = "Special";
            // 
            // mnuDate
            // 
            this.mnuDate.Name = "mnuDate";
            this.mnuDate.Size = new System.Drawing.Size(102, 22);
            this.mnuDate.Text = "Date";
            this.mnuDate.Click += new System.EventHandler(this.mnuDate_Click);
            // 
            // mnuTime
            // 
            this.mnuTime.Name = "mnuTime";
            this.mnuTime.Size = new System.Drawing.Size(102, 22);
            this.mnuTime.Text = "Time";
            this.mnuTime.Visible = false;
            this.mnuTime.Click += new System.EventHandler(this.mnuTime_Click);
            // 
            // txbMainText
            // 
            this.txbMainText.AcceptsReturn = true;
            this.txbMainText.AcceptsTab = true;
            this.txbMainText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txbMainText.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbMainText.HideSelection = false;
            this.txbMainText.Location = new System.Drawing.Point(0, 24);
            this.txbMainText.Multiline = true;
            this.txbMainText.Name = "txbMainText";
            this.txbMainText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txbMainText.Size = new System.Drawing.Size(292, 230);
            this.txbMainText.TabIndex = 1;
            this.txbMainText.WordWrap = false;
            this.txbMainText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbMainText_KeyPress);
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(172, 22);
            this.mnuClearAll.Text = "Clear All";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // TextEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txbMainText);
            this.Controls.Add(this.menuStrip1);
            this.Name = "TextEditor";
            this.Size = new System.Drawing.Size(292, 254);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuEditTop;
        private System.Windows.Forms.TextBox txbMainText;
        private System.Windows.Forms.ToolStripMenuItem mnuSearchTop;
        private System.Windows.Forms.ToolStripMenuItem mnuGoTo;
        private System.Windows.Forms.ToolStripMenuItem mnuFind;
        private System.Windows.Forms.ToolStripMenuItem formatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem specToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuUndo;
        private System.Windows.Forms.ToolStripMenuItem mnuCut;
        private System.Windows.Forms.ToolStripMenuItem mnuCopy;
        private System.Windows.Forms.ToolStripMenuItem mnuPaste;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuReplace;
        private System.Windows.Forms.ToolStripMenuItem mnuWordWrap;
        private System.Windows.Forms.ToolStripMenuItem mnuAdjust;
        private System.Windows.Forms.ToolStripMenuItem mnuSelectAll;
        private System.Windows.Forms.ToolStripMenuItem mnuDate;
        private System.Windows.Forms.ToolStripMenuItem mnuTime;
        private System.Windows.Forms.ToolStripMenuItem mnuInsertBlankLines;
        private System.Windows.Forms.ToolStripMenuItem mnuJoinLines;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
    }
}
