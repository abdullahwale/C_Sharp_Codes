//------------------------------------------------------------------------------
//
//FILE: SnipCls.cs
//
//DESCRIPTION: This file has the snip class
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: SnipCls
    //--------------------------------------------------------------------------
    public class SnipCls
    {
        public string Name = "";
        public string Header = "";
        public string Description = "";
        public string Body = "";
        public string RawText = "";

        public static string BodyStart = "----$$$$----body----$$$$";
        public static string DescStart = "----$$$$----description----$$$$";
        //----------------------------------------------------------------------
        //NAME: SnipCls
        //init a new snip
        //----------------------------------------------------------------------
        public SnipCls()
        {
        }
        //----------------------------------------------------------------------
        //NAME: Clone
        //make a copy of the snip
        //----------------------------------------------------------------------
        public SnipCls Clone()
        {
            SnipCls CL = new SnipCls();
            CL.Name = Name;
            CL.Header = Header;
            CL.Description = Description;
            CL.Body = Body;
            CL.RawText = RawText;
            return CL;
        }
        //----------------------------------------------------------------------
        //NAME: GetSnipText
        //make a snip from a string
        //----------------------------------------------------------------------
        public void GetSnipText(string MyText)
        {
            RawText = MyText;
            ParseSnip();
        }
        //----------------------------------------------------------------------
        //NAME: GetSnipPath
        //get a snip from disk
        //----------------------------------------------------------------------
        public void GetSnipPath(string MyPath)
        {
            RawText = Util.GetTextFile(MyPath);
            ParseSnip();
        }
        //----------------------------------------------------------------------
        //NAME: MakeString
        //Combine the fields to make a single long string.
        //----------------------------------------------------------------------
        public string MakeString()
        {
            StringBuilder SB = new StringBuilder();

            SB.AppendLine(Header);
            SB.AppendLine(DescStart);
            SB.AppendLine(Description);
            SB.AppendLine(BodyStart);
            SB.Append(Body);
            RawText = SB.ToString();
            return RawText;
        }
        //----------------------------------------------------------------------
        //NAME: ParseSnip
        //take the raw text apart
        //----------------------------------------------------------------------
        void ParseSnip()
        {
            string linin = "";

            //if((!RawText.Contains(BodyStart)) || (!RawText.Contains(DescStart)))
            //{
            //    //invalid snip
            //}

            StringReader SR = new StringReader(RawText);
            StringBuilder SB = new StringBuilder();

            //now extract the parts
            //everything before -- desc is header
            linin = SR.ReadLine();

            if (linin == null)
            {
                return;
            }
            //-- either divider ends the header
            while ( !(linin.Contains (DescStart) ||  linin.Contains (BodyStart)))
            {
                SB.AppendLine(linin);                
                linin = SR.ReadLine();
            }
            if (linin.Contains(DescStart))
            {
                Header = SB.ToString().Trim();
                SB = new StringBuilder();
                //read description until magic line - put in description
                linin = SR.ReadLine();
                while (!linin.Contains(BodyStart))
                {
                    SB.AppendLine(linin);
                    linin = SR.ReadLine();
                }
            }
            //if it wasn't desc start, we got another section
            Description = SB.ToString().Trim();

            //last get the body
            SB = new StringBuilder();
            linin = SR.ReadLine();
            while (linin != null)
            {
                SB.AppendLine(linin);
                linin = SR.ReadLine();
            }
            //only trim end because code has leading spaces!
            //Body = SB.ToString().TrimEnd();
            Body = SB.ToString();
        }
    }
}
