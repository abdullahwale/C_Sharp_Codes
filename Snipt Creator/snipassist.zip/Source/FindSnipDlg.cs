//------------------------------------------------------------------------------
//
//NAME: FindSnipDlg.cs
//
//DESCRIPTION: This is find snip. Uses plain "Show" not "DhowDialog" to save
// the results or setup.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: FindSnipDlg
    //--------------------------------------------------------------------------
    public partial class FindSnipDlg : Form
    {
        public string StartPath = "";
        public string LookFor = "";
        public bool AbortSearch = false;
        public int FoundCount = 0;
        public TreeView WorkTree = null;

        //----------------------------------------------------------------------
        //NAME: FindSnipDlg
        //init the dialog
        //----------------------------------------------------------------------
        public FindSnipDlg()
        {
            InitializeComponent();
            txtStartPath.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
            txtLookFor.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
        }
        //----------------------------------------------------------------------
        //NAME: FindDlg_Shown
        //
        //----------------------------------------------------------------------
        private void FindDlg_Shown(object sender, EventArgs e)
        {
            txtStartPath.Text = "";     //StartPath;
            txtLookFor.Focus();
        }
        //----------------------------------------------------------------------
        //NAME: FindDlg_FormClosing
        //don't close, hide so the search stuff is not lost
        //----------------------------------------------------------------------
        private void FindDlg_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }
        //----------------------------------------------------------------------
        //NAME: btnBrowse_Click
        //do a dialog to get the source file or folder
        //----------------------------------------------------------------------
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            TreeSelectDlg TSD = new TreeSelectDlg();
            TSD.CopyTreeView = WorkTree;
            if (Gbls.MainForm.CurntNode != null)
            {
                Gbls.MainForm.CurntNode.BackColor = Color.Empty;
            }

            if (TSD.ShowDialog() == DialogResult.OK)
            {
                txtStartPath.Text = TSD.DirectoryName;
            }
            if (Gbls.MainForm.CurntNode != null)
            {
                Gbls.MainForm.CurntNode.BackColor = Color.LightBlue;
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //cancel the search
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //set an abort flag
            AbortSearch = true;
        }
        //----------------------------------------------------------------------
        //NAME: btnSearch_Click
        //start searching
        //----------------------------------------------------------------------
        private void btnSearch_Click(object sender, EventArgs e)
        {
            LookFor = txtLookFor.Text;
            if (LookFor.Trim().Length == 0)
            {
                MessageBox.Show("Nothing to Search For", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string StartPath = txtStartPath.Text.Trim();
            if (StartPath.Length > 0)
            {
                if (Util.FindTreeNode(StartPath, WorkTree) == null)
                {
                    MessageBox.Show("Search Folder Not Valid", Gbls.ProgTitle,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }            
            if (!chkCatDesc.Checked && !chkSnipBody.Checked && !chkSnipDesc.Checked)
            {
                chkSnipDesc.Checked = true;
            }
            if (chkIgnoreCase.Checked)
            {
                LookFor = LookFor.ToUpper();
            }
            //do recursive search - DoEvents - check abort
            FoundCount = 0;
            lxbFound.Items.Clear();
            AbortSearch = false;
            if (txtStartPath.Text.Trim() == "")
            {
                //start at root, do all the nodes
                foreach (TreeNode Tx in WorkTree.Nodes)
                {
                    SearchNode(Tx);
                }
            }
            else
            {
                //look in this node or tree
                TreeNode Tnn = Util.FindTreeNode(txtStartPath.Text, WorkTree);
                SearchNode(Tnn);
            }

            if (FoundCount == 0)
            {
                MessageBox.Show("No Snips Found", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(FoundCount.ToString() + " Snips Found", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        //----------------------------------------------------------------------
        //NAME: SearchNode
        //recursive search - use WorkTree instead of directories
        //----------------------------------------------------------------------
        private void SearchNode(TreeNode MyNode)
        {
            //do recursive search - DoEvents - check abort
            Application.DoEvents();
            if (AbortSearch) return;

            string DirName = Gbls.RootFolder + "\\" + MyNode.FullPath;
            string NodePath = MyNode.FullPath;
            bool FountSnip = false;

            if (chkCatDesc.Checked)
            {
                FileInfo FI = new FileInfo(DirName + "\\Description.txt");
                if (FI.Exists)
                {
                    string txx = Util.GetTextFile(FI.FullName);
                    if (chkIgnoreCase.Checked)
                    {
                        txx = txx.ToUpper();
                    }
                    if(txx.Contains(LookFor))
                    {
                        lxbFound.Items.Add(NodePath + "\\Description.txt");
                        FoundCount++;
                    }
                }
            }
            DirectoryInfo DI = new DirectoryInfo(DirName);
            if (chkSnipBody.Checked || chkSnipDesc.Checked )
            {
                FileInfo[] These = DI.GetFiles();
                foreach (FileInfo FI in These)
                {
                    if (FI.Extension == ".snp")
                    {
                        FountSnip = false;

                        string Raw = Util.GetTextFile(FI.FullName);
                        SnipCls ThisSnip = new SnipCls();
                        ThisSnip.GetSnipText(Raw);
                        if (chkSnipBody.Checked)
                        {
                            if (chkIgnoreCase.Checked)
                            {
                                ThisSnip.Body = ThisSnip.Body.ToUpper();
                            }
                            if (ThisSnip.Body.Contains(LookFor))
                            {
                                lxbFound.Items.Add(NodePath + "\\" + FI.Name);
                                FoundCount++;
                                FountSnip = true;
                            }
                        }
                        if (chkSnipDesc.Checked && !FountSnip)
                        {
                            if (chkIgnoreCase.Checked)
                            {
                                ThisSnip.Description = ThisSnip.Description.ToUpper();
                            }
                            if (ThisSnip.Description.Contains(LookFor))
                            {
                                lxbFound.Items.Add(NodePath + "\\" + FI.Name);
                                FoundCount++;
                            }
                        }
                    }
                }
            }
            //--- now do same for all subnodes
            foreach (TreeNode Tx in MyNode.Nodes)
            {
                if (AbortSearch) return;
                SearchNode(Tx);
            }
        }
        //----------------------------------------------------------------------
        //NAME: lxbFound_SelectedIndexChanged
        //one of the found files was selected, get it displayed.
        //----------------------------------------------------------------------
        private void lxbFound_SelectedIndexChanged(object sender, EventArgs e)
        {
            string stx = lxbFound.SelectedItem.ToString();
            Gbls.MainForm.FindAction(stx);
        }
    }
}