namespace Bartel
{
    partial class CatalogDlg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txbStart = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbWholeTree = new System.Windows.Forms.RadioButton();
            this.rbSingleFolder = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkItemBody = new System.Windows.Forms.CheckBox();
            this.chkItemDescription = new System.Windows.Forms.CheckBox();
            this.chkCatDescription = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(283, 133);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 30);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(283, 185);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 30);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Start Folder";
            // 
            // txbStart
            // 
            this.txbStart.Location = new System.Drawing.Point(12, 37);
            this.txbStart.Name = "txbStart";
            this.txbStart.Size = new System.Drawing.Size(355, 20);
            this.txbStart.TabIndex = 3;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(220, 9);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(147, 23);
            this.btnBrowse.TabIndex = 4;
            this.btnBrowse.Text = "Select Folder";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.groupBox1.Controls.Add(this.rbWholeTree);
            this.groupBox1.Controls.Add(this.rbSingleFolder);
            this.groupBox1.Location = new System.Drawing.Point(18, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(236, 54);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "What To Catalog";
            // 
            // rbWholeTree
            // 
            this.rbWholeTree.AutoSize = true;
            this.rbWholeTree.Checked = true;
            this.rbWholeTree.Location = new System.Drawing.Point(122, 19);
            this.rbWholeTree.Name = "rbWholeTree";
            this.rbWholeTree.Size = new System.Drawing.Size(81, 17);
            this.rbWholeTree.TabIndex = 6;
            this.rbWholeTree.TabStop = true;
            this.rbWholeTree.Text = "Whole Tree";
            this.rbWholeTree.UseVisualStyleBackColor = true;
            // 
            // rbSingleFolder
            // 
            this.rbSingleFolder.AutoSize = true;
            this.rbSingleFolder.Location = new System.Drawing.Point(15, 19);
            this.rbSingleFolder.Name = "rbSingleFolder";
            this.rbSingleFolder.Size = new System.Drawing.Size(86, 17);
            this.rbSingleFolder.TabIndex = 6;
            this.rbSingleFolder.Text = "Single Folder";
            this.rbSingleFolder.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.groupBox2.Controls.Add(this.chkItemBody);
            this.groupBox2.Controls.Add(this.chkItemDescription);
            this.groupBox2.Controls.Add(this.chkCatDescription);
            this.groupBox2.Location = new System.Drawing.Point(18, 122);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(236, 93);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "What To Show";
            // 
            // chkItemBody
            // 
            this.chkItemBody.AutoSize = true;
            this.chkItemBody.Location = new System.Drawing.Point(6, 65);
            this.chkItemBody.Name = "chkItemBody";
            this.chkItemBody.Size = new System.Drawing.Size(74, 17);
            this.chkItemBody.TabIndex = 7;
            this.chkItemBody.Text = "Snip Body";
            this.chkItemBody.UseVisualStyleBackColor = true;
            // 
            // chkItemDescription
            // 
            this.chkItemDescription.AutoSize = true;
            this.chkItemDescription.Location = new System.Drawing.Point(6, 42);
            this.chkItemDescription.Name = "chkItemDescription";
            this.chkItemDescription.Size = new System.Drawing.Size(103, 17);
            this.chkItemDescription.TabIndex = 7;
            this.chkItemDescription.Text = "Snip Description";
            this.chkItemDescription.UseVisualStyleBackColor = true;
            // 
            // chkCatDescription
            // 
            this.chkCatDescription.AutoSize = true;
            this.chkCatDescription.Checked = true;
            this.chkCatDescription.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCatDescription.Location = new System.Drawing.Point(6, 19);
            this.chkCatDescription.Name = "chkCatDescription";
            this.chkCatDescription.Size = new System.Drawing.Size(111, 17);
            this.chkCatDescription.TabIndex = 7;
            this.chkCatDescription.Text = "Folder Description";
            this.chkCatDescription.UseVisualStyleBackColor = true;
            // 
            // CatalogDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(379, 229);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txbStart);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Name = "CatalogDlg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "CatalogDlg";
            this.Shown += new System.EventHandler(this.CatalogDlg_Shown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbStart;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbWholeTree;
        private System.Windows.Forms.RadioButton rbSingleFolder;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkItemBody;
        private System.Windows.Forms.CheckBox chkItemDescription;
        private System.Windows.Forms.CheckBox chkCatDescription;
    }
}