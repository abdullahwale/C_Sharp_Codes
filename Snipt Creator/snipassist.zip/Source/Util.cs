//------------------------------------------------------------------------------
//
//NAME: Util.cs
//
//DESCRIPTION: This file has general utility functions
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Util
    //--------------------------------------------------------------------------
    class Util
    {
        //----------------------------------------------------------------------
        // NAME: MakeDesc
        //make a string into a description block
        //Desc = "//DESCRIPTION: "  OtherLine = "// "
        //used to adjust lines
        //----------------------------------------------------------------------
        public static List<string> MakeDesc(string Src, string Desc, string OtherLine)
        {
            int MaxLen = Gbls.TextMargin;   //80;
            List<string> Proc = new List<string>();
            int scpn = 0;
            string Line;
            string Word = "";

            Line = Desc;
            while (scpn < Src.Length)
            {
                //get a word
                while ((scpn < Src.Length) && (!Char.IsWhiteSpace(Src[scpn])))
                {
                    Word = Word + Src[scpn];
                    scpn++;
                }
                scpn++;
                if (Word != "")
                {
                    Word = Word + ' ';
                }
                //if (Word[Word.Length - 1] != ' ')
                //{
                //    Word = Word + ' ';
                //}
                Word = Word.Replace("  ", " ");
                //if word wont fit, new line
                if((Line.Length + Word.Length)> MaxLen)
                {
                    Proc.Add(Line);
                    Line = OtherLine;                   
                }
                //add word to line
                Line = Line + Word;
                Word = "";
            }
            // take care of the left overs
            if (Word.Length > 0)
            {
                Line = Line + Word;
            }
            if (Line.Length > 0)
            {
                Proc.Add(Line);
            }
            return Proc;
        }
        //----------------------------------------------------------------------
        //NAME: GetTextFile
        //get the text from a file - path needed
        //----------------------------------------------------------------------
        public static string GetTextFile(string FileName)
        {
            String Content = "";
            try
            {
                StreamReader MySR = new StreamReader(FileName);
                Content = MySR.ReadToEnd();
                MySR.Close();
            }
            catch (Exception ex)
            {
                Gbls.LG.WriteLog("GetTextFile: " + ex.ToString());
            }
            return Content;
        }
        //----------------------------------------------------------------------
        //NAME: PutTextFile
        //put the the text into a file - path needed
        //----------------------------------------------------------------------
        public static bool PutTextFile(string FilePath, string FileText)
        {
            bool OK = true;
            try
            {
                StreamWriter MySW = new StreamWriter(FilePath);
                MySW.Write(FileText);
                MySW.Close();
            }
            catch (Exception ex)
            {
                Gbls.LG.WriteLog("PutTextFile: " + ex.ToString());
                OK = false;
            }
            return OK;
        }
        //----------------------------------------------------------------------
        //NAME: MakeDateList
        //this makes a string list from todays date
        //----------------------------------------------------------------------
        public static List<string> MakeDateList()
        {
            List<string> ML = new List<string>();
            DateTime DT = DateTime.Now;

            ML.Add(DT.ToString("dd-MMM-yyyy"));
            ML.Add(DT.ToString("MMMM dd, yyyy"));
            ML.Add(DT.ToShortDateString());
            ML.Add(DT.ToLongDateString());
            ML.Add(DT.ToString("yyyyMMdd"));

            return ML;
        }
        //----------------------------------------------------------------------
        //NAME: TreeViewClone
        // clone a TreeView - reset all the background colors
        //----------------------------------------------------------------------
        public static void TreeViewClone(TreeView OldTree, TreeView NewTree)
        {
            TreeNode Txx;
            NewTree.Nodes.Clear();

            foreach (TreeNode TN in OldTree.Nodes)
            {
                Txx = (TreeNode)TN.Clone();
                CleanTreeNode(Txx);
                NewTree.Nodes.Add(Txx);
            }
        }
        //----------------------------------------------------------------------
        //NAME: CloneTreeView
        // clone a TreeView - reset all the background colors
        //----------------------------------------------------------------------
        public static TreeView CloneTreeView(TreeView OldTree)
        {
            TreeView NewTree = new TreeView();
            TreeNode Txx;
            NewTree.Nodes.Clear();

            foreach (TreeNode TN in OldTree.Nodes)
            {
                Txx = (TreeNode)TN.Clone();
                CleanTreeNode(Txx);
                NewTree.Nodes.Add(Txx);
            }
            return NewTree;
        }
        //----------------------------------------------------------------------
        //NAME: CleanTreeNode
        //reset all the background colors
        //----------------------------------------------------------------------
        public static void CleanTreeNode(TreeNode MyNode)
        {
            MyNode.BackColor = Color.Empty;
            foreach (TreeNode TN in MyNode.Nodes)
            {
                TN.BackColor = Color.Empty;
                CleanTreeNode(TN);
            }
        }
        //----------------------------------------------------------------------
        //NAME: MakeParagraphs
        //divide a text string into paragraphs - blank line is divider
        //----------------------------------------------------------------------
        public static List<string> MakeParagraphs(string MyText)
        {
            List<string> Result = new List<string>();
            string[] RawLines = MyText.Split('\n');
            int jj;
            StringBuilder SB = new StringBuilder();

            for (jj = 0; jj < RawLines.Length; jj++)
            {
                if (RawLines[jj].Length <= 1)
                {
                    Result.Add(SB.ToString());
                    SB = new StringBuilder();
                }
                else
                {
                    SB.AppendLine(RawLines[jj]);
                }
            }
            if (SB.Length > 0)
            {
                Result.Add(SB.ToString());
            }

            return Result;
        }
        //----------------------------------------------------------------------
        //NAME: JoinLines
        //joins lines to make rtf paragraphs - blank line is divider
        //----------------------------------------------------------------------
        public static List<string> JoinLines(List<string> RawLines)
        {
            List<string> Result = new List<string>();
            int jj;
            StringBuilder SB = new StringBuilder();

            for (jj = 0; jj < RawLines.Count; jj++)
            {
                if (RawLines[jj].Length <= 1)
                {
                    SB.AppendLine();
                    Result.Add(SB.ToString());
                    SB = new StringBuilder();
                }
                else
                {
                    SB.Append(RawLines[jj]);
                    SB.Append(" ");
                }
            }
            if (SB.Length > 0)
            {
                SB.AppendLine();
                Result.Add(SB.ToString());
            }
            return Result;
        }
        //----------------------------------------------------------------------
        //NAME: FindTreeNode
        //find the node in the tree that has the full path
        //----------------------------------------------------------------------
        public static TreeNode FindTreeNode(string FullPath, TreeView MyTree)
        {
            TreeNode TN;
            string[] Parts = FullPath.Split('\\');
            int jj;

            if (MyTree.Nodes.ContainsKey(Parts[0]))
            { 
                TN = MyTree.Nodes[Parts[0]];
            }
            else
            {
                return null;
            }

            for (jj = 1; jj < Parts.Length; jj++)
            {
                if (TN.Nodes.ContainsKey(Parts[jj]))
                {
                    TN = TN.Nodes[Parts[jj]];
                }
                else
                {
                    return null;
                }
            }
            return TN;
        }
        //----------------------------------------------------------------------
        //NAME: BringUpForm
        //if form (dialog) is minimizes, make normal. Bring to front.
        //----------------------------------------------------------------------
        public static void BringUpForm(Form MyForm)
        {
            if (MyForm.WindowState == FormWindowState.Minimized)
            {
                MyForm.WindowState = FormWindowState.Normal;
            }
            MyForm.BringToFront();

            return;
        }
    }
    //--------------------------------------------------------------------------
    //DELEGATE: GenericEventHandler
    //--------------------------------------------------------------------------
    public delegate void GenericEventHandler(object sender, EventArgs e);
}
