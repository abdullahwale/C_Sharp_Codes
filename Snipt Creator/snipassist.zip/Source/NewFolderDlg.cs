//------------------------------------------------------------------------------
//
//FILE: NewFolderDlg.cs
//
//DESCRIPTION: This will add a new folder and a new Description.txt
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: NewCatDlg
    //--------------------------------------------------------------------------
    public partial class NewFolderDlg : Form
    {
        public string MyTitle = "New Folder";
        public TreeView WorkTree = null;
        public string MyFolder = "";           //new CurrentFolder created

        TextBox txbBody;
        //----------------------------------------------------------------------
        //NAME: NewCatDlg
        //init the dialog
        //----------------------------------------------------------------------
        public NewFolderDlg()
        {
            InitializeComponent();
            txbBody = textEditor1.GetTextBox();
            ContextMenuMgr.SetEmptyStrip(txbBaseCategory);
            ContextMenuMgr.SetEmptyStrip(txbNewName);
        }
        //----------------------------------------------------------------------
        //NAME: NewCatDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void NewCatDlg_Shown(object sender, EventArgs e)
        {
            //display the current set of data
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            //create new folder
            MyFolder = Gbls.RootFolder + "\\" + txbBaseCategory.Text +
                             "\\" + txbNewName.Text;
            //-- need to check duplicate name --
            if (Directory.Exists(MyFolder))
            {
                //strip the library path before sending message
                string ShowName = MyFolder.Substring(Gbls.RootFolder.Length + 1);
                MessageBox.Show("Cannot create because folder already exists\r\n" + ShowName,
                        Gbls.ProgTitle,
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DirectoryInfo DI = new DirectoryInfo(MyFolder);
            if (!DI.Exists)
            {
                DI.Create();
            }
            Gbls.LG.WriteLog("New dir: " + DI.FullName);

            //put CatDescription.txt in it
            MyFolder = MyFolder + "\\Description.txt";
            Util.PutTextFile(MyFolder, txbBody.Text);

            MyFolder = txbBaseCategory.Text + "\\" + txbNewName.Text + "\\Description.txt";
            DialogResult = DialogResult.OK;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: btnBrowse_Click
        //select the folder to put the new category in
        //----------------------------------------------------------------------
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            TreeSelectDlg TSD = new TreeSelectDlg();
            TSD.CopyTreeView = WorkTree;

            if (TSD.ShowDialog() == DialogResult.OK)
            {
                txbBaseCategory.Text = TSD.DirectoryName;
            }
        }
    }
}