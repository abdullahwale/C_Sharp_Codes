//------------------------------------------------------------------------------
//
//FILE: SnipEditDlg.cs
//
//DESCRIPTION: This is the dialog used for entering a new snip or editing an
// existing snip
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: SnipEditDlg
    //--------------------------------------------------------------------------
    public partial class SnipEditDlg : Form
    {
        public string MyTitle = "Edit Snip";
        //caller needs to set this before showing the dialog
        public string StartFolder = "";
        public TreeView WorkTree = null;

        public string RootFolder = "";
        public DirectoryInfo RDI;           //root folder
        public string Fname = "";           //full path to new sip
        public bool NewSnip = false;        //new or edit old

        public string Category = "";

        //this requires the snip class
        public SnipCls MySnip = new SnipCls();

        TextBox txtDescription;
        TextBox txtBody;
        TextBox txtHeader;
        //----------------------------------------------------------------------
        //NAME: SnipEditDlg
        //init the dialog
        //----------------------------------------------------------------------
        public SnipEditDlg()
        {
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: SnipEditDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void SnipEditDlg_Shown(object sender, EventArgs e)
        {
            //-- get the text boxes
            txtDescription = DescEdit.GetTextBox();
            txtBody = BodyEdit.GetTextBox();
            txtHeader = HeadEdit.GetTextBox();
            //display the current set of data
            this.Text = MyTitle;
            txbCategory.Text = StartFolder;
            if (Category != "")
            {
                txbCategory.Text = Category;
            }
            txtBody.Text = MySnip.Body;
            txtDescription.Text = MySnip.Description;
            txtHeader.Text = MySnip.Header;
            txbName.Text = MySnip.Name;
            txbName.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
            txbCategory.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
            //- thiis is to prevent a bogus select all from occuring
            label1.Focus();

            if (NewSnip)
            {
                txbName.ReadOnly = false;
                txbCategory.Enabled = true;
                btnBrowse.Enabled = true;
                lblAction.Text = "Create New Snip";
            }
            else
            {
                txbName.ReadOnly = true;
                txbName.Enabled = false;
                txbCategory.Enabled = false;
                btnBrowse.Enabled = false;
                lblAction.Text = "Edit Existing Snip";
            }
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
            MyTitle = title;
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            MySnip.Body = txtBody.Text;
            MySnip.Header = txtHeader.Text;
            MySnip.Description = txtDescription.Text;
            MySnip.Name = txbName.Text.Trim();
            Category = txbCategory.Text.Trim();

            if (Category.Length <= 0)
            {
                MessageBox.Show("Folder Name Cannot Be blank", Gbls.ProgTitle,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (Category.Length > 0)
            {
                if (Util.FindTreeNode(Category, WorkTree) == null)
                {
                    MessageBox.Show("Folder Name Not Valid", Gbls.ProgTitle,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            if (MySnip.Name.Length <= 0)
            {
                MessageBox.Show("Snip Name Cannot Be blank", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // check for all the pieces - 
            Fname = RootFolder + "\\" + Category;
            //-- just incase new category  -- is this a good idea?
            //Directory.CreateDirectory(Fname);
            if (!Directory.Exists(Fname))
            {
                MessageBox.Show("Folder was not found", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            // try to open the file - may need a replace option
            if (!MySnip.Name.Contains(".snp"))
            {
                MySnip.Name = MySnip.Name + ".snp";
            }
            Fname = RootFolder + "\\" + Category + "\\" + MySnip.Name;

            Char[] BadNameChars = Path.GetInvalidFileNameChars();
            if (MySnip.Name.IndexOfAny(BadNameChars) >= 0)
            {
                MessageBox.Show("New Name Not Valid", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                int NameNdx = MySnip.Name.IndexOfAny(BadNameChars);
                Gbls.LG.WriteLog("Bad Char: " + MySnip.Name + "  -  " + NameNdx.ToString());
                return;
            }
            //this will throw an exception if bad chars - check bad first
            FileInfo FI = new FileInfo(Fname);
            if (NewSnip && FI.Exists)
            {
                //need message box for continue
                if (MessageBox.Show(this.Text, "Duplicate snip name",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Stop) == DialogResult.Cancel)
                {
                    return;
                }
            }

            try
            {
                Gbls.LG.WriteLog("New File Name: " + Fname);
                StreamWriter SW = new StreamWriter(Fname);
                SW.Write(MySnip.MakeString());
                SW.Close();
                // go home - all done
                Fname = Category + "\\" + MySnip.Name;
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                Gbls.LG.WriteLog("Exception: " + ex.ToString());
                MessageBox.Show("Action Failed, Cannot Create File", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: btnBrowse_Click
        //do a dialog to get the source file or folder
        //----------------------------------------------------------------------
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            TreeSelectDlg TSD = new TreeSelectDlg();
            TSD.CopyTreeView = WorkTree;
            TSD.NoRoot = true;

            if (TSD.ShowDialog() == DialogResult.OK)
            {
                txbCategory.Text = TSD.DirectoryName;
            }
        }
    }
}