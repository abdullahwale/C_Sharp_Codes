//------------------------------------------------------------------------------
//
//FILE: CatalogCls.cs
//
//DESCRIPTION: This file has the Catalog class. This is intended to be used with
// any library organized like the SnipAssist
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: CatalogCls
    //--------------------------------------------------------------------------
    class CatalogCls
    {
        public string MakeDate = "";
        public bool LibraryRoot = false;
        public CatalogFolderCls RootFolder = new CatalogFolderCls();

        public bool InRoot = false;
        public string ItemType = "Snip";
        //----------------------------------------------------------------------
        //NAME: MakeTextCatalog
        // make a text version of the catalog class, return as a string
        //----------------------------------------------------------------------
        public string MakeTextCatalog()
        {
            StringBuilder Result = new StringBuilder();
            InRoot = LibraryRoot;

            Result.AppendLine(ItemType + " Catalog");
            Result.AppendLine(MakeDate);
            Result.Append("Start Folder: ");
            Result.AppendLine(RootFolder.FolderName);

            if (RootFolder != null)
            {
                Result.AppendLine(MakeTextFolder(RootFolder));
            }
            return Result.ToString();
        }
        //----------------------------------------------------------------------
        //NAME: MakeTextFolder
        //make a text version of a CatalogFolderCls and return as a string
        //----------------------------------------------------------------------
        string MakeTextFolder(CatalogFolderCls ThisCat)
        {
            CatalogFolderCls MyCat = ThisCat;
            StringBuilder Result = new StringBuilder();

            if (!InRoot)
            {
                Result.AppendLine();
                Result.Append("Folder: ");
                Result.AppendLine(ThisCat.FolderName);
                Result.AppendLine(ThisCat.Description);
            }
            InRoot = false;

            foreach (CatalogItemCls IC in ThisCat.Item)
            {
                Result.AppendLine();
                Result.Append(ItemType + ": ");
                Result.AppendLine(IC.Name);
                if (IC.Description.Length > 0)
                {
                    Result.AppendLine(IC.Description);
                }
                if (IC.Body.Length > 0)
                {
                    if (IC.Description.Length > 0)
                    {
                        Result.AppendLine();
                    }
                    Result.Append(IC.Body);
                }
                if (ThisCat.Item.Count > 1)
                {
                    Result.AppendLine();
                }
            }

            foreach (CatalogFolderCls FC in ThisCat.Folder)
            {
                Result.Append(MakeTextFolder(FC));
            }

            return Result.ToString();
        }
    }
    //--------------------------------------------------------------------------
    //CLASS: CatalogFolderCls
    //a folder, sub folders, items
    //--------------------------------------------------------------------------
    class CatalogFolderCls
    {
        public string FolderName = "";
        public string Description = "";     //CatDescription.txt
        public List<CatalogFolderCls> Folder = new List<CatalogFolderCls>();
        public List<CatalogItemCls> Item = new List<CatalogItemCls>();
    }
    //--------------------------------------------------------------------------
    //CLASS: CatalogItemCls
    //a single item in the class
    //--------------------------------------------------------------------------
    class CatalogItemCls
    {
        public string Name = "";
        public string Description = "";
        public string Body = "";
    }
}
