//------------------------------------------------------------------------------
//
//FILE: Config.cs
//
//DESCRIPTION: This file has methods that implement the Config file load and save.
// When a config file is loaded, it can change many things. The config file is JSON
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Form1
    //--------------------------------------------------------------------------
    public partial class Form1 : Form
    {
        //----------------------------------------------------------------------
        //NAME: WriteConfig
        // write the config file - JSON
        //----------------------------------------------------------------------
        public void WriteConfig()
        {
            JoesJsonWriter JJ = new JoesJsonWriter();

            //write all the config stuff to it
            //this is to force use of the default root - as a USB needs it
            if (!Gbls.UsbRoot)
            {
                JJ.CommentLine("This is root folder");
                JJ.WriteObject("RootFolder", Gbls.RootFolder);
            }
            JJ.WriteObject("Margin", Gbls.TextMargin.ToString());
            JJ.WriteObject("TabSize", Gbls.TabSize.ToString());

            //-- auto clip setting - on, off
            if (Gbls.AutoClipboard)
            {
                JJ.WriteObject("AutoClip", "on");
            }
            else
            {
                JJ.WriteObject("AutoClip", "off");
            }
        }
        //----------------------------------------------------------------------
        //NAME: ReadConfig
        // read the config file - JSON
        //----------------------------------------------------------------------
        public void ReadConfig()
        {
            string RawText = Util.GetTextFile(Gbls.StartPath + "\\" + "Config.txt");
            JoesJasonReader JJ = new JoesJasonReader(RawText);
            LexItem ThisToken;
            string Result = "";
            int Number = 0;
            int limit = 0;
            int MaxConfig = 99;

            ThisToken = JJ.GetToken();
            while ((ThisToken.Type != TokenType.End) && (limit < MaxConfig))
            {
                limit++;
                if (ThisToken.Type == TokenType.Tstring)
                {
                    switch (ThisToken.Name)
                    {
                        case "RootFolder":
                            Result = JJ.GetStringItem();    //get item - string
                            Gbls.RootFolder = Result;
                            Gbls.UsbRoot = false;
                            break;
                        case "AutoClip":
                            Result = JJ.GetStringItem();    //get item - string
                            Gbls.AutoClipboard = (Result == "on");
                            break;
                        case "Margin":
                            Result = JJ.GetStringItem();    //get item - string
                            if (int.TryParse(Result, out Number))
                            {
                                Gbls.TextMargin = Number;
                            }
                            break;
                        case "TabSize":
                            Result = JJ.GetStringItem();    //get item - string
                            if (int.TryParse(Result, out Number))
                            {
                                Gbls.TabSize = Number;
                            }
                            break;
                        default:
                            //an unexpected item will kill things!
                            Gbls.LG.WriteLog("Reject Token Type: " + ThisToken.Type.ToString() +
                                " -- " + ThisToken.Name);
                            limit = MaxConfig + 100;     //terminate the loop
                            break;
                    }
                }
                //else
                //{
                // --> this fix killed config reader
                //    //an unexpected item will kill things!
                //    Gbls.LG.WriteLog("Reject Token Type Else: " + ThisToken.Type.ToString() +
                //        " -- " + ThisToken.Name);
                //    limit = MaxConfig + 100;     //terminate the loop
                //}
                ThisToken = JJ.GetToken();  //first token should be '}'
            }
        }
    }
}
