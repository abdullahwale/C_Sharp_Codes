//------------------------------------------------------------------------------
//
//FILE: MacString.cs
//
//DESCRIPTION: This is a generic string macro class. It can be reused without
//all items being replaced. The using program puts replacemet items in. Replacement 
//items are marked as $xx$. The item names are not case sensitive. A replacement
//item can have a default value.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
//--- new
//$$
//$*comment$
//$"text"$
//$"text","default"$
//$"text","first","second","third"$
//--- old - original
//$text$           replace  text
//$.text.default$  replace with default value if none given
//$$               insert $ in output
//$*text$          comment - ignored
//$#text.op1,op2,op3,op4$  - option list
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: MacString
    //--------------------------------------------------------------------------
    public class MacString
    {
        // note: this is modified by use, might not be able to use a template
        // twice if defaults or option list
        public string MyTemplate;                   //Template string
        public Dictionary<string, string> Values;   //replacement values
        public List<string> Names;                  //replacement names
        public List<string> Defaults;               //default values
        public List<List<string>> Options;          //[0]name,[1]default,[2]option
        //2017 - combine replacements and values
        //<name> <default> or <name> <default, option, option, ... >
        public Dictionary<string, List<string>> ReplaceItems = new Dictionary<string, List<string>>();
        public StringBuilder SB;    //builds the final result

        int scpn;                   //scan pointer to build macro
        string ThisToken;           //current replace token
        bool ScanError = false;     //an error occured while scanning
        //----------------------------------------------------------------------
        //NAME: MacString
        //init the class
        //----------------------------------------------------------------------
        public MacString()
        {
            MyTemplate = "";
            Values = new Dictionary<string, string>();
            Names = new List<string>();
            Options = new List<List<string>>();
            ReplaceItems = new Dictionary<string, List<string>>();
            ThisToken = "";
        }
        //----------------------------------------------------------------------
        //NAME: MacString
        //init the class
        //----------------------------------------------------------------------
        public MacString(string Template)
        {
            MyTemplate = Template;
            ThisToken = "";
            MyTemplate = ExtractDefaults();
        }
        //----------------------------------------------------------------------
        //NAME: Template
        //This is a property so default values can be used for items
        //----------------------------------------------------------------------
        public string Template
        {
            get
            {
                return MyTemplate;
            }
            set
            {
                MyTemplate = value;
                MyTemplate = ExtractDefaults();
            }
        }
        //----------------------------------------------------------------------
        //a template validation may be needed - should be $name$ but an error
        //might be hard to find during debugging
        //----------------------------------------------------------------------
        //NAME: ExtractDefaults
        //rewrite of ExtractDefaults $"text"$ escape chars
        //----------------------------------------------------------------------
        string ExtractDefaults()
        {
            Values = new Dictionary<string, string>();
            Names = new List<string>();
            Defaults = new List<string>();
            Options = new List<List<string>>();
            List<string> ThisEntry = new List<string>();
            bool working = true;
            char chx;           //current scan character

            SB = new StringBuilder(MyTemplate.Length);
            scpn = 0;
            bool ScanError = false;

            Gbls.LG.WriteLog("ExtractDefaults");
            while (scpn < MyTemplate.Length)
            {
                chx = GetChar();
                if (chx == '$')
                {
                    chx = GetChar();
                    if (chx == '$')
                    {
                        SB.Append("$$");
                    }
                    else if (chx == '*')
                    {
                        chx = GetChar();
                        //ignore comment
                        while ((scpn < MyTemplate.Length) && (chx != '$'))
                        {
                            chx = GetChar();
                        }
                    }
                    //---- get string list 
                    else if (chx == '"')
                    {
                        ThisEntry = new List<string>();
                        working = true;
                        while (!ScanError && working)
                        {
                            ThisToken = GetStrToken();
                            ThisEntry.Add(ThisToken);
                            
                            //skip space and ','
                            chx = GetChar();
                            while ((scpn < MyTemplate.Length-1) && ((chx == ' ') || (chx == ',')))
                            {
                                chx = GetChar();
                            }
                            if (chx != '"')
                            {
                                working = false;
                            }
                        }
                        if (!Names.Contains(ThisEntry[0]))
                        {
                            Names.Add(ThisEntry[0]);
                            if (ThisEntry.Count > 1)
                            {
                                Defaults.Add(ThisEntry[1]);
                            }
                            else
                            {
                                Defaults.Add("");
                            }
                            Options.Add(ThisEntry);
                            ReplaceItems.Add(ThisEntry[0].ToLower(), ThisEntry);
                        }
                        //no need to remove stuff
                        SB.Append('$');
                        SB.Append(ThisEntry[0].ToLower());
                        SB.Append('$');
                    }
                    //-- simple replace name -- depracated
                    else
                    {
                        ThisToken = "";
                        //gather token - should be $name$
                        while ((!ScanError) && (chx != '$'))
                        {
                            ThisToken = ThisToken + chx;
                            chx = GetChar();
                            //need a size check for bad template or bad chars
                        }
                        if (!Names.Contains(ThisToken))
                        {
                            Names.Add(ThisToken);
                            Defaults.Add("");
                            ThisEntry = new List<string>();
                            ThisEntry.Add(ThisToken);
                            Options.Add(ThisEntry);
                            if(!ReplaceItems.ContainsKey (ThisToken.ToLower()))
                            {
                                ReplaceItems.Add(ThisToken.ToLower(), ThisEntry);
                            }
                        }
                        SB.Append('$');
                        SB.Append(ThisToken);
                        SB.Append('$');
                    }
                }
                else
                {
                    SB.Append(chx);
                }
            }
            return SB.ToString();
        }
        //----------------------------------------------------------------------
        //NAME: GetStrToken
        //we found '"' - now get the string
        //----------------------------------------------------------------------
        public string GetStrToken()
        {
            string EscapeStr = "\"\\/.$bnrt";        //escaped tokens
            string ReplaceStr = "\"\\/.$\b\n\r\t";   //values that were escaped
            int ndx = 0;
            char chx = ' ';
            char Dlim = '"';                        //string delimiter
            string ThisToken = "";
            
            chx = GetChar();
            //pickup chars until EOL or Dlim
            while ((!ScanError) && (chx != Dlim))
            {
                //need to save the string characters!
                if (chx == '\\')
                {
                    chx = GetChar(); 
                    ndx = EscapeStr.IndexOf(chx);
                    if (ndx >= 0)
                    {
                        chx = ReplaceStr[ndx];
                        ThisToken = ThisToken + chx;
                    }
                    else
                    {
                        ThisToken = ThisToken + " ";    //bad escape is space
                    }
                }
                else
                {
                    ThisToken = ThisToken + chx;
                }
                chx = GetChar();
            }
            return ThisToken;
        }
        //----------------------------------------------------------------------
        //NAME: MakeString
        //apply the values to the template  - replace $name with dictionary value
        //----------------------------------------------------------------------
        public string MakeString()
        {
            char chx;       //current scan character
            SB = new StringBuilder(MyTemplate.Length);
            scpn = 0;
            ScanError = false;

            while (scpn < MyTemplate.Length-1)
            {
                chx = GetChar();
                if (chx == '$')
                {
                    chx = GetChar();
                    if (chx == '$')
                    {
                        SB.Append('$');
                        scpn++;
                    }
                    else
                    {
                        ThisToken = "";
                        //gather token and insert replacement - should be $name$
                        while ((scpn < MyTemplate.Length-1)&&(chx != '$'))
                        {
                            ThisToken = ThisToken + chx;
                            chx = GetChar();
                            //need a size check for bad template or bad chars
                        }
                        //chx = GetChar();
                        ThisToken = ThisToken.ToUpper();
                        //if key not found, just ignore it
                        if (Values.ContainsKey(ThisToken))
                        {
                            SB.Append(Values[ThisToken]);
                        }
                        else
                        {
                            Gbls.LG.WriteLog("Not found Mac Token: " + ThisToken);
                        }
                    }
                }
                else
                {
                    SB.Append(chx);
                }
            }
            return SB.ToString();
        }
        //----------------------------------------------------------------------
        //NAME: NewValue
        //put a new key,value pair
        //----------------------------------------------------------------------
        public void NewValue(string key, string value)
        {
            key = key.ToUpper();
            if (Values.ContainsKey(key))
            {
                //update old key,value pair
                Values[key] = value;
            }
            else
            {
                //add new pair
                Values.Add(key, value);
            }
        }
        //----------------------------------------------------------------------
        //NAME: ClearValues
        //clear the dictionary -- allow reuse of template
        //----------------------------------------------------------------------
        public void ClearValues()
        {
            MyTemplate = ExtractDefaults();
            ThisToken = "";
        }
        //----------------------------------------------------------------------
        //NAME: NewTemplate
        //replace the current template text with the new string
        //----------------------------------------------------------------------
        public void NewTemplate(string NewTemp)
        {
            MyTemplate = NewTemp;
            MyTemplate = ExtractDefaults();
        }
        //----------------------------------------------------------------------
        //NAME: DumpValues
        //dump the dictionary to the log file
        //----------------------------------------------------------------------
        public void DumpValues()
        {
            foreach(KeyValuePair <string,string> KV in Values)
            {
                Gbls.LG.WriteLog("Replace: " + KV.Key + " : " + KV.Value);
            }
        }
        //----------------------------------------------------------------------
        //NAME: DumpNames
        //dump the dictionary to the log file
        //----------------------------------------------------------------------
        public void DumpNames()
        {
            foreach (string stx in Names)
            {
                Gbls.LG.WriteLog("Name: " + stx);
            }
        }
        //----------------------------------------------------------------------
        //NAME: GetNames
        //get the replacement names
        //----------------------------------------------------------------------
        public List<string> GetNames()
        {
            return Names;
        }
        //----------------------------------------------------------------------
        //NAME: GetDefaults
        //get the default replacement values
        //----------------------------------------------------------------------
        public List<string> GetDefaults()
        {
            return Defaults;
        }
        //----------------------------------------------------------------------
        //NAME: GetOptions
        //get the default replacement values
        //----------------------------------------------------------------------
        public List<List<string>> GetOptions()
        {
            return Options;
        }
        //----------------------------------------------------------------------
        //NAME: GetChar
        //get the next char and check for end of template
        //----------------------------------------------------------------------
        public Char GetChar()
        {
            Char Result = ' ';

            if (scpn > (MyTemplate.Length - 1))
            {
                Result = ' ';
                ScanError = true;
            }
            else
            {
                Result = MyTemplate[scpn];
                scpn++;
            }
            return Result;
        }
    }
}
