namespace Bartel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAddCategory = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDeleteFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRenameCat = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEditCatDesc = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuMakeCatalog = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEditSnip = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDeleteSnip = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMoveSnip = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRenameSnip = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSelectLibrary = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAutoClip = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEditorSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuLoggerTop = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuLogShow = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuLogClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuLogSave = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnNewSnip = new System.Windows.Forms.Button();
            this.btnCopyToClip = new System.Windows.Forms.Button();
            this.btnFind = new System.Windows.Forms.Button();
            this.btnExpand = new System.Windows.Forms.Button();
            this.btnDescription = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.btnCollapse = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tvSelect = new System.Windows.Forms.TreeView();
            this.label1 = new System.Windows.Forms.Label();
            this.lxbItem = new System.Windows.Forms.ListBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.btnWordWrapDesc = new System.Windows.Forms.Button();
            this.txbSnip = new System.Windows.Forms.TextBox();
            this.DescDisplay = new System.Windows.Forms.TextBox();
            this.btnWordWrapBody = new System.Windows.Forms.Button();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnCrypto = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1003, 25);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuAddCategory,
            this.mnuDeleteFolder,
            this.mnuRenameCat,
            this.mnuEditCatDesc,
            this.toolStripSeparator1,
            this.mnuMakeCatalog});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(109, 21);
            this.fileToolStripMenuItem.Text = "Folder Actions";
            // 
            // mnuAddCategory
            // 
            this.mnuAddCategory.Name = "mnuAddCategory";
            this.mnuAddCategory.Size = new System.Drawing.Size(218, 22);
            this.mnuAddCategory.Text = "Add Folder";
            this.mnuAddCategory.Click += new System.EventHandler(this.mnuAddCategory_Click);
            // 
            // mnuDeleteFolder
            // 
            this.mnuDeleteFolder.Name = "mnuDeleteFolder";
            this.mnuDeleteFolder.Size = new System.Drawing.Size(218, 22);
            this.mnuDeleteFolder.Text = "Delete Folder";
            this.mnuDeleteFolder.Click += new System.EventHandler(this.mnuDeleteFolder_Click);
            // 
            // mnuRenameCat
            // 
            this.mnuRenameCat.Name = "mnuRenameCat";
            this.mnuRenameCat.Size = new System.Drawing.Size(218, 22);
            this.mnuRenameCat.Text = "Rename Folder";
            this.mnuRenameCat.Click += new System.EventHandler(this.mnuRenameFolder_Click);
            // 
            // mnuEditCatDesc
            // 
            this.mnuEditCatDesc.Name = "mnuEditCatDesc";
            this.mnuEditCatDesc.Size = new System.Drawing.Size(218, 22);
            this.mnuEditCatDesc.Text = "Edit Folder Description";
            this.mnuEditCatDesc.Click += new System.EventHandler(this.mnuEditCatDesc_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(215, 6);
            // 
            // mnuMakeCatalog
            // 
            this.mnuMakeCatalog.Name = "mnuMakeCatalog";
            this.mnuMakeCatalog.Size = new System.Drawing.Size(218, 22);
            this.mnuMakeCatalog.Text = "Make Catalog";
            this.mnuMakeCatalog.Click += new System.EventHandler(this.mnuMakeCatalog_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuEditSnip,
            this.mnuDeleteSnip,
            this.mnuMoveSnip,
            this.mnuRenameSnip});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(97, 21);
            this.toolStripMenuItem1.Text = "Snip Actions";
            // 
            // mnuEditSnip
            // 
            this.mnuEditSnip.Name = "mnuEditSnip";
            this.mnuEditSnip.Size = new System.Drawing.Size(156, 22);
            this.mnuEditSnip.Text = "Edit Snip";
            this.mnuEditSnip.Click += new System.EventHandler(this.mnuEditSnip_Click);
            // 
            // mnuDeleteSnip
            // 
            this.mnuDeleteSnip.Name = "mnuDeleteSnip";
            this.mnuDeleteSnip.Size = new System.Drawing.Size(156, 22);
            this.mnuDeleteSnip.Text = "Delete Snip";
            this.mnuDeleteSnip.Click += new System.EventHandler(this.mnuDeleteSnip_Click);
            // 
            // mnuMoveSnip
            // 
            this.mnuMoveSnip.Name = "mnuMoveSnip";
            this.mnuMoveSnip.Size = new System.Drawing.Size(156, 22);
            this.mnuMoveSnip.Text = "Move Snip";
            this.mnuMoveSnip.Click += new System.EventHandler(this.mnuMoveSnip_Click);
            // 
            // mnuRenameSnip
            // 
            this.mnuRenameSnip.Name = "mnuRenameSnip";
            this.mnuRenameSnip.Size = new System.Drawing.Size(156, 22);
            this.mnuRenameSnip.Text = "Rename Snip";
            this.mnuRenameSnip.Click += new System.EventHandler(this.mnuRenameSnip_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuSelectLibrary,
            this.mnuAutoClip,
            this.mnuEditorSettings});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(70, 21);
            this.toolStripMenuItem2.Text = "Settings";
            // 
            // mnuSelectLibrary
            // 
            this.mnuSelectLibrary.Name = "mnuSelectLibrary";
            this.mnuSelectLibrary.Size = new System.Drawing.Size(193, 22);
            this.mnuSelectLibrary.Text = "Select Library";
            this.mnuSelectLibrary.Click += new System.EventHandler(this.mnuSelectLibrary_Click);
            // 
            // mnuAutoClip
            // 
            this.mnuAutoClip.Name = "mnuAutoClip";
            this.mnuAutoClip.Size = new System.Drawing.Size(193, 22);
            this.mnuAutoClip.Text = "Auto Clip Copy Off";
            this.mnuAutoClip.Click += new System.EventHandler(this.mnuAutoClip_Click);
            // 
            // mnuEditorSettings
            // 
            this.mnuEditorSettings.Name = "mnuEditorSettings";
            this.mnuEditorSettings.Size = new System.Drawing.Size(193, 22);
            this.mnuEditorSettings.Text = "Editor";
            this.mnuEditorSettings.Click += new System.EventHandler(this.mnuEditorSettings_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuLoggerTop,
            this.mnuHelp,
            this.mnuAbout});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(49, 21);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // mnuLoggerTop
            // 
            this.mnuLoggerTop.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuLogShow,
            this.mnuLogClose,
            this.mnuLogSave});
            this.mnuLoggerTop.Name = "mnuLoggerTop";
            this.mnuLoggerTop.Size = new System.Drawing.Size(119, 22);
            this.mnuLoggerTop.Text = "Logger";
            this.mnuLoggerTop.Visible = false;
            // 
            // mnuLogShow
            // 
            this.mnuLogShow.Name = "mnuLogShow";
            this.mnuLogShow.Size = new System.Drawing.Size(109, 22);
            this.mnuLogShow.Text = "Show";
            this.mnuLogShow.Click += new System.EventHandler(this.mnuLogShow_Click);
            // 
            // mnuLogClose
            // 
            this.mnuLogClose.Name = "mnuLogClose";
            this.mnuLogClose.Size = new System.Drawing.Size(109, 22);
            this.mnuLogClose.Text = "Close";
            this.mnuLogClose.Click += new System.EventHandler(this.mnuLogClose_Click);
            // 
            // mnuLogSave
            // 
            this.mnuLogSave.Name = "mnuLogSave";
            this.mnuLogSave.Size = new System.Drawing.Size(109, 22);
            this.mnuLogSave.Text = "Save";
            this.mnuLogSave.Click += new System.EventHandler(this.mnuLogSave_Click);
            // 
            // mnuHelp
            // 
            this.mnuHelp.Name = "mnuHelp";
            this.mnuHelp.Size = new System.Drawing.Size(119, 22);
            this.mnuHelp.Text = "Help";
            this.mnuHelp.Click += new System.EventHandler(this.mnuHelp_Click);
            // 
            // mnuAbout
            // 
            this.mnuAbout.Name = "mnuAbout";
            this.mnuAbout.Size = new System.Drawing.Size(119, 22);
            this.mnuAbout.Text = "About";
            this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 578);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1003, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(85, 17);
            this.toolStripStatusLabel1.Text = "Active Library: ";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel.Text = "toolStripStatusLabel1";
            // 
            // btnNewSnip
            // 
            this.btnNewSnip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNewSnip.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewSnip.Location = new System.Drawing.Point(230, 29);
            this.btnNewSnip.Name = "btnNewSnip";
            this.btnNewSnip.Size = new System.Drawing.Size(100, 33);
            this.btnNewSnip.TabIndex = 11;
            this.btnNewSnip.Text = "New Snip";
            this.btnNewSnip.UseVisualStyleBackColor = true;
            this.btnNewSnip.Click += new System.EventHandler(this.btnNewSnip_Click);
            // 
            // btnCopyToClip
            // 
            this.btnCopyToClip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCopyToClip.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyToClip.Location = new System.Drawing.Point(890, 29);
            this.btnCopyToClip.Name = "btnCopyToClip";
            this.btnCopyToClip.Size = new System.Drawing.Size(100, 33);
            this.btnCopyToClip.TabIndex = 30;
            this.btnCopyToClip.Text = "Copy";
            this.btnCopyToClip.UseVisualStyleBackColor = true;
            this.btnCopyToClip.Click += new System.EventHandler(this.btnCopyToClip_Click);
            // 
            // btnFind
            // 
            this.btnFind.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFind.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFind.Location = new System.Drawing.Point(340, 29);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(100, 33);
            this.btnFind.TabIndex = 29;
            this.btnFind.Text = "Find Snip";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // btnExpand
            // 
            this.btnExpand.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExpand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExpand.Location = new System.Drawing.Point(450, 29);
            this.btnExpand.Name = "btnExpand";
            this.btnExpand.Size = new System.Drawing.Size(100, 33);
            this.btnExpand.TabIndex = 28;
            this.btnExpand.Text = "Expand Macro";
            this.btnExpand.UseVisualStyleBackColor = true;
            this.btnExpand.Click += new System.EventHandler(this.btnExpand_Click);
            // 
            // btnDescription
            // 
            this.btnDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDescription.Location = new System.Drawing.Point(560, 28);
            this.btnDescription.Name = "btnDescription";
            this.btnDescription.Size = new System.Drawing.Size(100, 34);
            this.btnDescription.TabIndex = 25;
            this.btnDescription.Text = "Edit Snip";
            this.btnDescription.UseVisualStyleBackColor = true;
            this.btnDescription.Click += new System.EventHandler(this.mnuEditSnip_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(670, 29);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 33);
            this.button2.TabIndex = 26;
            this.button2.Text = "- nothing -";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Location = new System.Drawing.Point(9, 67);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(987, 508);
            this.splitContainer1.SplitterDistance = 272;
            this.splitContainer1.TabIndex = 31;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.btnCollapse);
            this.splitContainer3.Panel1.Controls.Add(this.label2);
            this.splitContainer3.Panel1.Controls.Add(this.tvSelect);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.label1);
            this.splitContainer3.Panel2.Controls.Add(this.lxbItem);
            this.splitContainer3.Size = new System.Drawing.Size(270, 506);
            this.splitContainer3.SplitterDistance = 253;
            this.splitContainer3.TabIndex = 32;
            // 
            // btnCollapse
            // 
            this.btnCollapse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCollapse.Location = new System.Drawing.Point(207, 4);
            this.btnCollapse.Name = "btnCollapse";
            this.btnCollapse.Size = new System.Drawing.Size(60, 23);
            this.btnCollapse.TabIndex = 23;
            this.btnCollapse.Text = "Collapse";
            this.btnCollapse.UseVisualStyleBackColor = true;
            this.btnCollapse.Click += new System.EventHandler(this.btnCollapse_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.LightGray;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 23);
            this.label2.TabIndex = 22;
            this.label2.Text = "Snip Folder";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tvSelect
            // 
            this.tvSelect.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tvSelect.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvSelect.Location = new System.Drawing.Point(3, 28);
            this.tvSelect.Name = "tvSelect";
            this.tvSelect.Size = new System.Drawing.Size(264, 220);
            this.tvSelect.TabIndex = 17;
            this.tvSelect.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvSelect_AfterSelect);
            this.tvSelect.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tvSelect_MouseDown);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.LightGray;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 23);
            this.label1.TabIndex = 21;
            this.label1.Text = "Snip Item";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lxbItem
            // 
            this.lxbItem.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lxbItem.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lxbItem.FormattingEnabled = true;
            this.lxbItem.ItemHeight = 12;
            this.lxbItem.Location = new System.Drawing.Point(3, 30);
            this.lxbItem.Name = "lxbItem";
            this.lxbItem.ScrollAlwaysVisible = true;
            this.lxbItem.Size = new System.Drawing.Size(264, 208);
            this.lxbItem.TabIndex = 14;
            this.lxbItem.SelectedIndexChanged += new System.EventHandler(this.lxbItem_SelectedIndexChanged);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.btnWordWrapDesc);
            this.splitContainer2.Panel1.Controls.Add(this.txbSnip);
            this.splitContainer2.Panel1.Controls.Add(this.DescDisplay);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.btnWordWrapBody);
            this.splitContainer2.Panel2.Controls.Add(this.txtDisplay);
            this.splitContainer2.Panel2.Controls.Add(this.textBox1);
            this.splitContainer2.Size = new System.Drawing.Size(709, 506);
            this.splitContainer2.SplitterDistance = 250;
            this.splitContainer2.TabIndex = 0;
            // 
            // btnWordWrapDesc
            // 
            this.btnWordWrapDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWordWrapDesc.Location = new System.Drawing.Point(630, 2);
            this.btnWordWrapDesc.Name = "btnWordWrapDesc";
            this.btnWordWrapDesc.Size = new System.Drawing.Size(75, 23);
            this.btnWordWrapDesc.TabIndex = 10;
            this.btnWordWrapDesc.Text = "word wrap";
            this.btnWordWrapDesc.UseVisualStyleBackColor = true;
            this.btnWordWrapDesc.Click += new System.EventHandler(this.btnWordWrapDesc_Click);
            // 
            // txbSnip
            // 
            this.txbSnip.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txbSnip.BackColor = System.Drawing.Color.LightGray;
            this.txbSnip.Enabled = false;
            this.txbSnip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSnip.Location = new System.Drawing.Point(7, 4);
            this.txbSnip.Name = "txbSnip";
            this.txbSnip.ReadOnly = true;
            this.txbSnip.Size = new System.Drawing.Size(618, 22);
            this.txbSnip.TabIndex = 8;
            this.txbSnip.Text = "Description";
            this.txbSnip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DescDisplay
            // 
            this.DescDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.DescDisplay.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DescDisplay.Location = new System.Drawing.Point(7, 27);
            this.DescDisplay.Multiline = true;
            this.DescDisplay.Name = "DescDisplay";
            this.DescDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DescDisplay.Size = new System.Drawing.Size(698, 220);
            this.DescDisplay.TabIndex = 9;
            this.DescDisplay.WordWrap = false;
            // 
            // btnWordWrapBody
            // 
            this.btnWordWrapBody.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWordWrapBody.Location = new System.Drawing.Point(630, 3);
            this.btnWordWrapBody.Name = "btnWordWrapBody";
            this.btnWordWrapBody.Size = new System.Drawing.Size(75, 23);
            this.btnWordWrapBody.TabIndex = 11;
            this.btnWordWrapBody.Text = "word wrap";
            this.btnWordWrapBody.UseVisualStyleBackColor = true;
            this.btnWordWrapBody.Click += new System.EventHandler(this.btnWordWrapBody_Click);
            // 
            // txtDisplay
            // 
            this.txtDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDisplay.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.Location = new System.Drawing.Point(7, 27);
            this.txtDisplay.Multiline = true;
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDisplay.Size = new System.Drawing.Size(698, 220);
            this.txtDisplay.TabIndex = 10;
            this.txtDisplay.WordWrap = false;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.BackColor = System.Drawing.Color.LightGray;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(6, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(618, 22);
            this.textBox1.TabIndex = 9;
            this.textBox1.Text = "Snip Body";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(780, 29);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 33);
            this.button3.TabIndex = 32;
            this.button3.Text = "- nothing -";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(120, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 33);
            this.button1.TabIndex = 33;
            this.button1.Text = "- nothing -";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            // 
            // btnCrypto
            // 
            this.btnCrypto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCrypto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrypto.Location = new System.Drawing.Point(10, 29);
            this.btnCrypto.Name = "btnCrypto";
            this.btnCrypto.Size = new System.Drawing.Size(100, 33);
            this.btnCrypto.TabIndex = 34;
            this.btnCrypto.Text = "Crypto";
            this.btnCrypto.UseVisualStyleBackColor = true;
            this.btnCrypto.Click += new System.EventHandler(this.btnCrypto_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(1003, 600);
            this.Controls.Add(this.btnCrypto);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.btnCopyToClip);
            this.Controls.Add(this.btnFind);
            this.Controls.Add(this.btnExpand);
            this.Controls.Add(this.btnDescription);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnNewSnip);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuAbout;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mnuEditSnip;
        private System.Windows.Forms.ToolStripMenuItem mnuDeleteSnip;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem mnuSelectLibrary;
        private System.Windows.Forms.ToolStripMenuItem mnuAutoClip;
        private System.Windows.Forms.ToolStripMenuItem mnuAddCategory;
        private System.Windows.Forms.ToolStripMenuItem mnuEditCatDesc;
        private System.Windows.Forms.ToolStripMenuItem mnuMakeCatalog;
        private System.Windows.Forms.ToolStripMenuItem mnuRenameSnip;
        private System.Windows.Forms.ToolStripMenuItem mnuRenameCat;
        private System.Windows.Forms.ToolStripMenuItem mnuDeleteFolder;
        private System.Windows.Forms.ToolStripMenuItem mnuMoveSnip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Button btnNewSnip;
        private System.Windows.Forms.Button btnCopyToClip;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Button btnExpand;
        private System.Windows.Forms.Button btnDescription;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Button btnCollapse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TreeView tvSelect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lxbItem;
        private System.Windows.Forms.TextBox txbSnip;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox DescDisplay;
        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.Button btnWordWrapDesc;
        private System.Windows.Forms.Button btnWordWrapBody;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button btnCrypto;
        private System.Windows.Forms.ToolStripMenuItem mnuEditorSettings;
        private System.Windows.Forms.ToolStripMenuItem mnuLoggerTop;
        private System.Windows.Forms.ToolStripMenuItem mnuLogShow;
        private System.Windows.Forms.ToolStripMenuItem mnuLogClose;
        private System.Windows.Forms.ToolStripMenuItem mnuLogSave;
    }
}

