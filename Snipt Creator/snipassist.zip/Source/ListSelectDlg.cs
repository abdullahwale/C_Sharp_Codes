//------------------------------------------------------------------------------
//
//FILE: ListSelectDlg.cs
//
//DESCRIPTION: This is a simple dialog that has a list box.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: ListSelectDlg
    //--------------------------------------------------------------------------
    public partial class ListSelectDlg : Form
    {
        public string MyTitle = "ListSelectDlg";
        public string SelectedItem = "";
        public string[] MyItems;
        public Color MyColor = Color.LightBlue;

        //----------------------------------------------------------------------
        //NAME: ListSelectDlg
        //init the dialog
        //----------------------------------------------------------------------
        public ListSelectDlg()
        {
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: ListSelectDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void ListSelectDlg_Shown(object sender, EventArgs e)
        {
            this.BackColor = MyColor;

            listBox1.Items.AddRange(MyItems);
            //select the first item as the default
            if (MyItems.Length > 0)
            {
                listBox1.SelectedIndex = 0;
            }
            this.Text = MyTitle;
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
            MyTitle = title;
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it, go home
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            SelectedItem = "";
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: listBox1_SelectedIndexChanged
        //
        //----------------------------------------------------------------------
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                SelectedItem = listBox1.SelectedItem.ToString();
            }
        }
    }
}