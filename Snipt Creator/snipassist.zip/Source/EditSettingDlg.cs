//------------------------------------------------------------------------------
//
//FILE: EditSettingDlg.cs
//
//DESCRIPTION: This will get editor settings like margin and tab size
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: EditSettingDlg
    //--------------------------------------------------------------------------
    public partial class EditSettingDlg : Form
    {
        public string MyTitle = "Editor Settings";
        public int SetMargin = 80;      //caller fills this in
        public int SetTab = 4;          //caller fills this in

        //----------------------------------------------------------------------
        //NAME: EditSettingDlg
        //init the dialog
        //----------------------------------------------------------------------
        public EditSettingDlg()
        {
            InitializeComponent(); 
            ContextMenuMgr.SetStrip(txbMargin);
            ContextMenuMgr.SetStrip(txbTabSize);
        }
        //----------------------------------------------------------------------
        //NAME: EditSettingDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void EditSettingDlg_Shown(object sender, EventArgs e)
        {
            //display the current set of data
            this.Text = MyTitle;
            txbMargin.Text = SetMargin.ToString();
            txbTabSize.Text = SetTab.ToString();
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
            MyTitle = title;
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            Int32 Value = 0;
            Int32.TryParse(txbMargin.Text, out Value);
            SetMargin = Value;
            Int32.TryParse(txbTabSize.Text, out Value);
            SetTab = Value;

            DialogResult = DialogResult.OK;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}