//------------------------------------------------------------------------------
//
//FILE: DirectorySelectDlg.cs
//
//DESCRIPTION: This is a dialog that allows a user to select a directory. The
// files in the directory are displayed but cannot be selected.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: DirectorySelectDlg
    //--------------------------------------------------------------------------
    public partial class DirectorySelectDlg : Form
    {
        public string MyTitle = "Directory Selection";
        public string StartPath = "";  //"C:\\";
        public TreeNode CurntNode = null;
        public Color NewBackColor = Color.Coral;
        public string SelectedDirectory = "";

        //----------------------------------------------------------------------
        //NAME: DirectorySelectDlg
        //init the dialog
        //----------------------------------------------------------------------
        public DirectorySelectDlg()
        {
            InitializeComponent();
            txbFiles.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
            txbDirectory.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
            cmbDrive.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();
        }
        //----------------------------------------------------------------------
        //NAME: DirectorySelectDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void DirectorySelectDlg_Shown(object sender, EventArgs e)
        {
            string stx = "";
            tvDirectory.Nodes.Clear();
            TreeNode Tn;
            DriveInfo[] allDrives = DriveInfo.GetDrives();
            foreach (DriveInfo d in allDrives)
            {
                try
                {
                    stx = d.Name;
                    stx = stx.Replace("\\", "");
                    cmbDrive.Items.Add(stx + "  " + d.VolumeLabel);
                    Tn = GetDirContent(d.Name);
                    if (Tn != null)
                    {
                        tvDirectory.Nodes.Add(Tn);
                    }
                }
                catch { };
            }
            cmbDrive.Text = cmbDrive.Items[0].ToString();
            //PopulateTv(tvDirectory, StartPath);
            this.BackColor = NewBackColor;
            this.Text = MyTitle;
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
        }
        //----------------------------------------------------------------------
        //NAME: btnOK_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnOK_Click(object sender, EventArgs e)
        {
            SelectedDirectory = txbDirectory.Text;
            DialogResult = DialogResult.OK;
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            SelectedDirectory = "";
            DialogResult = DialogResult.Cancel;
        }
        //----------------------------------------------------------------------
        //NAME: tvDirectory_AfterSelect
        //
        //----------------------------------------------------------------------
        private void tvDirectory_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {
                if (CurntNode != null)
                {
                    CurntNode.BackColor = Color.Empty;
                }
                txbFiles.Text = "";

                int jj;
                TreeNode TN = tvDirectory.SelectedNode;
                string FPath = StartPath + TN.FullPath;
                string[] MyFiles = Directory.GetFiles(FPath);
                FileInfo FI;
                StringBuilder SB = new StringBuilder();

                TN.BackColor = Color.LightBlue;
                CurntNode = TN;

                for (jj = 0; jj < MyFiles.Length; jj++)
                {
                    FI = new FileInfo(MyFiles[jj]);
                    SB.AppendLine(FI.Name);
                }
                txbFiles.Text = SB.ToString();
                string stx = StartPath + TN.FullPath;
                txbDirectory.Text = stx.Replace("\\\\", "\\");

                foreach (TreeNode tnn in TN.Nodes)
                {
                    FPath = StartPath + tnn.FullPath;
                    DirectoryInfo DI = new DirectoryInfo(FPath);
                    try
                    {
                        DirectoryInfo[] Subdirs = DI.GetDirectories();
                        tnn.Nodes.Clear();
                        for (jj = 0; jj < Subdirs.Length; jj++)
                        {
                            tnn.Nodes.Add(Subdirs[jj].Name);
                        }
                    }
                    catch { }
                }
                tvDirectory.Update();
            }
            catch { }
        }
        //----------------------------------------------------------------------
        //NAME: GetDirContent
        //get the directoies of this directory and any sub directoies
        //----------------------------------------------------------------------
        public TreeNode GetDirContent(string MyDir)
        {
            int jj;
            TreeNode TN = new TreeNode();
            DirectoryInfo DI = new DirectoryInfo(MyDir);
            DirectoryInfo[] Subdirs;
            try
            {
                Subdirs = DI.GetDirectories();
            }
            catch
            {
                return null;
            }

            TN.Text = DI.Name;
            TN.Tag = "D";       //directory node
            for (jj = 0; jj < Subdirs.Length; jj++)
            {
                TN.Nodes.Add(Subdirs[jj].Name);
            }
            return TN;
        }
        //----------------------------------------------------------------------
        //NAME: tvDirectory_AfterExpand
        //A node was expanded
        //----------------------------------------------------------------------
        private void tvDirectory_AfterExpand(object sender, TreeViewEventArgs e)
        {
            TreeNode TN = e.Node;
            string NPath = StartPath + TN.FullPath;
            TreeView TV = (TreeView)sender;
            TV.SelectedNode = TN;
        }
        //----------------------------------------------------------------------
        //NAME: comboBox1_SelectedIndexChanged
        //
        //----------------------------------------------------------------------
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //make new tree starting at the root of the disk
        }
        //----------------------------------------------------------------------
        //NAME: btnUp_Click
        //go up one level in the tree
        //----------------------------------------------------------------------
        private void btnUp_Click(object sender, EventArgs e)
        {
            try
            {
                TreeNode TN = tvDirectory.SelectedNode;
                TreeNode Par = TN.Parent;

                tvDirectory.SelectedNode = Par;
                TN.Collapse();
            }
            catch { }
        }
        //----------------------------------------------------------------------
        //NAME: btnColapse_Click
        //
        //----------------------------------------------------------------------
        private void btnColapse_Click(object sender, EventArgs e)
        {
            tvDirectory.CollapseAll();
            txbFiles.Text = "";
        }
        //----------------------------------------------------------------------
        //NAME: tvDirectory_MouseDown
        //allow right mouse click to select node
        //----------------------------------------------------------------------
        private void tvDirectory_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                TreeNode MyTn = tvDirectory.GetNodeAt(e.Location);
                if (MyTn != null)
                {
                    tvDirectory.SelectedNode = MyTn;
                }
            }
        }
    }
}