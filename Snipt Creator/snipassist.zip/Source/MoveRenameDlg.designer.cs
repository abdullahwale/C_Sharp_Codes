namespace Bartel
{
    partial class MoveRenameDlg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBoxSrc = new System.Windows.Forms.GroupBox();
            this.btnSrcSelect = new System.Windows.Forms.Button();
            this.txbSrc = new System.Windows.Forms.TextBox();
            this.lblSrc = new System.Windows.Forms.Label();
            this.groupBoxDest = new System.Windows.Forms.GroupBox();
            this.btnDestSelect = new System.Windows.Forms.Button();
            this.txbDest = new System.Windows.Forms.TextBox();
            this.lblDest = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.groupBoxSrc.SuspendLayout();
            this.groupBoxDest.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(251, 266);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(378, 266);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // groupBoxSrc
            // 
            this.groupBoxSrc.Controls.Add(this.btnSrcSelect);
            this.groupBoxSrc.Controls.Add(this.txbSrc);
            this.groupBoxSrc.Controls.Add(this.lblSrc);
            this.groupBoxSrc.Location = new System.Drawing.Point(12, 45);
            this.groupBoxSrc.Name = "groupBoxSrc";
            this.groupBoxSrc.Size = new System.Drawing.Size(451, 100);
            this.groupBoxSrc.TabIndex = 2;
            this.groupBoxSrc.TabStop = false;
            this.groupBoxSrc.Text = "src";
            // 
            // btnSrcSelect
            // 
            this.btnSrcSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSrcSelect.Location = new System.Drawing.Point(317, 30);
            this.btnSrcSelect.Name = "btnSrcSelect";
            this.btnSrcSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSrcSelect.TabIndex = 2;
            this.btnSrcSelect.Text = "button1";
            this.btnSrcSelect.UseVisualStyleBackColor = true;
            this.btnSrcSelect.Visible = false;
            // 
            // txbSrc
            // 
            this.txbSrc.Location = new System.Drawing.Point(16, 62);
            this.txbSrc.Name = "txbSrc";
            this.txbSrc.ReadOnly = true;
            this.txbSrc.Size = new System.Drawing.Size(413, 20);
            this.txbSrc.TabIndex = 1;
            // 
            // lblSrc
            // 
            this.lblSrc.AutoSize = true;
            this.lblSrc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSrc.Location = new System.Drawing.Point(15, 27);
            this.lblSrc.Name = "lblSrc";
            this.lblSrc.Size = new System.Drawing.Size(52, 15);
            this.lblSrc.TabIndex = 0;
            this.lblSrc.Text = "Source";
            // 
            // groupBoxDest
            // 
            this.groupBoxDest.Controls.Add(this.btnDestSelect);
            this.groupBoxDest.Controls.Add(this.txbDest);
            this.groupBoxDest.Controls.Add(this.lblDest);
            this.groupBoxDest.Location = new System.Drawing.Point(12, 150);
            this.groupBoxDest.Name = "groupBoxDest";
            this.groupBoxDest.Size = new System.Drawing.Size(451, 100);
            this.groupBoxDest.TabIndex = 3;
            this.groupBoxDest.TabStop = false;
            this.groupBoxDest.Text = "Dest";
            // 
            // btnDestSelect
            // 
            this.btnDestSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDestSelect.Location = new System.Drawing.Point(293, 30);
            this.btnDestSelect.Name = "btnDestSelect";
            this.btnDestSelect.Size = new System.Drawing.Size(99, 23);
            this.btnDestSelect.TabIndex = 2;
            this.btnDestSelect.Text = "Select Dest";
            this.btnDestSelect.UseVisualStyleBackColor = true;
            this.btnDestSelect.Click += new System.EventHandler(this.btnDestSelect_Click);
            // 
            // txbDest
            // 
            this.txbDest.Location = new System.Drawing.Point(16, 62);
            this.txbDest.Name = "txbDest";
            this.txbDest.Size = new System.Drawing.Size(413, 20);
            this.txbDest.TabIndex = 1;
            // 
            // lblDest
            // 
            this.lblDest.AutoSize = true;
            this.lblDest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDest.Location = new System.Drawing.Point(15, 27);
            this.lblDest.Name = "lblDest";
            this.lblDest.Size = new System.Drawing.Size(80, 15);
            this.lblDest.TabIndex = 0;
            this.lblDest.Text = "Destination";
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(164, 14);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(137, 23);
            this.lblTitle.TabIndex = 4;
            this.lblTitle.Text = "label1";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MoveRenameDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(476, 311);
            this.ControlBox = false;
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.groupBoxDest);
            this.Controls.Add(this.groupBoxSrc);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "MoveRenameDlg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "MoveRenameDlg";
            this.Shown += new System.EventHandler(this.MoveRenameDlg_Shown);
            this.groupBoxSrc.ResumeLayout(false);
            this.groupBoxSrc.PerformLayout();
            this.groupBoxDest.ResumeLayout(false);
            this.groupBoxDest.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox groupBoxSrc;
        private System.Windows.Forms.Button btnSrcSelect;
        private System.Windows.Forms.TextBox txbSrc;
        private System.Windows.Forms.Label lblSrc;
        private System.Windows.Forms.GroupBox groupBoxDest;
        private System.Windows.Forms.Button btnDestSelect;
        private System.Windows.Forms.TextBox txbDest;
        private System.Windows.Forms.Label lblDest;
        private System.Windows.Forms.Label lblTitle;
    }
}