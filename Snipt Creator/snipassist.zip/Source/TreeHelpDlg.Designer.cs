namespace Bartel
{
    partial class TreeHelpDlg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tvNavigate = new System.Windows.Forms.TreeView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lsvIndexList = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lsvSearch = new System.Windows.Forms.ListView();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.chkLookText = new System.Windows.Forms.CheckBox();
            this.chkLookLabel = new System.Windows.Forms.CheckBox();
            this.chkNoCase = new System.Windows.Forms.CheckBox();
            this.cmbxSearch = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.navigeteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txbMainText = new System.Windows.Forms.TextBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.HelpTextDisplay = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            this.splitContainer1.Panel1.Controls.Add(this.menuStrip3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.txbMainText);
            this.splitContainer1.Panel2.Controls.Add(this.menuStrip2);
            this.splitContainer1.Size = new System.Drawing.Size(802, 446);
            this.splitContainer1.SplitterDistance = 207;
            this.splitContainer1.TabIndex = 2;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(207, 422);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tvNavigate);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(199, 396);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Contents";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tvNavigate
            // 
            this.tvNavigate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvNavigate.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvNavigate.Location = new System.Drawing.Point(3, 3);
            this.tvNavigate.Name = "tvNavigate";
            this.tvNavigate.Size = new System.Drawing.Size(193, 390);
            this.tvNavigate.TabIndex = 2;
            this.tvNavigate.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvNavigate_AfterSelect);
            this.tvNavigate.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tvNavigate_MouseDown);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightGreen;
            this.tabPage2.Controls.Add(this.lsvIndexList);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(199, 396);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Index";
            // 
            // lsvIndexList
            // 
            this.lsvIndexList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lsvIndexList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvIndexList.FullRowSelect = true;
            this.lsvIndexList.GridLines = true;
            this.lsvIndexList.HideSelection = false;
            this.lsvIndexList.Location = new System.Drawing.Point(3, 3);
            this.lsvIndexList.Name = "lsvIndexList";
            this.lsvIndexList.Size = new System.Drawing.Size(193, 390);
            this.lsvIndexList.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.lsvIndexList.TabIndex = 3;
            this.lsvIndexList.UseCompatibleStateImageBehavior = false;
            this.lsvIndexList.View = System.Windows.Forms.View.Details;
            this.lsvIndexList.SelectedIndexChanged += new System.EventHandler(this.lsvIndexList_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Item";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Full Path";
            this.columnHeader2.Width = 100;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.PaleGreen;
            this.tabPage3.Controls.Add(this.btnSearch);
            this.tabPage3.Controls.Add(this.lsvSearch);
            this.tabPage3.Controls.Add(this.chkLookText);
            this.tabPage3.Controls.Add(this.chkLookLabel);
            this.tabPage3.Controls.Add(this.chkNoCase);
            this.tabPage3.Controls.Add(this.cmbxSearch);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(199, 396);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Search";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(108, 74);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lsvSearch
            // 
            this.lsvSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lsvSearch.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.lsvSearch.FullRowSelect = true;
            this.lsvSearch.GridLines = true;
            this.lsvSearch.HideSelection = false;
            this.lsvSearch.Location = new System.Drawing.Point(5, 101);
            this.lsvSearch.MultiSelect = false;
            this.lsvSearch.Name = "lsvSearch";
            this.lsvSearch.Size = new System.Drawing.Size(186, 292);
            this.lsvSearch.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.lsvSearch.TabIndex = 3;
            this.lsvSearch.UseCompatibleStateImageBehavior = false;
            this.lsvSearch.View = System.Windows.Forms.View.Details;
            this.lsvSearch.SelectedIndexChanged += new System.EventHandler(this.lsvSearch_SelectedIndexChanged);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Label";
            this.columnHeader3.Width = 90;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Path";
            this.columnHeader4.Width = 80;
            // 
            // chkLookText
            // 
            this.chkLookText.AutoSize = true;
            this.chkLookText.Checked = true;
            this.chkLookText.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkLookText.Location = new System.Drawing.Point(8, 78);
            this.chkLookText.Name = "chkLookText";
            this.chkLookText.Size = new System.Drawing.Size(85, 17);
            this.chkLookText.TabIndex = 5;
            this.chkLookText.Text = "Look in Text";
            this.chkLookText.UseVisualStyleBackColor = true;
            // 
            // chkLookLabel
            // 
            this.chkLookLabel.AutoSize = true;
            this.chkLookLabel.Checked = true;
            this.chkLookLabel.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkLookLabel.Location = new System.Drawing.Point(10, 56);
            this.chkLookLabel.Name = "chkLookLabel";
            this.chkLookLabel.Size = new System.Drawing.Size(90, 17);
            this.chkLookLabel.TabIndex = 4;
            this.chkLookLabel.Text = "Look in Label";
            this.chkLookLabel.UseVisualStyleBackColor = true;
            // 
            // chkNoCase
            // 
            this.chkNoCase.AutoSize = true;
            this.chkNoCase.Checked = true;
            this.chkNoCase.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkNoCase.Location = new System.Drawing.Point(106, 56);
            this.chkNoCase.Name = "chkNoCase";
            this.chkNoCase.Size = new System.Drawing.Size(67, 17);
            this.chkNoCase.TabIndex = 2;
            this.chkNoCase.Text = "No Case";
            this.chkNoCase.UseVisualStyleBackColor = true;
            // 
            // cmbxSearch
            // 
            this.cmbxSearch.FormattingEnabled = true;
            this.cmbxSearch.Location = new System.Drawing.Point(8, 29);
            this.cmbxSearch.Name = "cmbxSearch";
            this.cmbxSearch.Size = new System.Drawing.Size(175, 21);
            this.cmbxSearch.TabIndex = 2;
            this.cmbxSearch.SelectedIndexChanged += new System.EventHandler(this.cmbxSearch_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Info;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Search For:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip3
            // 
            this.menuStrip3.BackColor = System.Drawing.Color.PaleGreen;
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.navigeteToolStripMenuItem});
            this.menuStrip3.Location = new System.Drawing.Point(0, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(207, 24);
            this.menuStrip3.TabIndex = 1;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // navigeteToolStripMenuItem
            // 
            this.navigeteToolStripMenuItem.Enabled = false;
            this.navigeteToolStripMenuItem.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.navigeteToolStripMenuItem.Name = "navigeteToolStripMenuItem";
            this.navigeteToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.navigeteToolStripMenuItem.Text = "Navigate";
            // 
            // txbMainText
            // 
            this.txbMainText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txbMainText.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbMainText.Location = new System.Drawing.Point(0, 24);
            this.txbMainText.Multiline = true;
            this.txbMainText.Name = "txbMainText";
            this.txbMainText.ReadOnly = true;
            this.txbMainText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txbMainText.Size = new System.Drawing.Size(591, 422);
            this.txbMainText.TabIndex = 1;
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.PaleGreen;
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.HelpTextDisplay});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(591, 24);
            this.menuStrip2.TabIndex = 0;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // HelpTextDisplay
            // 
            this.HelpTextDisplay.Enabled = false;
            this.HelpTextDisplay.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HelpTextDisplay.Name = "HelpTextDisplay";
            this.HelpTextDisplay.Size = new System.Drawing.Size(207, 20);
            this.HelpTextDisplay.Text = "Help Text Display";
            // 
            // TreeHelpDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 446);
            this.Controls.Add(this.splitContainer1);
            this.Name = "TreeHelpDlg";
            this.Text = "TreeHelpDlg";
            this.Shown += new System.EventHandler(this.TreeHelpDlg_Shown);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txbMainText;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TreeView tvNavigate;
        private System.Windows.Forms.ToolStripMenuItem navigeteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HelpTextDisplay;
        private System.Windows.Forms.CheckBox chkLookText;
        private System.Windows.Forms.CheckBox chkLookLabel;
        private System.Windows.Forms.CheckBox chkNoCase;
        private System.Windows.Forms.ComboBox cmbxSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lsvIndexList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ListView lsvSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
    }
}