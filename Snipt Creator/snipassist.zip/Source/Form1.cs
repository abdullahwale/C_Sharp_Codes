//------------------------------------------------------------------------------
//
//NAME: Form1.cs
//
//DESCRIPTION: This is the main form for SnipAssist a program to manage small
//pieces of something for working with text. The clipboard is used as the 
//transfer mechanism between programs.
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Form1
    //--------------------------------------------------------------------------
    public partial class Form1 : Form
    {
        public DirectoryInfo RDI;           //root folder
        public DirectoryInfo LDI;           //local - category folder
        public FileInfo[] LocalFiles;       //file in LDI - snips
        public SnipCls CurrentSnip = new SnipCls();
        string CurrentFolder = "";          //folder snip is in
        bool NoSelect = true;               //no file is selected
        string SnipPath = "";               //path for current snip
        string SnipName = "";               //base name part of path
        // part of tree view selection
        public TreeNode CurntNode;          //= new TreeNode();

        // this needs to be static so it can be hidden and redisplayed
        FindSnipDlg FD = new FindSnipDlg();
        //merged dictionary for macro expansion
        Dictionary<string, List<string>> Repl = new Dictionary<string, List<string>>();

        TextBox BodyDisplay;
                
        //use the windows forms timer not the threading one
        System.Windows.Forms.Timer Timex;
        //----------------------------------------------------------------------
        //NAME: Form1
        //init the class
        //----------------------------------------------------------------------
        public Form1()
        {
            InitializeComponent();
            Gbls.MainForm = this;       //set who we are
            //-- logger first created, last destroyed
            Gbls.LG = new Logger();
            Gbls.LG.Title = Gbls.ProgTitle + " Log";
            Gbls.LG.WriteLog(Gbls.ProgTitle + " now running");
            Gbls.Init();
            toolStripStatusLabel.Text = Gbls.RootFolder;
            this.Text = Gbls.ProgTitle + " " + Gbls.ProgVersion;
            this.BackColor = Gbls.DarkColor;

            if (Gbls.DebugVersion)
            {
                mnuLoggerTop.Visible = true;
                Gbls.LG.Show();
                Gbls.LG.WriteLog(Gbls.ProgTitle + " running");
            }

            ContextMenuMgr.SetStripRo(DescDisplay);
            DescDisplay.ReadOnly = true;
            ContextMenuMgr.SetStripRo(txtDisplay);
            txtDisplay.ReadOnly = true;
            BodyDisplay = txtDisplay;

            tvSelect.ContextMenuStrip = ContextMenuMgr.GetEmptyStrip();

            //setup a timer 
            Timex = new System.Windows.Forms.Timer();
            Timex.Interval = 50;        //50 msc - 20 per second
            Timex.Tick += new System.EventHandler(Timex_Tick);
            Timex.Enabled = Gbls.DebugVersion;

            Gbls.LG.WriteLog("Initialize done");
        }
        //----------------------------------------------------------------------
        //NAME: Form1_Shown
        //main form is now visible
        //----------------------------------------------------------------------
        private void Form1_Shown(object sender, EventArgs e)
        {
            Gbls.LG.WriteLog("StartPath" + Gbls.StartPath);
            PopulateTv();
            //something forced focus to a label and looked ugly
            button2.Focus();
        }
        //----------------------------------------------------------------------
        //NAME: Form1_FormClosing
        //close files, cleanup anything used
        //----------------------------------------------------------------------
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Timex.Enabled = false;
            //Thread.Sleep(10);

            //-- logger first created, last destroyed
            Gbls.LG.WriteLog("Program Closed");
            Gbls.LG.UpdateDisplay();    //last update
            Gbls.LG.Stop();
        }
        //----------------------------------------------------------------------
        //NAME: btnNewSnip_Click
        //create a new snip for the library
        //----------------------------------------------------------------------
        private void btnNewSnip_Click(object sender, EventArgs e)
        {
            SnipEditDlg SED = new SnipEditDlg();
            int CrntItemIndex = lxbItem.SelectedIndex;

            SED.Setup("Enter New Snip");
            SED.MySnip = new SnipCls();
            try
            {
                if (CurntNode != null)
                {
                    SED.Category = CurntNode.FullPath;
                }
            }
            catch (Exception ex)
            {
                Gbls.LG.WriteLog("btnNewSnip_Click - CurntNode" + ex.ToString());
            }
            SED.RootFolder = Gbls.RootFolder;
            SED.MySnip.Body = Clipboard.GetText();
            SED.NewSnip = true;
            SED.WorkTree = Util.CloneTreeView(tvSelect);

            if (SED.ShowDialog() == DialogResult.OK)
            {
                PopulateTv();       //populate the tree view
                //if new snip in current folder - repopulate list box
                //need to select new snip - ED.Fname has path
                FindAction(SED.Fname);
                //- get the body again
                CurrentSnip = SED.MySnip;
                DescDisplay.Text = CurrentSnip.Description;
                txtDisplay.Text = CurrentSnip.Body;
                txbSnip.Text = "Snip Body Text";
                Gbls.LG.WriteLog("new snip: " + SED.Fname);
            }
            //else
            //{
            //    //?? new rejected, get old
            //}
        }
        //----------------------------------------------------------------------
        //NAME: mnuWordWrap_Click
        //toggle word wrapping on/off for the main display
        //----------------------------------------------------------------------
        private void mnuWordWrap_Click(object sender, EventArgs e)
        {
            txtDisplay.WordWrap = !txtDisplay.WordWrap;
        }
        //----------------------------------------------------------------------
        //NAME: PopulateItemsList
        //this gets the names of the snips in this folder
        //----------------------------------------------------------------------
        void PopulateItemsList()
        {
            int jj;
            string[] FileNames;

            //create the folder name -- see PopulateListBoxFile
            try
            {
                CurrentFolder = CurntNode.FullPath;
                string DirName = Gbls.RootFolder + "\\" + CurrentFolder;
                LDI = new DirectoryInfo(DirName);

                //get the file names in the folder
                txtDisplay.Text = "";
                lxbItem.Items.Clear();
                //get only the .snp files
                LocalFiles = LDI.GetFiles("*.snp");
                FileNames = Directory.GetFiles(DirName,"*.snp");
                Array.Sort(FileNames,LocalFiles);
                for (jj = 0; jj < LocalFiles.Length; jj++)
                {
                    lxbItem.Items.Add(LocalFiles[jj].Name);
                }
            }
            catch (Exception ex)
            {
                Gbls.LG.WriteLog("PopulateItemsList " + ex.ToString());
            }
            NoSelect = true;
            txtDisplay.Text = "";
        }
        //----------------------------------------------------------------------
        //NAME: lxbItem_SelectedIndexChanged
        //a new item was selected - get item, display, and copy to clipboard
        //----------------------------------------------------------------------
        private void lxbItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            string FileText = "";               //text of the selected file
            if (lxbItem.SelectedIndex >= 0)
            {
                NoSelect = false;
                //get the selected - root + foldername +selected
                try
                {
                    CurrentFolder = CurntNode.FullPath;
                }
                catch(Exception ex) 
                {
                    Gbls.LG.WriteLog("Select error: " + ex.ToString());
                    CurntNode = tvSelect.SelectedNode;
                    if (CurntNode == null)
                    {
                        return;
                    }
                    else
                    {
                        CurrentFolder = CurntNode.FullPath;
                    }
                }
                string Fname = Gbls.RootFolder + "\\" + CurrentFolder + "\\" + lxbItem.SelectedItem.ToString();
                //Gbls.LG.WriteLog("Select snip: " + Fname);
                SnipPath = Fname;
                SnipName = lxbItem.SelectedItem.ToString();
                FileText = Util.GetTextFile(SnipPath);
                CurrentSnip.GetSnipText(FileText);

                //see bug for find if text selected
                lxbItem.Focus();

                DescDisplay.Text = CurrentSnip.Description;
                BodyDisplay.Text = CurrentSnip.Body;
                SetClipText(CurrentSnip.Body);
                txbSnip.Text = "Snip Description";
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnExpand_Click
        //expand the body of the snippet as a string macro
        //----------------------------------------------------------------------
        private void btnExpand_Click(object sender, EventArgs e)
        {
            List<string> NL = new List<string>();
            List<string> DL = new List<string>();
            List<List<string>> Ops = new List<List<string>>();
            int jj = 0;

            //make sure we have something to work with
            if (CheckNoSnipSelect()) return;

            //try extracting the replace values
            MacString MS = new MacString(CurrentSnip.Body);
            Repl = MS.ReplaceItems;
            NL = MS.GetNames();
            if (NL.Count == 0)
            {
                MessageBox.Show("No Replacable items", "Macro Expand", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //run multiple input dialog, if OK, run string macro
                MultiInputDlg MD = new MultiInputDlg();
                MD.SetupText("Macro Expand", NL);
                MD.SetAllItems(Repl);

                //need to check for magic macro $ToDay$
                for (jj = 0; jj < NL.Count; jj++)
                {
                    if (NL[jj].ToUpper() == "TODAY")
                    {
                        List<string> Dates = Util.MakeDateList();
                        MD.SetComboBox(jj, Dates, Dates[0]);
                    }
                }

                MD.BackColor = Color.LightBlue;
                if (MD.ShowDialog() == DialogResult.OK)
                {
                    //get values
                    for (jj = 0; jj < NL.Count; jj++)
                    {
                        MS.NewValue(NL[jj], MD.Results[jj]);
                    }
                    CurrentSnip.Body = MS.MakeString();
                    SetClipText(CurrentSnip.Body);
                    txtDisplay.Text = CurrentSnip.Body;
                    txbSnip.Text = "Snip Body";
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: CheckNoSnipSelect
        //check for a selected node - many places need this
        //----------------------------------------------------------------------
        bool CheckNoSnipSelect()
        {
            //make sure we have something to work with
            if (NoSelect)
            {
                MessageBox.Show("No snip selected", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            else
            {
                return false;
            }
        }
        //----------------------------------------------------------------------
        //NAME: CheckNoFolderSelect
        //check for a selected folder - many places need this
        //----------------------------------------------------------------------
        bool CheckNoFolderSelect()
        {
            //make sure we have something to work with
            if (CurntNode != null)
            {
                CurrentFolder = CurntNode.FullPath;
            }

            if (CurrentFolder  == "")
            {
                MessageBox.Show("No folder selected", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            else
            {
                return false;
            }
        }
        //----------------------------------------------------------------------
        //NAME: tvSelect_AfterSelect
        //a folder or a file has been selected
        //----------------------------------------------------------------------
        private void tvSelect_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (CurntNode != null)
            {
                CurntNode.BackColor = Color.Empty;
            }
            TreeNode TN = tvSelect.SelectedNode;
            CurntNode = TN;
            string Tx = (string)TN.Tag;
            if (Tx == "D")
            {
                //Gbls.LG.WriteLog("Select Node Path: " + TN.FullPath);
                txtDisplay.Text = "";
                txbSnip.Text = "Folder Description";
                PopulateItemsList();
                NoSelect = true;
                // see if there is a description.txt file to display
                CurrentFolder = CurntNode.FullPath;
                string DescName = Gbls.RootFolder + "\\" + CurrentFolder + "\\Description.txt";
                FileInfo FI = new FileInfo(DescName);
                if (FI.Exists)
                {
                    string txx = "";
                    txx = Util.GetTextFile(DescName);
                    txtDisplay.Text = txx;
                    //txbSnip.Text = "Folder Description";
                    DescDisplay.Text = txx;
                    BodyDisplay.Text = "";
                }
                else
                {
                    txtDisplay.Text = "";
                }
                TN.BackColor = Color.LightBlue;
            }
        }
        //----------------------------------------------------------------------
        //NAME: PopulateTv
        //populate the TreeView
        //----------------------------------------------------------------------
        void PopulateTv()
        {
            int jj;
            DirectoryInfo DI;
            DirectoryInfo[] Subdirs;
            string[] DirNames;

            try
            {
                DI = new DirectoryInfo(Gbls.RootFolder);
                Subdirs = DI.GetDirectories();
                DirNames = Directory.GetDirectories(Gbls.RootFolder);
            }
            catch (Exception ex)
            {
                Gbls.LG.WriteLog("Exception: " + ex.ToString());
                MessageBox.Show("Can't Find Library", Gbls.ProgTitle,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                DI = new DirectoryInfo(Gbls.StartPath);
                Subdirs = DI.GetDirectories();
                DirNames = Directory.GetDirectories(Gbls.StartPath);
            }

            Array.Sort(DirNames, Subdirs);
            tvSelect.Nodes.Clear();
            for (jj = 0; jj < Subdirs.Length; jj++)
            {
                tvSelect.Nodes.Add(GetDirContent(Subdirs[jj].FullName));
            }
        }
        //----------------------------------------------------------------------
        //NAME: GetDirContent
        //get the content of this directory and any sub directoies
        //----------------------------------------------------------------------
        TreeNode GetDirContent(string MyDir)
        {
            int jj;
            TreeNode TN = new TreeNode();
            DirectoryInfo DI = new DirectoryInfo(MyDir);
            DirectoryInfo[] Subdirs = DI.GetDirectories();
            FileInfo[] MyFiles = DI.GetFiles("*.snp");

            TN.Text = DI.Name;
            TN.Name = DI.Name;
            TN.Tag = "D";       //directory node
            // get the rest of the tree
            for (jj = 0; jj < Subdirs.Length; jj++)
            {
                TN.Nodes.Add(GetDirContent(Subdirs[jj].FullName));
            }
            return TN;
        }
        //----------------------------------------------------------------------
        //NAME: btnFind_Click
        //find a snip that has the wanted text
        //----------------------------------------------------------------------
        private void btnFind_Click(object sender, EventArgs e)
        {
            FD.WorkTree = Util.CloneTreeView(tvSelect);
            FD.Text = "Finder for " + Gbls.ProgTitle;
            FD.WindowState = FormWindowState.Normal;
            FD.Show();
            FD.BringToFront();
        }
        //----------------------------------------------------------------------
        //NAME: FindAction
        //this is called by Find Window to get the result
        //----------------------------------------------------------------------
        public void FindAction(string Info)
        {
            //this will allow the find window to open the requested item
            Gbls.LG.WriteLog("Find info: " + Info);

            string tx = Info;
            FileInfo FI = new FileInfo(Gbls.RootFolder + "\\" + Info);

            try
            {
                TreeNode TN = new TreeNode();
                string[] PathNodes = tx.Split('\\');
                TN = tvSelect.Nodes[PathNodes[0]];
                TreeNode Tnx = new TreeNode(TN.Name);
                tvSelect.SelectedNode = TN;

                int jj = 0;
                for (jj = 1; jj < PathNodes.Length-1; jj++)
                {
                    Tnx = new TreeNode();
                    Tnx = TN.Nodes[PathNodes[jj]];
                    TN = Tnx;
                    tvSelect.SelectedNode = TN;
                }
                //now select the actual snip or Description            
                if(PathNodes[PathNodes.Length - 1].EndsWith(".txt"))
                {
                    string txx = Util.GetTextFile(Gbls.RootFolder + "\\" + Info);
                    txtDisplay.Text = txx;
                    txbSnip.Text = "Folder Description";
                }
                else if(PathNodes[PathNodes.Length - 1].EndsWith(".snp"))
                {
                    lxbItem.SelectedItem = PathNodes[PathNodes.Length - 1];
                }
                Util.BringUpForm(this);
            }
            catch (Exception ex)
            {
                Gbls.LG.WriteLog("Exception: " + ex.ToString());
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnCollapse_Click
        //Collapse the select folder tree view
        //----------------------------------------------------------------------
        private void btnCollapse_Click(object sender, EventArgs e)
        {
            if (CurntNode != null)
            {
                CurntNode.BackColor = Color.Empty;
            }
            tvSelect.CollapseAll();
            lxbItem.Items.Clear();
        }
        //----------------------------------------------------------------------
        //NAME: btnCopyToClip_Click
        //Copy the body of the current snip to the clipboard
        //----------------------------------------------------------------------
        private void btnCopyToClip_Click(object sender, EventArgs e)
        {
            //make sure we have something to work with
            if (CheckNoSnipSelect()) return;
            Clipboard.SetText(CurrentSnip.Body);
        }
        //----------------------------------------------------------------------
        //NAME: SetClipText
        //if auto is on, set clip board else ignore it
        //----------------------------------------------------------------------
        public static void SetClipText(string What)
        {
            if (Gbls.AutoClipboard)
            {
                Clipboard.SetText(What);
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnWordWrapDesc_Click
        //
        //----------------------------------------------------------------------
        private void btnWordWrapDesc_Click(object sender, EventArgs e)
        {
            DescDisplay.WordWrap = !DescDisplay.WordWrap;
        }
        //----------------------------------------------------------------------
        //NAME: btnWordWrapBody_Click
        //
        //----------------------------------------------------------------------
        private void btnWordWrapBody_Click(object sender, EventArgs e)
        {
            txtDisplay.WordWrap = !txtDisplay.WordWrap;
        }
        //----------------------------------------------------------------------
        //NAME: tvSelect_MouseDown
        //allow right mouse click to select node
        //----------------------------------------------------------------------
        private void tvSelect_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                TreeNode MyTn = tvSelect.GetNodeAt(e.Location);
                if (MyTn != null)
                {
                    tvSelect.SelectedNode = MyTn;
                }
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnCrypto_Click
        //simple encrypt / decrypt a snip
        //----------------------------------------------------------------------
        private void btnCrypto_Click(object sender, EventArgs e)
        {
            if (CheckNoSnipSelect()) return;

            CryptoDlg CD = new CryptoDlg();
            CD.Setup("SnipAssist Crypto");
            CD.SnipBody = CurrentSnip.Body;
            if (CD.ShowDialog() == DialogResult.OK)
            {
                //- get the body again - it might change
                CurrentSnip.Body = CD.SnipBody;
                //-- need to write the result to disk
                string Fname = Gbls.RootFolder + "\\" + CurrentFolder + "\\" + SnipName; //CurrentSnip.Name;
                StreamWriter SW = new StreamWriter(Fname);
                SW.Write(CurrentSnip.MakeString());
                SW.Close();
                txtDisplay.Text = CurrentSnip.Description;
                BodyDisplay.Text = CurrentSnip.Body;
                SetClipText(CurrentSnip.Body);
                txbSnip.Text = "Snip Description";
            }
        }
    }
}
