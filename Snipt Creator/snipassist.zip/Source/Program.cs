//------------------------------------------------------------------------------
//
//NAME: Program.cs
//
//DESCRIPTION: This is the main function for the SnipAssit program
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: Program
    //--------------------------------------------------------------------------
    static class Program
    {
        //----------------------------------------------------------------------
        //NAME: Main
        // The main entry point for the application.
        //----------------------------------------------------------------------
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Gbls.StartPath = Environment.CurrentDirectory;
            if (Gbls.DebugVersion)
            {
                string DebugPath = "C:\\Working\\SnipAssist";
                if (!Directory.Exists(DebugPath))
                {
                    MessageBox.Show("Debug Root Folder Not Found", Gbls.ProgTitle,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FolderBrowserDialog FBD = new FolderBrowserDialog();
                    FBD.ShowNewFolderButton = false;
                    FBD.Description = "Select working root folder";
                    if (FBD.ShowDialog() == DialogResult.OK)
                    {
                        DebugPath = FBD.SelectedPath;
                    }
                    else
                    {
                        return;     //exit program
                    }
                }
                Gbls.StartPath = DebugPath;
            }
            Application.Run(new Form1());
        }
    }
}
