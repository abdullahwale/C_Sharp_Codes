//------------------------------------------------------------------------------
//
//NAME: HelpForm.cs
//
//DESCRIPTION: This tests using a richTextBox as a help viewer. Teh window 
//designer and the resx need to be hand edited to get formatted text.
//
//HISTORY:
//------------------------------------------------------------------------------
//29-DEC-08 JBartel   Created
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    public partial class HelpForm : Form
    {
        //----------------------------------------------------------------------
        // NAME: HelpForm
        // Constructor - The buck starts here
        //----------------------------------------------------------------------
        public HelpForm()
        {
            InitializeComponent();
            //-- fill the window with the text box and resize with the window
            richTextBox1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left | 
                 AnchorStyles.Right | AnchorStyles.Top);
        }
        //----------------------------------------------------------------------
        // NAME: SetText
        // fill in the text
        //----------------------------------------------------------------------
        public void SetText(String Src)
        {
            richTextBox1.Rtf = Src;
        }
    }
}