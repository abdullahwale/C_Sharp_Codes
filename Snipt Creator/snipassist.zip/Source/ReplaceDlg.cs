//------------------------------------------------------------------------------
//
//FILE: ReplaceDlg.cs
//
//DESCRIPTION: This is the replace dialog for the text editor
//
// Copyright (c) 2015-2019, PineTreeJoe LLC, Joe Bartel - All rights reserved.
// For licensing, see license.txt - Released under MIT license
//
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Bartel
{
    //--------------------------------------------------------------------------
    //CLASS: ReplaceDlg
    //--------------------------------------------------------------------------
    public partial class ReplaceDlg : Form
    {
        public string MyTitle = "ReplaceDlg";

        public string What = "";
        public string Replacement = "";
        public bool IgnoreCase = true;
        public bool WholeWord = false;

        public bool StartAtBeginning = false;
        public bool StartCurrent = true;

        public bool ExitNow = false;        //set by delegate to quit
        public ReplaceEventHandler NextEvent;
        public ReplaceEventHandler ReplaceEvent;

        //----------------------------------------------------------------------
        //NAME: ReplaceDlg
        //init the dialog
        //----------------------------------------------------------------------
        public ReplaceDlg()
        {
            InitializeComponent();
        }
        //----------------------------------------------------------------------
        //NAME: ReplaceDlg_Shown
        //fill in the boxes from setup
        //----------------------------------------------------------------------
        private void ReplaceDlg_Shown(object sender, EventArgs e)
        {
            btnReplace.Visible = false;

            //display the current set of data
            this.Text = MyTitle;
            txbFindWhat.Text = What;
            if (What.Trim() == "")
            {
                txbFindWhat.Focus();
            }
            else
            {
                txbReplace.Focus();
            }
            chkIgnoreCase.Checked = IgnoreCase;
            chkWholeWord.Checked = WholeWord;
            rbStartBegin.Checked = StartAtBeginning;
            rbStartCurrent.Checked = StartCurrent;
            ContextMenuMgr.SetEmptyStrip(txbFindWhat);
            ContextMenuMgr.SetEmptyStrip(txbReplace);
        }
        //----------------------------------------------------------------------
        //NAME: Setup
        //
        //----------------------------------------------------------------------
        public void Setup(string title)
        {
            MyTitle = title;
        }
        //----------------------------------------------------------------------
        //NAME: btnNext_Click
        //bring back stuff or doit
        //----------------------------------------------------------------------
        private void btnNext_Click(object sender, EventArgs e)
        {
            What = txbFindWhat.Text;
            Replacement = txbReplace.Text;
            IgnoreCase = chkIgnoreCase.Checked;
            StartAtBeginning = rbStartBegin.Checked;
            StartCurrent = rbStartCurrent.Checked;

            if (NextEvent != null)
                NextEvent();

            rbStartBegin.Checked = true;

            if (ExitNow)
            {
                DialogResult = DialogResult.OK;
            }
            else
            {
                btnReplace.Visible = true;
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnReplace_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnReplace_Click(object sender, EventArgs e)
        {
            //now look for next
            What = txbFindWhat.Text;
            Replacement = txbReplace.Text;
            IgnoreCase = chkIgnoreCase.Checked;
            rbStartBegin.Checked = true;

            if (ReplaceEvent != null)
                ReplaceEvent();

            if (NextEvent != null)
                NextEvent();

            if (ExitNow)
            {
                DialogResult = DialogResult.OK;
            }
        }
        //----------------------------------------------------------------------
        //NAME: btnCancel_Click
        //forget about it
        //----------------------------------------------------------------------
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        //--------------------------------------------------------------------------
        //DELEGATE: ReplaceEventHandler
        //do something for the replace dialog
        //--------------------------------------------------------------------------
        public delegate void ReplaceEventHandler();
    }
}