﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;


namespace VOICE_RECOGNITION
{
    public partial class Form1 : Form
    {
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        SpeechSynthesizer synthesizer = new SpeechSynthesizer();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try

            {
                synthesizer.SelectVoiceByHints(VoiceGender.Female);
                Choices commands = new Choices();
                commands.Add(new string[] { "jb say hello", "jb print my name", "jb read selected text", "jb", "jb greet ics", "jb run notepad","jb turn off","jb run youtube" });          //commands to execute
                GrammarBuilder gBuilder = new GrammarBuilder();
                gBuilder.Append(commands);
                Grammar grammar = new Grammar(gBuilder);

                recEngine.LoadGrammarAsync(grammar);
                recEngine.SetInputToDefaultAudioDevice();
                recEngine.SpeechRecognized += recEngine_SpeechRecognized;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
          
        }
        void recEngine_SpeechRecognized(object sender,SpeechRecognizedEventArgs e)
        {
            switch(e.Result.Text )
            {
                case "jb say hello":
                    PromptBuilder builder = new PromptBuilder();
                    builder.StartSentence();
                    builder.AppendText("Hello Jhiro!");
                    builder.EndSentence();

                    builder.AppendBreak(new TimeSpan(0, 0, 0, 0, 25));

                     builder.StartSentence();
                    builder.AppendText("How are you?");
                    builder.EndSentence();
                    richTextBox1.Text += "\n jb say hello";
                   // MessageBox.Show("Hello Jhiro! How are you?");
                   // synthesizer.SpeakAsync("Hello Jhiro! How are you today?");
                    synthesizer.SpeakAsync(builder);
                    break;
                case "jb print my name":
                    richTextBox1.Text += "\n Jhiro";
                    break;
                case "jb read selected text":
                    synthesizer.SpeakAsync(richTextBox1.SelectedText);
                    break;
                case "jb":
                    richTextBox1.Text += "\n jb";
                    synthesizer.SpeakAsync("I'm fine sir! Ready to assist you sir!");
                    break;
                case "jb greet ics":
                    richTextBox1.Text += "\n jb greet ics";
                    synthesizer.SpeakAsync("Hello ICS department! How are you today!");
                    break;
                case "jb run notepad":
                    richTextBox1.Text += "\n jb run notepad";
                    System.Diagnostics.Process.Start(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Notepad++", @"notepad++.exe"));
                    break;
                case "jb turn off":
                    synthesizer.SpeakAsync("Bye-bye!");
                    System.Environment.Exit(0);
                  break;
                case "jb run youtube":
                  richTextBox1.Text += "\n jb run youtube";
                  runYouTube();
                  break;
            }
        }
        private void btnEnable_Click(object sender, EventArgs e)
        {
            try
            {
                recEngine.RecognizeAsync(RecognizeMode.Multiple);
               
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            finally
            {
                btnDisable.Enabled = true;
            }
          
        }

        private void btnDisable_Click(object sender, EventArgs e)
        {
            try
            {
                recEngine.RecognizeAsyncStop();
                btnDisable.Enabled = false;
            }
           
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
          
        }

      

        public void runYouTube()
        {
            try
            {
                
                var embed = "<html><head>" +
                "<meta http-equiv=\"X-UA-Compatible\" content=\"IE=Edge\"/>" +
                "</head><body>" +
                 "<iframe width=\"450\" height=\"250\" src=\"{0}\"" +
                 "frameborder = \"0\" allow = \"autoplay; encrypted-media\" allowfullscreen></iframe>" +
                 "</body></html>";
               var url = "https://www.youtube.com/embed/08NwONfuDuI";
                this.webBrowser1.DocumentText = string.Format(embed, url);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }
    }
}
